const DISPLAY_NAME = '§a消§b耗§9卡 §d- §a跳跃提升 I';

const SKILL_NAMES = [
    '§a消耗卡 - 跳跃提升 I'
];

const COOLDOWN_MS = 1000; //时间
const BUFF_TICKS = 1200000000;    // 6000000s
const RANGE = 1;           // 技能影响范围（格数）

const cdMap = new Map();
const skillMap = new Map();

/* ===== 技能分发 ===== */
function onUse(evt) {
    const player = evt.getPlayer();
    const uuid = player.getUniqueId().toString();
    const now = Date.now();

    if (cdMap.has(uuid) && now - cdMap.get(uuid) < COOLDOWN_MS) {
        player.sendActionBar('§7冷却中...');
        return;
    }
    cdMap.set(uuid, now);

    const skillIndex = skillMap.has(uuid) ? (skillMap.get(uuid) + 1) % 1 : 0;
    skillMap.set(uuid, skillIndex);

    switch (skillIndex) {
        case 0: skillBuff(player); break;
    }

    player.sendMessage(`§a[${SKILL_NAMES[skillIndex]}] §a已使用！`);
    
    // 添加物品消耗逻辑
    const invs = player.getInventory();
    const itemInMainHand = invs.getItemInMainHand();
    
    if (itemInMainHand.getAmount() > 1) {
        itemInMainHand.setAmount(itemInMainHand.getAmount() - 1);
    } else {
        invs.setItemInMainHand(null); // 如果只剩下一个，则移除物品
    }
}

/* ===== 群体增益 ===== */
function skillBuff(player) {
    const PotionEffect = Packages.org.bukkit.potion.PotionEffect;
    const PotionEffectType = Packages.org.bukkit.potion.PotionEffectType;
    const world = player.getWorld();
    const LivingEntity = Packages.org.bukkit.entity.LivingEntity;

    //提供跳跃提升效果
    const jumpBoostEffect = PotionEffectType.getByName("JUMP_BOOST") || PotionEffectType.JUMP;

    const buffs = [
        new PotionEffect(jumpBoostEffect, BUFF_TICKS, 0)
    ];

    world.getNearbyEntities(player.getLocation(), RANGE, RANGE, RANGE).forEach(function (ent) {
        if (ent instanceof LivingEntity && ent !== player) {
            buffs.forEach(buff => {
                if (buff.getType() !== null) {
                    ent.addPotionEffect(buff);
                }
            });
        }
    });
    // 自己也吃
    buffs.forEach(b => {
        if (b.getType() !== null) {
            player.addPotionEffect(b);
        }
    });
    world.playSound(player.getLocation(), 'item.totem.use', 1, 1.2);
}

/* ===== 事件绑定 ===== */
function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            const action = evt.getAction().name();
            if (action !== 'RIGHT_CLICK_AIR' && action !== 'RIGHT_CLICK_BLOCK') return;
            if (evt.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

            const item = evt.getPlayer().getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() !== DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}