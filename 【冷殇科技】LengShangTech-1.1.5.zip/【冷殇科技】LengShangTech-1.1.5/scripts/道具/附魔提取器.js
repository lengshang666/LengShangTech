const DISPLAY_NAME = '§d§l附魔提取器';

/* ===== 创建真正的存储附魔书 ===== */
function createStoredEnchantBook(enchantment, level) {
    const book = new org.bukkit.inventory.ItemStack(org.bukkit.Material.ENCHANTED_BOOK);
    
    try {
        // 获取 ItemFactory
        const itemFactory = org.bukkit.Bukkit.getItemFactory();
        
        // 创建 EnchantmentStorageMeta（通过反射）
        const metaClass = java.lang.Class.forName('org.bukkit.inventory.meta.EnchantmentStorageMeta');
        
        // 获取 asMeta 方法（Bukkit 1.20+ 方式）或直接用 itemFactory
        let storageMeta = null;
        
        try {
            // 尝试直接通过 ItemFactory 创建特定类型的 meta
            storageMeta = itemFactory.getItemMeta(org.bukkit.Material.ENCHANTED_BOOK);
            
            // 确保我们得到的是 EnchantmentStorageMeta
            if (storageMeta && metaClass.isInstance(storageMeta)) {
                // 使用反射调用 addStoredEnchant
                const addStoredEnchantMethod = metaClass.getMethod('addStoredEnchant', 
                    org.bukkit.enchantments.Enchantment.class, 
                    java.lang.Integer.TYPE, 
                    java.lang.Boolean.TYPE);
                addStoredEnchantMethod.invoke(storageMeta, enchantment, level, true);
                
                // 设置回物品
                book.setItemMeta(storageMeta);
                return book;
            }
        } catch (e1) {
            // 上面的方法失败，尝试备用方案
        }
        
        // 备用方案：使用 Bukkit 的 Unsafe 方法
        // 创建书，然后通过反射获取并修改内部存储
        const meta = book.getItemMeta();
        if (meta) {
            // 尝试直接调用存储附魔方法（如果可用）
            try {
                const addStoredMethod = meta.getClass().getMethod('addStoredEnchant',
                    org.bukkit.enchantments.Enchantment.class,
                    java.lang.Integer.TYPE,
                    java.lang.Boolean.TYPE);
                addStoredMethod.invoke(meta, enchantment, level, true);
                book.setItemMeta(meta);
                return book;
            } catch (e2) {
                // 方法不存在，使用最后的备用方案
            }
        }
        
        // 最后的备用：unsafe 附魔（虽然不完美，但至少能工作）
        book.addUnsafeEnchantment(enchantment, level);
        return book;
        
    } catch (e) {
        // 所有反射都失败，使用 unsafe 附魔
        book.addUnsafeEnchantment(enchantment, level);
        return book;
    }
}

/* ===== 提取一个附魔并生成附魔书 ===== */
function extractOneEnchant(item, player) {
    if (!item || item.getType() === org.bukkit.Material.AIR) {
        return { success: false, reason: 'no_item' };
    }
    
    const meta = item.getItemMeta();
    if (!meta || !meta.hasEnchants()) {
        return { success: false, reason: 'no_enchants' };
    }
    
    // 获取所有附魔
    const enchants = meta.getEnchants();
    const keys = enchants.keySet().toArray();
    
    if (keys.length === 0) {
        return { success: false, reason: 'no_enchants' };
    }
    
    // 只取第一个附魔
    const enchantment = keys[0];
    const level = enchants.get(enchantment);
    const enchantKey = enchantment.getKey().toString();
    
    // 从原物品移除这个附魔
    meta.removeEnchant(enchantment);
    item.setItemMeta(meta);
    
    // 创建真正的存储附魔书
    const enchantedBook = createStoredEnchantBook(enchantment, level);
    
    // 将附魔书给玩家
    const inventory = player.getInventory();
    const leftover = inventory.addItem(enchantedBook);
    
    // 如果背包满了，掉落在玩家位置
    if (leftover && !leftover.isEmpty()) {
        const location = player.getLocation();
        const world = location.getWorld();
        const values = leftover.values().toArray();
        for (let i = 0; i < values.length; i++) {
            world.dropItemNaturally(location, values[i]);
        }
    }
    
    return {
        success: true,
        enchantName: enchantKey.replace('minecraft:', ''),
        level: level,
        remaining: keys.length - 1
    };
}

/* ===== 主处理函数 ===== */
function onUse(evt) {
    const player = evt.getPlayer();
    const equipment = player.getEquipment();
    
    // 获取副手物品
    const offHandItem = equipment.getItem(org.bukkit.inventory.EquipmentSlot.OFF_HAND);
    
    // 检查副手是否有物品
    if (!offHandItem || offHandItem.getType() === org.bukkit.Material.AIR) {
        player.sendMessage('§c✖ §7副手没有物品！请将需要提取附魔的物品放在副手。');
        try {
            player.playSound(player.getLocation(), 'block.note_block.bass', 1.0, 0.5);
        } catch (e) {}
        return;
    }
    
    // 检查是否是附魔书
    let isStoredEnchant = false;
    
    if (offHandItem.getType() === org.bukkit.Material.ENCHANTED_BOOK) {
        try {
            const meta = offHandItem.getItemMeta();
            if (meta) {
                const hasStoredMethod = meta.getClass().getMethod('hasStoredEnchants');
                if (hasStoredMethod) {
                    const hasStored = hasStoredMethod.invoke(meta);
                    if (hasStored) {
                        isStoredEnchant = true;
                    }
                }
            }
        } catch (e) {
            isStoredEnchant = false;
        }
    }
    
    // 提取一个附魔
    let result;
    
    if (isStoredEnchant) {
        result = extractStoredEnchant(offHandItem, player);
    } else {
        result = extractOneEnchant(offHandItem, player);
    }
    
    // 根据结果反馈
    if (!result.success) {
        if (result.reason === 'no_item') {
            player.sendMessage('§c✖ §7副手没有物品！');
        } else if (result.reason === 'no_enchants') {
            player.sendMessage('§c✖ §7副手物品没有任何附魔！');
        }
        try {
            player.playSound(player.getLocation(), 'block.note_block.bass', 1.0, 0.5);
        } catch (e) {}
        return;
    }
    
    // 成功提取
    const enchantDisplay = formatEnchantName(result.enchantName) + (result.level > 1 ? ' ' + toRoman(result.level) : '');
    
    // 播放音效
    try {
        player.playSound(player.getLocation(), 'block.enchantment_table.use', 1.0, 1.0);
        player.playSound(player.getLocation(), 'entity.experience_orb.pickup', 0.5, 1.0);
    } catch (e) {}
    
    // 发送消息
    player.sendMessage('§d§l✦ §d§l附魔提取成功 §d§l✦');
    player.sendMessage(`§a✓ §f提取了：§e${enchantDisplay}`);
    player.sendMessage(`§7§o副手物品还有 ${result.remaining} 个附魔`);
    
    // 更新副手物品
    equipment.setItem(org.bukkit.inventory.EquipmentSlot.OFF_HAND, offHandItem);
    
    // 如果还有附魔，提示可以继续提取
    if (result.remaining > 0) {
        player.sendMessage('§7§o右键继续使用以提取下一个附魔');
    } else {
        player.sendMessage('§a§l该物品的所有附魔已提取完毕！');
        try {
            player.playSound(player.getLocation(), 'entity.player.levelup', 0.5, 1.0);
        } catch (e) {}
    }
}

/* ===== 从附魔书提取存储附魔 ===== */
function extractStoredEnchant(book, player) {
    const meta = book.getItemMeta();
    if (!meta) {
        return { success: false, reason: 'no_enchants' };
    }
    
    try {
        // 通过反射获取存储附魔
        const getStoredMethod = meta.getClass().getMethod('getStoredEnchants');
        const enchants = getStoredMethod.invoke(meta);
        
        if (!enchants || enchants.isEmpty()) {
            return { success: false, reason: 'no_enchants' };
        }
        
        // 获取第一个附魔
        const keys = enchants.keySet().toArray();
        const enchantment = keys[0];
        const level = enchants.get(enchantment);
        
        // 创建新的附魔书（使用新的创建函数）
        const newBook = createStoredEnchantBook(enchantment, level);
        
        // 从原书移除这个附魔
        const removeStoredMethod = meta.getClass().getMethod('removeStoredEnchant', org.bukkit.enchantments.Enchantment.class);
        removeStoredMethod.invoke(meta, enchantment);
        book.setItemMeta(meta);
        
        // 给玩家新书
        const inventory = player.getInventory();
        const leftover = inventory.addItem(newBook);
        
        if (leftover && !leftover.isEmpty()) {
            const location = player.getLocation();
            const world = location.getWorld();
            const values = leftover.values().toArray();
            for (let i = 0; i < values.length; i++) {
                world.dropItemNaturally(location, values[i]);
            }
        }
        
        // 检查剩余附魔
        const hasStoredMethod = meta.getClass().getMethod('hasStoredEnchants');
        const hasRemaining = hasStoredMethod.invoke(meta);
        let remainingCount = 0;
        if (hasRemaining) {
            const remainingEnchants = getStoredMethod.invoke(meta);
            remainingCount = remainingEnchants.size();
        }
        
        return {
            success: true,
            enchantName: enchantment.getKey().toString().replace('minecraft:', ''),
            level: level,
            remaining: remainingCount
        };
        
    } catch (e) {
        // 反射失败，尝试当作普通物品处理
        return extractOneEnchant(book, player);
    }
}

/* ===== 格式化附魔名称 ===== */
function formatEnchantName(key) {
    const nameMap = {
        'protection': '保护',
        'fire_protection': '火焰保护',
        'feather_falling': '摔落保护',
        'blast_protection': '爆炸保护',
        'projectile_protection': '弹射物保护',
        'respiration': '水下呼吸',
        'aqua_affinity': '水下速掘',
        'thorns': '荆棘',
        'depth_strider': '深海探索者',
        'frost_walker': '冰霜行者',
        'binding_curse': '绑定诅咒',
        'sharpness': '锋利',
        'smite': '亡灵杀手',
        'bane_of_arthropods': '节肢杀手',
        'knockback': '击退',
        'fire_aspect': '火焰附加',
        'looting': '抢夺',
        'sweeping': '横扫之刃',
        'efficiency': '效率',
        'silk_touch': '精准采集',
        'unbreaking': '耐久',
        'fortune': '时运',
        'power': '力量',
        'punch': '冲击',
        'flame': '火矢',
        'infinity': '无限',
        'luck_of_the_sea': '海之眷顾',
        'lure': '饵钓',
        'mending': '经验修补',
        'vanishing_curse': '消失诅咒',
        'loyalty': '忠诚',
        'impaling': '穿刺',
        'riptide': '激流',
        'channeling': '引雷',
        'multishot': '多重射击',
        'piercing': '穿透',
        'quick_charge': '快速装填',
        'soul_speed': '灵魂疾行',
        'swift_sneak': '迅捷潜行'
    };
    
    const cleanKey = key.replace('minecraft:', '');
    
    if (nameMap[cleanKey]) {
        return nameMap[cleanKey];
    }
    
    return cleanKey.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

/* ===== 数字转罗马数字 ===== */
function toRoman(num) {
    const roman = {
        1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V',
        6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'
    };
    return roman[num] || num;
}

/* ===== 事件绑定 ===== */
function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            const action = evt.getAction().name();
            if (action !== 'RIGHT_CLICK_AIR' && action !== 'RIGHT_CLICK_BLOCK') return;
            if (evt.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

            const item = evt.getPlayer().getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() !== DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();