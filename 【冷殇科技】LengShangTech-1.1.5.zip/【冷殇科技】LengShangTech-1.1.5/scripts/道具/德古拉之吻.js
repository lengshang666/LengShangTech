function onWeaponHit(event, player) {

    // 获取实际造成的伤害（取原始伤害和目标当前生命值的最小值）
    let finalDamage = event.getFinalDamage();

    // 获取玩家当前和最大健康值
    let currentHealth = player.getHealth();
    let maxHealth = player.getMaxHealth();

    // 按实际造成伤害的20%回复生命
    let healAmount = finalDamage * 0.20;
    let newHealth = Math.min(currentHealth + healAmount, maxHealth);

    // 设置新的健康值
    player.setHealth(newHealth);

    // 调试信息
    player.sendMessage("§c[吸血] §7造成伤害: §4" + finalDamage + " §6回复: §a" + healAmount.toFixed(1) + " §a点生命值");
}