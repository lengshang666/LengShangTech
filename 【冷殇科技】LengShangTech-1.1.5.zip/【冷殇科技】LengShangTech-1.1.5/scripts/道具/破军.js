function onWeaponHit(event, player) {
    // 获取原始伤害
    let finalDamage = event.getFinalDamage();
    
    // 20%概率触发双倍伤害
    if (Math.random() < 0.20) {
        // 计算双倍伤害（在实际伤害基础上翻倍）
        let bonusDamage = finalDamage; // 额外造成等于原伤害的伤害
        let totalDamage = finalDamage + bonusDamage; // 总伤害 = 原伤害 + 额外伤害

        // 方式1：如果事件支持直接设置伤害
        event.setDamage(totalDamage);

        // 调试信息
        player.sendMessage("§c[暴击] §7触发双倍伤害！原伤害: §4" + finalDamage + " §6总伤害: §4" + totalDamage);
    }
}