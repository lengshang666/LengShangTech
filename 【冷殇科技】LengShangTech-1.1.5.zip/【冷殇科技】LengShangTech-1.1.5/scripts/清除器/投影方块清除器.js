const DISPLAY_NAME = '§b投影方块清除器';

const RANGE = 100;         // 清除半径
const COOLDOWN_MS = 1000;  // 冷却1秒

const cdMap = new Map();

/* ===== 范围清除投影方块 ===== */
function onUse(evt) {
    const player = evt.getPlayer();
    const uuid = player.getUniqueId().toString();
    const now = Date.now();

    // 冷却检查
    if (cdMap.has(uuid) && now - cdMap.get(uuid) < COOLDOWN_MS) {
        player.sendActionBar('§7冷却中...');
        return;
    }
    cdMap.set(uuid, now);

    const world = player.getWorld();
    const location = player.getLocation();

    let clearCount = 0;

    // 获取Bukkit实体类引用
    const BlockDisplay = Packages.org.bukkit.entity.BlockDisplay;
    const ItemDisplay = Packages.org.bukkit.entity.ItemDisplay;
    const Display = Packages.org.bukkit.entity.Display;

    // 遍历范围内的所有实体
    world.getNearbyEntities(location, RANGE, RANGE, RANGE).forEach(function(ent) {
        let shouldRemove = false;
        
        // 检查是否为 BlockDisplay（方块展示实体）
        if (ent instanceof BlockDisplay) {
            shouldRemove = true;
        }
        // 检查是否为 ItemDisplay（物品展示实体）
        else if (ent instanceof ItemDisplay) {
            shouldRemove = true;
        }
        // 检查是否为 Display 类型的其他展示实体（包括 TextDisplay）
        else if (ent instanceof Display) {
            shouldRemove = true;
        }
        
        // 可选：更精确的检测 - 检查是否是投影模组创建的特定属性
        if (!shouldRemove) {
            try {
                // 检查实体是否有特定的投影相关元数据（某些模组会添加）
                const entityType = ent.getType().name();
                if (entityType === 'BLOCK_DISPLAY' || 
                    entityType === 'ITEM_DISPLAY' ||
                    entityType === 'TEXT_DISPLAY') {
                    shouldRemove = true;
                }
            } catch (e) {
                // 忽略错误
            }
        }

        if (shouldRemove) {
            ent.remove();
            clearCount++;
        }
    });

    // 反馈信息
    if (clearCount > 0) {
        player.sendMessage(`§b已清除${clearCount}个投影方块`);
    } else {
        player.sendMessage('§7半径100格内未发现投影方块');
    }
}

/* ===== 事件绑定 ===== */
function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            const action = evt.getAction().name();
            if (action !== 'RIGHT_CLICK_AIR' && action !== 'RIGHT_CLICK_BLOCK') return;
            if (evt.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

            const item = evt.getPlayer().getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() !== DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();