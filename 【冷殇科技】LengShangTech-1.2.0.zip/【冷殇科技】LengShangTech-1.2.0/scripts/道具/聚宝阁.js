// ============================================
// 冷殇商店系统 - 聚宝阁（重构版）
// 基于 RykenSlimefunCustomizer (RSC) + GraalJS 开发
// 功能：独立价格配置 + 批量购买 + 冷却机制 + 背包检查
// ============================================

// ============================================
// 【配置区域 1】分类配置
// ============================================
const CATEGORIES = [
    {
        id: '树苗',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0树§x§F§F§D§7§0§0苗 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1全部树苗 §x§C§D§5§B§9§9❀',
        icon: 'OAK_SAPLING',
        slot: 10
    },
    {
        id: '花',
        name: '§x§F§F§0§0§0§0⚡ §x§A§D§F§F§2§F花 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1各类花 §x§C§D§5§B§9§9❀',
        icon: 'PINK_TULIP',
        slot: 11
    },
    {
        id: '矿物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0矿§x§F§F§D§7§0§0物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1各种矿物 §x§C§D§5§B§9§9❀',
        icon: 'DIAMOND',
        slot: 12
    },
    {
        id: '掉落物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0掉§x§F§F§D§7§0§0落§x§A§D§F§F§2§F物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1生物掉落物 §x§C§D§5§B§9§9❀',
        icon: 'BLAZE_ROD',
        slot: 13
    },
    {
        id: '杂物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0杂§x§F§F§D§7§0§0物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1杂物与农作物 §x§C§D§5§B§9§9❀',
        icon: 'POTATO',
        slot: 14
    },
    {
        id: '方块',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0方§x§F§F§D§7§0§0块 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9各种方块 §x§C§D§5§B§9§9❀',
        icon: 'STONE',
        slot: 15
    },
    {
        id: '海洋',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0海§x§F§F§D§7§0§0洋 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9海洋群系 §x§C§D§5§B§9§9❀',
        icon: 'TUBE_CORAL',
        slot: 16
    },
    {
        id: '粘液科技',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0粘§x§F§F§D§7§0§0液 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9粘液基础物资 §x§C§D§5§B§9§9❀',
        icon: 'SLIME_BALL',
        slot: 19
    },
    {
        id: '合成锭',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0合§x§F§F§D§7§0§0成§x§A§D§F§F§2§F锭 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1一键加工 §x§C§D§5§B§9§9❀',
        icon: 'IRON_INGOT',
        slot: 20
    },
    {
        id: '制造',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0制§x§F§F§D§7§0§0造 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9一键制造 §x§C§D§5§B§9§9❀',
        icon: 'COBBLESTONE',
        slot: 21
    },
];

// ============================================
// 【配置区域 2】界面装饰配置
// ============================================
const INFO_ITEM = {
    material: 'PAINTING',
    name: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9聚§x§E§B§9§1§B§1宝§x§E§1§7§F§A§9阁 §x§C§D§5§B§9§9❀',
    lore: ['§f点击下方分类查看可购买物品', '§f每个物品标有售价', '§eShift+点击可批量购买']
};

const MAIN_TITLE = '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9聚§x§E§B§9§1§B§1宝§x§E§1§7§F§A§9阁 §x§C§D§5§B§9§9❀';  // 主菜单窗口标题
const SUB_PRE = '§x§F§F§B§6§C§1❀ ';
const SUB_SUF = ' §x§C§D§5§B§9§9❀';

const BORDER_SLOTS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 46, 47, 51, 52, 53];
const PAGE_SIZE = 28;
const ITEM_SLOTS = [10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43];
const PREV_SLOT = 48;
const NEXT_SLOT = 50;

// ============================================
// 【配置区域 3】商品配置（新版：独立 price 数组）
// ============================================
// price 格式: [{ id: '物品ID', amount: 数量 }, ...]
// 支持多货币组合支付
const ITEMS = {
    树苗: [
        { type: 'vanilla', id: 'OAK_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：8个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 8 }] },
        { type: 'vanilla', id: 'SPRUCE_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'BIRCH_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'JUNGLE_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'ACACIA_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'DARK_OAK_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'CHERRY_SAPLING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'MANGROVE_PROPAGULE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'AZALEA', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'FLOWERING_AZALEA', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'CRIMSON_FUNGUS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] },
        { type: 'vanilla', id: 'WARPED_FUNGUS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个橡树树苗', '§eShift+点击批量购买'], price: [{ id: 'OAK_SAPLING', amount: 1 }] }
    ],
    花: [
        { type: 'vanilla', id: 'POPPY', lines: ['§f------§a§l点击购买§f------', '§a售价：1个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 1 }] },
        { type: 'vanilla', id: 'DANDELION', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'BLUE_ORCHID', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'ALLIUM', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'AZURE_BLUET', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'OXEYE_DAISY', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'CORNFLOWER', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'RED_TULIP', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'ORANGE_TULIP', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'WHITE_TULIP', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'PINK_TULIP', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'LILY_OF_THE_VALLEY', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'SUNFLOWER', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'LILAC', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'ROSE_BUSH', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'PEONY', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'PITCHER_PLANT', lines: ['§f------§a§l点击购买§f------', '§a售价：1个瓶子草夹果', '§eShift+点击批量购买'], price: [{ id: 'PITCHER_POD', amount: 1 }] },
        { type: 'vanilla', id: 'TORCHFLOWER', lines: ['§f------§a§l点击购买§f------', '§a售价：1个火把花种子', '§eShift+点击批量购买'], price: [{ id: 'TORCHFLOWER_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'PINK_PETALS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'CHORUS_FLOWER', lines: ['§f------§a§l点击购买§f------', '§a售价：8个紫颂果', '§eShift+点击批量购买'], price: [{ id: 'CHORUS_FRUIT', amount: 8 }] },
        { type: 'vanilla', id: 'SPORE_BLOSSOM', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'WITHER_ROSE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'BROWN_MUSHROOM', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] },
        { type: 'vanilla', id: 'RED_MUSHROOM', lines: ['§f------§a§l点击购买§f------', '§a售价：1个虞美人', '§eShift+点击批量购买'], price: [{ id: 'POPPY', amount: 1 }] }
    ],
    矿物: [
        { type: 'vanilla', id: 'COAL', lines: ['§f------§a§l点击购买§f------', '§a售价：8个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 8 }] },
        { type: 'vanilla', id: 'REDSTONE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 8 }] },
        { type: 'vanilla', id: 'LAPIS_LAZULI', lines: ['§f------§a§l点击购买§f------', '§a售价：8个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 8 }] },
        { type: 'vanilla', id: 'QUARTZ', lines: ['§f------§a§l点击购买§f------', '§a售价：1个灵魂沙', '§eShift+点击批量购买'], price: [{ id: 'SOUL_SAND', amount: 1 }] },
        { type: 'vanilla', id: 'COPPER_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 4 }] },
        { type: 'vanilla', id: 'IRON_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：8个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 8 }] },
        { type: 'vanilla', id: 'GOLD_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个铁锭', '§eShift+点击批量购买'], price: [{ id: 'IRON_INGOT', amount: 4 }] },
        { type: 'vanilla', id: 'AMETHYST_SHARD', lines: ['§f------§a§l点击购买§f------', '§a售价：8个铁锭', '§eShift+点击批量购买'], price: [{ id: 'IRON_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'DIAMOND', lines: ['§f------§a§l点击购买§f------', '§a售价：8个金锭', '§eShift+点击批量购买'], price: [{ id: 'GOLD_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'EMERALD', lines: ['§f------§a§l点击购买§f------', '§a售价：8个钻石', '§eShift+点击批量购买'], price: [{ id: 'DIAMOND', amount: 8 }] },
        { type: 'vanilla', id: 'NETHERITE_SCRAP', lines: ['§f------§a§l点击购买§f------', '§a售价：16个绿宝石', '§eShift+点击批量购买'], price: [{ id: 'EMERALD', amount: 16 }] },
        { type: 'vanilla', id: 'NETHERITE_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个下界合金碎片', '§eShift+点击批量购买'], price: [{ id: 'NETHERITE_SCRAP', amount: 4 }] }
    ],
    掉落物: [
        { type: 'vanilla', id: 'ROTTEN_FLESH', lines: ['§f------§a§l点击购买§f------', '§a售价：1个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 1 }] },
        { type: 'vanilla', id: 'STRING', lines: ['§f------§a§l点击购买§f------', '§a售价：1个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 1 }] },
        { type: 'vanilla', id: 'BONE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 1 }] },
        { type: 'vanilla', id: 'GUNPOWDER', lines: ['§f------§a§l点击购买§f------', '§a售价：1个沙子', '§eShift+点击批量购买'], price: [{ id: 'SAND', amount: 1 }] },
        { type: 'vanilla', id: 'SPIDER_EYE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个线', '§eShift+点击批量购买'], price: [{ id: 'STRING', amount: 4 }] },
        { type: 'vanilla', id: 'LEATHER', lines: ['§f------§a§l点击购买§f------', '§a售价：4个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 4 }] },
        { type: 'vanilla', id: 'FEATHER', lines: ['§f------§a§l点击购买§f------', '§a售价：4个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 4 }] },
        { type: 'vanilla', id: 'BEEF', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'PORKCHOP', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'MUTTON', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'CHICKEN', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'RABBIT', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'COD', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'SALMON', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'INK_SAC', lines: ['§f------§a§l点击购买§f------', '§a售价：8个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 8 }] },
        { type: 'vanilla', id: 'GLOW_INK_SAC', lines: ['§f------§a§l点击购买§f------', '§a售价：1个墨囊', '§eShift+点击批量购买'], price: [{ id: 'INK_SAC', amount: 1 }] },
        { type: 'vanilla', id: 'ENDER_PEARL', lines: ['§f------§a§l点击购买§f------', '§a售价：16个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 16 }] },
        { type: 'vanilla', id: 'BLAZE_ROD', lines: ['§f------§a§l点击购买§f------', '§a售价：32个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 32 }] },
        { type: 'vanilla', id: 'BREEZE_ROD', lines: ['§f------§a§l点击购买§f------', '§a售价：4个烈焰棒', '§eShift+点击批量购买'], price: [{ id: 'BLAZE_ROD', amount: 4 }] },
        { type: 'vanilla', id: 'RABBIT_HIDE', lines: ['§f------§a§l点击购买§f------', '§a售价：2个生兔肉', '§eShift+点击批量购买'], price: [{ id: 'RABBIT', amount: 2 }] },
        { type: 'vanilla', id: 'RABBIT_FOOT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个兔子皮', '§eShift+点击批量购买'], price: [{ id: 'RABBIT_HIDE', amount: 4 }] },
        { type: 'vanilla', id: 'WITHER_SKELETON_SKULL', lines: ['§f------§a§l点击购买§f------', '§a售价：64个骨头', '§eShift+点击批量购买'], price: [{ id: 'BONE', amount: 64 }] },
        { type: 'vanilla', id: 'NETHER_STAR', lines: ['§f------§a§l点击购买§f------', '§a售价：4个灵魂沙 + 3个凋零骷髅头颅', '§eShift+点击批量购买'], price: [{ id: 'SOUL_SAND', amount: 4 }, { id: 'WITHER_SKELETON_SKULL', amount: 3 }] },
        { type: 'vanilla', id: 'SHULKER_SHELL', lines: ['§f------§a§l点击购买§f------', '§a售价：16个末影珍珠', '§eShift+点击批量购买'], price: [{ id: 'ENDER_PEARL', amount: 16 }] },
        { type: 'vanilla', id: 'HONEYCOMB', lines: ['§f------§a§l点击购买§f------', '§a售价：16个线', '§eShift+点击批量购买'], price: [{ id: 'STRING', amount: 16 }] },
        { type: 'vanilla', id: 'PHANTOM_MEMBRANE', lines: ['§f------§a§l点击购买§f------', '§a售价：16个线', '§eShift+点击批量购买'], price: [{ id: 'STRING', amount: 16 }] },
        { type: 'vanilla', id: 'GHAST_TEAR', lines: ['§f------§a§l点击购买§f------', '§a售价：4个灵魂沙', '§eShift+点击批量购买'], price: [{ id: 'SOUL_SAND', amount: 4 }] },
        { type: 'vanilla', id: 'SLIME_BALL', lines: ['§f------§a§l点击购买§f------', '§a售价：4个甘蔗', '§eShift+点击批量购买'], price: [{ id: 'SUGAR_CANE', amount: 4 }] },
        { type: 'vanilla', id: 'TURTLE_SCUTE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个粘液球', '§eShift+点击批量购买'], price: [{ id: 'SLIME_BALL', amount: 8 }] }
    ],
    杂物: [
        { type: 'vanilla', id: 'POTATO', lines: ['§f------§a§l点击购买§f------', '§a售价：64个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 64 }] },
        { type: 'vanilla', id: 'CARROT', lines: ['§f------§a§l点击购买§f------', '§a售价：64个腐肉', '§eShift+点击批量购买'], price: [{ id: 'ROTTEN_FLESH', amount: 64 }] },
        { type: 'vanilla', id: 'APPLE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个橡树原木', '§eShift+点击批量购买'], price: [{ id: 'OAK_LOG', amount: 4 }] },
        { type: 'vanilla', id: 'MELON_SLICE', lines: ['§f------§a§l点击购买§f------', '§a售价：2个苹果', '§eShift+点击批量购买'], price: [{ id: 'APPLE', amount: 2 }] },
        { type: 'vanilla', id: 'SWEET_BERRIES', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'GLOW_BERRIES', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'BAMBOO', lines: ['§f------§a§l点击购买§f------', '§a售价：4个甘蔗', '§eShift+点击批量购买'], price: [{ id: 'SUGAR_CANE', amount: 4 }] },
        { type: 'vanilla', id: 'WHEAT_SEEDS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 1 }] },
        { type: 'vanilla', id: 'PUMPKIN_SEEDS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'MELON_SEEDS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'BEETROOT_SEEDS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'TORCHFLOWER_SEEDS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'PITCHER_POD', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'NETHER_WART', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'WHEAT', lines: ['§f------§a§l点击购买§f------', '§a售价：8个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 8 }] },
        { type: 'vanilla', id: 'PUMPKIN', lines: ['§f------§a§l点击购买§f------', '§a售价：8个南瓜种子', '§eShift+点击批量购买'], price: [{ id: 'PUMPKIN_SEEDS', amount: 8 }] },
        { type: 'vanilla', id: 'MELON', lines: ['§f------§a§l点击购买§f------', '§a售价：8个西瓜种子', '§eShift+点击批量购买'], price: [{ id: 'MELON_SEEDS', amount: 8 }] },
        { type: 'vanilla', id: 'BEETROOT', lines: ['§f------§a§l点击购买§f------', '§a售价：8个甜菜种子', '§eShift+点击批量购买'], price: [{ id: 'BEETROOT_SEEDS', amount: 8 }] },
        { type: 'vanilla', id: 'SUGAR_CANE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 1 }] },
        { type: 'vanilla', id: 'POISONOUS_POTATO', lines: ['§f------§a§l点击购买§f------', '§a售价：8个马铃薯', '§eShift+点击批量购买'], price: [{ id: 'POTATO', amount: 8 }] },
        { type: 'vanilla', id: 'CACTUS', lines: ['§f------§a§l点击购买§f------', '§a售价：4个沙子', '§eShift+点击批量购买'], price: [{ id: 'SAND', amount: 4 }] },
        { type: 'vanilla', id: 'SEA_PICKLE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个甘蔗', '§eShift+点击批量购买'], price: [{ id: 'SUGAR_CANE', amount: 8 }] },
        { type: 'vanilla', id: 'COCOA_BEANS', lines: ['§f------§a§l点击购买§f------', '§a售价：1个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 1 }] },
        { type: 'vanilla', id: 'TURTLE_SCUTE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个甘蔗', '§eShift+点击批量购买'], price: [{ id: 'SUGAR_CANE', amount: 8 }] },
        { type: 'vanilla', id: 'NAME_TAG', lines: ['§f------§a§l点击购买§f------', '§a售价：8个纸', '§eShift+点击批量购买'], price: [{ id: 'PAPER', amount: 8 }] },
        { type: 'vanilla', id: 'LAVA_BUCKET', lines: ['§f------§a§l点击购买§f------', '§a售价：1个黑曜石 + 1个桶', '§eShift+点击批量购买'], price: [{ id: 'OBSIDIAN', amount: 1 }, { id: 'BUCKET', amount: 1 }] },
        { type: 'vanilla', id: 'WATER_BUCKET', lines: ['§f------§a§l点击购买§f------', '§a售价：1个桶', '§eShift+点击批量购买'], price: [{ id: 'BUCKET', amount: 1 }] },
        { type: 'vanilla', id: 'MILK_BUCKET', lines: ['§f------§a§l点击购买§f------', '§a售价：1个生牛肉 + 1个桶', '§eShift+点击批量购买'], price: [{ id: 'BEEF', amount: 1 }, { id: 'BUCKET', amount: 1 }] },
        { type: 'vanilla', id: 'EGG', lines: ['§f------§a§l点击购买§f------', '§a售价：1个生鸡肉', '§eShift+点击批量购买'], price: [{ id: 'CHICKEN', amount: 1 }] },
        { type: 'vanilla', id: 'CHORUS_FRUIT', lines: ['§f------§a§l点击购买§f------', '§a售价：8个末地石', '§eShift+点击批量购买'], price: [{ id: 'END_STONE', amount: 8 }] },
        { type: 'vanilla', id: 'BELL', lines: ['§f------§a§l点击购买§f------', '§a售价：8个金锭', '§eShift+点击批量购买'], price: [{ id: 'GOLD_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'NAUTILUS_SHELL', lines: ['§f------§a§l点击购买§f------', '§a售价：8个铜锭', '§eShift+点击批量购买'], price: [{ id: 'COPPER_INGOT', amount: 8 }] }
    ],
    方块: [
        { type: 'vanilla', id: 'STONE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 1 }] },
        { type: 'vanilla', id: 'GRASS_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：8个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 8 }] },
        { type: 'vanilla', id: 'PODZOL', lines: ['§f------§a§l点击购买§f------', '§a售价：8个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 8 }] },
        { type: 'vanilla', id: 'MYCELIUM', lines: ['§f------§a§l点击购买§f------', '§a售价：8个泥土', '§eShift+点击批量购买'], price: [{ id: 'DIRT', amount: 8 }] },
        { type: 'vanilla', id: 'GRAVEL', lines: ['§f------§a§l点击购买§f------', '§a售价：2个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 2 }] },
        { type: 'vanilla', id: 'COBBLED_DEEPSLATE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 1 }] },
        { type: 'vanilla', id: 'ICE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个水桶', '§eShift+点击批量购买'], price: [{ id: 'WATER_BUCKET', amount: 1 }] },
        { type: 'vanilla', id: 'CALCITE', lines: ['§f------§a§l点击购买§f------', '§a售价：32个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 32 }] },
        { type: 'vanilla', id: 'TUFF', lines: ['§f------§a§l点击购买§f------', '§a售价：32个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 32 }] },
        { type: 'vanilla', id: 'OBSIDIAN', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'CRYING_OBSIDIAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个黑曜石', '§eShift+点击批量购买'], price: [{ id: 'OBSIDIAN', amount: 1 }] },
        { type: 'vanilla', id: 'CRIMSON_NYLIUM', lines: ['§f------§a§l点击购买§f------', '§a售价：16个下界岩', '§eShift+点击批量购买'], price: [{ id: 'NETHERRACK', amount: 16 }] },
        { type: 'vanilla', id: 'WARPED_NYLIUM', lines: ['§f------§a§l点击购买§f------', '§a售价：16个下界岩', '§eShift+点击批量购买'], price: [{ id: 'NETHERRACK', amount: 16 }] },
        { type: 'vanilla', id: 'SOUL_SAND', lines: ['§f------§a§l点击购买§f------', '§a售价：2个沙子', '§eShift+点击批量购买'], price: [{ id: 'SAND', amount: 2 }] },
        { type: 'vanilla', id: 'BLACKSTONE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 4 }] },
        { type: 'vanilla', id: 'BASALT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 4 }] },
        { type: 'vanilla', id: 'END_STONE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 4 }] },
        { type: 'vanilla', id: 'GLOWSTONE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 4 }] },
        { type: 'vanilla', id: 'SEA_LANTERN', lines: ['§f------§a§l点击购买§f------', '§a售价：8个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 8 }] },
        { type: 'vanilla', id: 'BUDDING_AMETHYST', lines: ['§f------§a§l点击购买§f------', '§a售价：8个紫水晶碎片', '§eShift+点击批量购买'], price: [{ id: 'AMETHYST_SHARD', amount: 8 }] },
        { type: 'vanilla', id: 'SHROOMLIGHT', lines: ['§f------§a§l点击购买§f------', '§a售价：16个下界岩', '§eShift+点击批量购买'], price: [{ id: 'NETHERRACK', amount: 16 }] },
        { type: 'vanilla', id: 'COAL_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 8 }] },
        { type: 'vanilla', id: 'LAPIS_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个青金石', '§eShift+点击批量购买'], price: [{ id: 'LAPIS_LAZULI', amount: 8 }] },
        { type: 'vanilla', id: 'REDSTONE_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个红石粉', '§eShift+点击批量购买'], price: [{ id: 'REDSTONE', amount: 8 }] },
        { type: 'vanilla', id: 'IRON_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个铁锭', '§eShift+点击批量购买'], price: [{ id: 'IRON_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'GOLD_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个金锭', '§eShift+点击批量购买'], price: [{ id: 'GOLD_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'DIAMOND_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个钻石', '§eShift+点击批量购买'], price: [{ id: 'DIAMOND', amount: 8 }] },
        { type: 'vanilla', id: 'EMERALD_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个绿宝石', '§eShift+点击批量购买'], price: [{ id: 'EMERALD', amount: 8 }] },
        { type: 'vanilla', id: 'COPPER_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个铜锭', '§eShift+点击批量购买'], price: [{ id: 'COPPER_INGOT', amount: 8 }] },
        { type: 'vanilla', id: 'NETHER_QUARTZ_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：8个下界石英', '§eShift+点击批量购买'], price: [{ id: 'QUARTZ', amount: 8 }] },
        { type: 'vanilla', id: 'OCHRE_FROGLIGHT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个海晶灯', '§eShift+点击批量购买'], price: [{ id: 'SEA_LANTERN', amount: 2 }] },
        { type: 'vanilla', id: 'VERDANT_FROGLIGHT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个海晶灯', '§eShift+点击批量购买'], price: [{ id: 'SEA_LANTERN', amount: 2 }] },
        { type: 'vanilla', id: 'PEARLESCENT_FROGLIGHT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个海晶灯', '§eShift+点击批量购买'], price: [{ id: 'SEA_LANTERN', amount: 2 }] },
        { type: 'vanilla', id: 'DIRT', lines: ['§f------§a§l点击购买§f------', '§a售价：1个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 1 }] },
        { type: 'vanilla', id: 'MAGMA_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：8个下界岩', '§eShift+点击批量购买'], price: [{ id: 'NETHERRACK', amount: 8 }] }
    ],
    海洋: [
        { type: 'vanilla', id: 'TUBE_CORAL_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'BRAIN_CORAL_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'BUBBLE_CORAL_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'FIRE_CORAL_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'HORN_CORAL_BLOCK', lines: ['§f------§a§l点击购买§f------', '§a售价：64个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 64 }] },
        { type: 'vanilla', id: 'SEAGRASS', lines: ['§f------§a§l点击购买§f------', '§a售价：16个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 16 }] },
        { type: 'vanilla', id: 'KELP', lines: ['§f------§a§l点击购买§f------', '§a售价：16个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 16 }] },
        { type: 'vanilla', id: 'TUBE_CORAL', lines: ['§f------§a§l点击购买§f------', '§a售价：1个管珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'TUBE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'BRAIN_CORAL', lines: ['§f------§a§l点击购买§f------', '§a售价：1个脑纹珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'BRAIN_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'BUBBLE_CORAL', lines: ['§f------§a§l点击购买§f------', '§a售价：1个气泡珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'BUBBLE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'FIRE_CORAL', lines: ['§f------§a§l点击购买§f------', '§a售价：1个火珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'FIRE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'HORN_CORAL', lines: ['§f------§a§l点击购买§f------', '§a售价：1个鹿角珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'HORN_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'SEA_PICKLE', lines: ['§f------§a§l点击购买§f------', '§a售价：16个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 16 }] },
        { type: 'vanilla', id: 'LILY_PAD', lines: ['§f------§a§l点击购买§f------', '§a售价：16个小麦种子', '§eShift+点击批量购买'], price: [{ id: 'WHEAT_SEEDS', amount: 16 }] },
        { type: 'vanilla', id: 'TUBE_CORAL_FAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个管珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'TUBE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'BRAIN_CORAL_FAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个脑纹珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'BRAIN_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'BUBBLE_CORAL_FAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个气泡珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'BUBBLE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'FIRE_CORAL_FAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个火珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'FIRE_CORAL_BLOCK', amount: 1 }] },
        { type: 'vanilla', id: 'HORN_CORAL_FAN', lines: ['§f------§a§l点击购买§f------', '§a售价：1个鹿角珊瑚块', '§eShift+点击批量购买'], price: [{ id: 'HORN_CORAL_BLOCK', amount: 1 }] }
    ],
    粘液科技: [
        { type: 'slimefun', id: 'SIFTED_ORE', lines: ['§f------§a§l点击购买§f------', '§a售价：4个沙砾', '§eShift+点击批量购买'], price: [{ id: 'GRAVEL', amount: 4 }] },
        { type: 'slimefun', id: 'STONE_CHUNK', lines: ['§f------§a§l点击购买§f------', '§a售价：1个石头', '§eShift+点击批量购买'], price: [{ id: 'STONE', amount: 1 }] },
        { type: 'slimefun', id: 'COMPRESSED_CARBON', lines: ['§f------§a§l点击购买§f------', '§a售价：1个钻石', '§eShift+点击批量购买'], price: [{ id: 'DIAMOND', amount: 1 }] },
        { type: 'slimefun', id: 'SILICON', lines: ['§f------§a§l点击购买§f------', '§a售价：4个下界石英', '§eShift+点击批量购买'], price: [{ id: 'QUARTZ', amount: 4 }] },
        { type: 'slimefun', id: 'COPPER_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'IRON_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'GOLD_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'ALUMINUM_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'SILVER_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'TIN_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'LEAD_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'ZINC_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'MAGNESIUM_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：1个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 1 }] },
        { type: 'slimefun', id: 'SULFATE', lines: ['§f------§a§l点击购买§f------', '§a售价：1个岩浆块', '§eShift+点击批量购买'], price: [{ id: 'MAGMA_BLOCK', amount: 1 }] },
        { type: 'slimefun', id: 'ELECTRO_MAGNET', lines: ['§f------§a§l点击购买§f------', '§a售价：11个铁粉 + 8个铜粉 + 1个铝粉', '§a售价：+ 2个锌粉 + 2个硫酸盐 + 1个红石粉', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 11 }, { id: 'COPPER_DUST', amount: 8 }, { id: 'ALUMINUM_DUST', amount: 1 }, { id: 'ZINC_DUST', amount: 2 }, { id: 'SULFATE', amount: 2 }, { id: 'REDSTONE', amount: 1 }] },
        { type: 'slimefun', id: 'ELECTRIC_MOTOR', lines: ['§f------§a§l点击购买§f------', '§a售价：11个铁粉 + 11个铜粉 + 1个铝粉', '§a售价：+ 2个锌粉 + 2个硫酸盐 + 1个红石粉', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 11 }, { id: 'COPPER_DUST', amount: 11 }, { id: 'ALUMINUM_DUST', amount: 1 }, { id: 'ZINC_DUST', amount: 2 }, { id: 'SULFATE', amount: 2 }, { id: 'REDSTONE', amount: 1 }] },
        { type: 'slimefun', id: 'HEATING_COIL', lines: ['§f------§a§l点击购买§f------', '§a售价：11个铁粉 + 14个铜粉 + 1个铝粉', '§a售价：+ 2个锌粉 + 2个硫酸盐 + 1个红石粉', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 11 }, { id: 'COPPER_DUST', amount: 8 }, { id: 'ALUMINUM_DUST', amount: 1 }, { id: 'ZINC_DUST', amount: 2 }, { id: 'SULFATE', amount: 2 }, { id: 'REDSTONE', amount: 1 }] },
        { type: 'slimefun', id: 'BASIC_CIRCUIT_BOARD', lines: ['§f------§a§l点击购买§f------', '§a售价：36个铁锭 + 8个泥土', '§eShift+点击批量购买'], price: [{ id: 'IRON_INGOT', amount: 36 }, { id: 'DIRT', amount: 8 }] },
        { type: 'slimefun', id: 'MAGIC_LUMP_3', lines: ['§f------§a§l点击购买§f------', '§a售价：8个下界疣', '§eShift+点击批量购买'], price: [{ id: 'NETHER_WART', amount: 8 }] },
        { type: 'slimefun', id: 'ENDER_LUMP_3', lines: ['§f------§a§l点击购买§f------', '§a售价：8个末影之眼', '§eShift+点击批量购买'], price: [{ id: 'ENDER_EYE', amount: 8 }] },
        { type: 'slimefun', id: 'LENGSHANG_MTXJ', lines: ['§f------§a§l点击购买§f------', '§a售价：8个强化合金锭 + 8个电磁铁', '§eShift+点击批量购买'], price: [{ id: 'REINFORCED_ALLOY_INGOT', amount: 8 }, { id: 'ELECTRO_MAGNET', amount: 8 }] },
        { type: 'slimefun', id: 'DYNATECH_VEX_GEM', lines: ['§f------§a§l点击购买§f------', '§a售价：8个绿宝石块', '§eShift+点击批量购买'], price: [{ id: 'EMERALD_BLOCK', amount: 8 }] }
    ],
    合成锭: [
        { type: 'slimefun', id: 'STEEL_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：8个煤炭 + 2个铁粉', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 8 }, { id: 'IRON_DUST', amount: 2 }] },
        { type: 'slimefun', id: 'DAMASCUS_STEEL_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：16个煤炭 + 4个铁粉', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 16 }, { id: 'IRON_DUST', amount: 4 }] },
        { type: 'slimefun', id: 'BRONZE_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铜粉 + 1个锡粉', '§eShift+点击批量购买'], price: [{ id: 'COPPER_DUST', amount: 2 }, { id: 'TIN_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'BRASS_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铜粉 + 1个锌粉', '§eShift+点击批量购买'], price: [{ id: 'COPPER_DUST', amount: 2 }, { id: 'ZINC_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'DURALUMIN_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铝粉 + 1个铜粉', '§eShift+点击批量购买'], price: [{ id: 'ALUMINUM_DUST', amount: 2 }, { id: 'COPPER_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'BILLON_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个银粉 + 1个铜粉', '§eShift+点击批量购买'], price: [{ id: 'SILVER_DUST', amount: 2 }, { id: 'COPPER_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'SOLDER_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铅粉 + 1个锡粉', '§eShift+点击批量购买'], price: [{ id: 'LEAD_DUST', amount: 2 }, { id: 'TIN_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'NICKEL_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铁粉 + 1个铜粉', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 2 }, { id: 'COPPER_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'COBALT_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：3个铁粉 + 2个铜粉', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 3 }, { id: 'COPPER_DUST', amount: 2 }] },
        { type: 'slimefun', id: 'FERROSILICON', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铁粉 + 4个下界石英', '§eShift+点击批量购买'], price: [{ id: 'IRON_DUST', amount: 2 }, { id: 'QUARTZ', amount: 4 }] },
        { type: 'slimefun', id: 'ALUMINUM_BRASS_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铝粉 + 2个铜粉 + 1个锌粉', '§eShift+点击批量购买'], price: [{ id: 'ALUMINUM_DUST', amount: 2 }, { id: 'COPPER_DUST', amount: 2 }, { id: 'ZINC_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'ALUMINUM_BRONZE_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铝粉 + 2个铜粉 + 1个锡粉', '§eShift+点击批量购买'], price: [{ id: 'ALUMINUM_DUST', amount: 2 }, { id: 'COPPER_DUST', amount: 2 }, { id: 'TIN_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'CORINTHIAN_BRONZE_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：3个铜粉 + 1个锡粉 + 1个金粉 + 1个银粉', '§eShift+点击批量购买'], price: [{ id: 'COPPER_DUST', amount: 3 }, { id: 'TIN_DUST', amount: 1 }, { id: 'GOLD_DUST', amount: 1 }, { id: 'SILVER_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'GOLD_24K', lines: ['§f------§a§l点击购买§f------', '§a售价：11个金粉', '§eShift+点击批量购买'], price: [{ id: 'GOLD_DUST', amount: 11 }] },
        { type: 'slimefun', id: 'GILDED_IRON', lines: ['§f------§a§l点击购买§f------', '§a售价：11个金粉 + 1个铁粉', '§eShift+点击批量购买'], price: [{ id: 'GOLD_DUST', amount: 11 }, { id: 'IRON_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'MAGSTEEL', lines: ['§f------§a§l点击购买§f------', '§a售价：2个镁粉 + 2个铁粉 + 8个煤炭', '§eShift+点击批量购买'], price: [{ id: 'MAGNESIUM_DUST', amount: 2 }, { id: 'IRON_DUST', amount: 2 }, { id: 'COAL', amount: 8 }] },
        { type: 'slimefun', id: 'HARDENED_METAL_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：4个铁粉 + 4个铝粉 + 3个铜粉 + 1个锡粉', '§a售价：+ 48个煤炭', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 48 }, { id: 'IRON_DUST', amount: 4 }, { id: 'ALUMINUM_DUST', amount: 4 }, { id: 'COPPER_DUST', amount: 3 }, { id: 'TIN_DUST', amount: 1 }] },
        { type: 'slimefun', id: 'REDSTONE_ALLOY', lines: ['§f------§a§l点击购买§f------', '§a售价：6个铁粉 + 4个铝粉 + 3个铜粉 + 1个锡粉', '§a售价：+ 48个煤炭 + 10个红石粉 + 4个下界石英', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 48 }, { id: 'IRON_DUST', amount: 4 }, { id: 'ALUMINUM_DUST', amount: 4 }, { id: 'COPPER_DUST', amount: 3 }, { id: 'TIN_DUST', amount: 1 }, { id: 'REDSTONE', amount: 10 }, { id: 'QUARTZ', amount: 4 }] },
        { type: 'slimefun', id: 'REINFORCED_ALLOY_INGOT', lines: ['§f------§a§l点击购买§f------', '§a售价：64个煤炭 + 12个金粉 + 8个铁粉 + 7个铜粉', '§a售价：+ 4个铝粉 + 3个银粉 + 3个锡粉 + 2个铅粉', '§eShift+点击批量购买'], price: [{ id: 'COAL', amount: 64 }, { id: 'GOLD_DUST', amount: 12 }, { id: 'IRON_DUST', amount: 8 }, { id: 'COPPER_DUST', amount: 7 }, { id: 'ALUMINUM_DUST', amount: 4 }, { id: 'SILVER_DUST', amount: 3 }, { id: 'TIN_DUST', amount: 3 }, { id: 'LEAD_DUST', amount: 2 }] },
        { type: 'slimefun', id: 'URANIUM', lines: ['§f------§a§l点击购买§f------', '§a售价：36个筛矿', '§eShift+点击批量购买'], price: [{ id: 'SIFTED_ORE', amount: 36 }] },
        { type: 'slimefun', id: 'SYNTHETIC_SAPPHIRE', lines: ['§f------§a§l点击购买§f------', '§a售价：2个铝粉 + 2个玻璃 + 1个青金石', '§eShift+点击批量购买'], price: [{ id: 'ALUMINUM_DUST', amount: 2 }, { id: 'GLASS', amount: 2 }, { id: 'LAPIS_LAZULI', amount: 1 }] },
        { type: 'slimefun', id: 'SYNTHETIC_EMERALD', lines: ['§f------§a§l点击购买§f------', '§a售价：4个铝粉 + 3个玻璃 + 1个青金石', '§eShift+点击批量购买'], price: [{ id: 'ALUMINUM_DUST', amount: 4 }, { id: 'GLASS', amount: 3 }, { id: 'LAPIS_LAZULI', amount: 1 }] },
        { type: 'slimefun', id: 'SYNTHETIC_DIAMOND', lines: ['§f------§a§l点击购买§f------', '§a售价：8个钻石', '§eShift+点击批量购买'], price: [{ id: 'DIAMOND', amount: 8 }] },
        { type: 'slimefun', id: 'CARBONADO', lines: ['§f------§a§l点击购买§f------', '§a售价：8个钻石 + 1个玻璃', '§eShift+点击批量购买'], price: [{ id: 'DIAMOND', amount: 8 }, { id: 'GLASS', amount: 1 }] }
    ],
    制造: [
        { type: 'slimefun', id: '_FINALTECH_UNORDERED_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：172个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 172 }] },
        { type: 'slimefun', id: '_FINALTECH_ORDERED_DUST', lines: ['§f------§a§l点击购买§f------', '§a售价：171个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 171 }] },
        { type: 'slimefun', id: 'MOMOTECH_CREATIVE', lines: ['§f------§a§l点击购买§f------', '§a售价：135个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 135 }] },
        { type: 'slimefun', id: 'MOMOTECH_CREATIVE_I', lines: ['§f------§a§l点击购买§f------', '§a售价：135个圆石', '§eShift+点击批量购买'], price: [{ id: 'COBBLESTONE', amount: 135 }] }
    ]
};

// ============================================
// 核心逻辑代码（已整合批量购买、冷却、背包检查等功能）
// ============================================

const Bukkit = Java.type('org.bukkit.Bukkit');
const Material = Java.type('org.bukkit.Material');
const ItemStack = Java.type('org.bukkit.inventory.ItemStack');
const ClickEvent = Java.type('org.bukkit.event.inventory.InventoryClickEvent');
const CloseEvent = Java.type('org.bukkit.event.inventory.InventoryCloseEvent');
const EventPriority = Java.type('org.bukkit.event.EventPriority');
const plugin = Java.type('org.lins.mmmjjkx.rykenslimefuncustomizer.RykenSlimefunCustomizer').INSTANCE;
const SlimefunItem = Java.type('io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem');
const Listener = Java.type('org.bukkit.event.Listener');
const Consumer = Java.type('java.util.function.Consumer');

// 冷却机制
const COOLDOWN_MAP = new java.util.HashMap();
const COOLDOWN_MS = 500;

function isOnCooldown(player) {
    const last = COOLDOWN_MAP.get(player);
    if (!last) return false;
    const now = Date.now();
    if (now - last < COOLDOWN_MS) return true;
    COOLDOWN_MAP.remove(player);
    return false;
}

function setCooldown(player) {
    COOLDOWN_MAP.put(player, Date.now());
}

/**
 * 创建基础物品
 */
function item(mat, name, lore) {
    const it = new ItemStack(Material.getMaterial(mat));
    const meta = it.getItemMeta();
    meta.setDisplayName(name);
    if (lore) meta.setLore(Array.isArray(lore) ? lore : [lore]);
    it.setItemMeta(meta);
    return it;
}

function borderItem() { return item('PINK_STAINED_GLASS_PANE', '§6 '); }

function applyBorder(inv) {
    const b = borderItem();
    BORDER_SLOTS.forEach(s => inv.setItem(s, b.clone()));
}

/**
 * 检查玩家是否拥有足够的支付物品（支持原版 + Slimefun）
 * @param {Player} player 
 * @param {Array} priceList - 价格列表 [{id, amount}, ...]
 * @param {number} multiplier - 倍数（批量购买）
 */
function hasEnough(player, priceList, multiplier) {
    const inventory = player.getInventory();
    for (let price of priceList) {
        let needed = price.amount * multiplier;
        let total = 0;
        const targetMat = Material.getMaterial(price.id);

        for (let i = 0; i < inventory.getSize(); i++) {
            const stack = inventory.getItem(i);
            if (!stack || stack.getType() === Material.AIR) continue;

            const sf = SlimefunItem.getByItem(stack);
            if (sf && sf.getId() === price.id) {
                total += stack.getAmount();
            } else if (targetMat && stack.getType() === targetMat && !sf) {
                total += stack.getAmount();
            }

            if (total >= needed) break;
        }
        if (total < needed) return false;
    }
    return true;
}
/**
 * 从玩家背包扣除指定物品（支持原版 + Slimefun）
 */
function removeItems(player, priceList, multiplier) {
    for (let price of priceList) {
        let remain = price.amount * multiplier;
        const inv = player.getInventory();
        const targetMat = Material.getMaterial(price.id);

        for (let i = 0; i < inv.getSize() && remain > 0; i++) {
            const stack = inv.getItem(i);
            if (!stack || stack.getType() === Material.AIR) continue;

            let match = false;
            const sf = SlimefunItem.getByItem(stack);
            if (sf && sf.getId() === price.id) {
                match = true;
            } else if (targetMat && stack.getType() === targetMat && !sf) {
                match = true;
            }

            if (!match) continue;

            const amt = stack.getAmount();
            if (amt <= remain) {
                inv.setItem(i, null);
                remain -= amt;
            } else {
                stack.setAmount(amt - remain);
                remain = 0;
            }
        }
    }
}

/**
 * 计算玩家当前背包能支撑的最大购买数量（用于 all 模式）
 * @param {Player} player
 * @param {Array} priceList - 价格列表 [{id, amount}, ...]
 * @returns {number} 最大可购买数量，0 表示材料不足
 */
function calcMaxBuyAmount(player, priceList) {
    let maxAmount = Number.MAX_SAFE_INTEGER;

    for (let price of priceList) {
        let total = 0;
        const inv = player.getInventory();
        const targetMat = Material.getMaterial(price.id);

        for (let i = 0; i < inv.getSize(); i++) {
            const stack = inv.getItem(i);
            if (!stack || stack.getType() === Material.AIR) continue;

            const sf = SlimefunItem.getByItem(stack);
            if (sf && sf.getId() === price.id) {
                total += stack.getAmount();
            } else if (targetMat && stack.getType() === targetMat && !sf) {
                total += stack.getAmount();
            }
        }

        const canBuy = Math.floor(total / price.amount);
        if (canBuy < maxAmount) {
            maxAmount = canBuy;
        }
    }

    return maxAmount === Number.MAX_SAFE_INTEGER ? 0 : maxAmount;
}

/**
 * 发放物品（自动处理堆叠上限，满背包则掉地上）
 */
function giveItems(player, itemProto, amount) {
    const maxStack = itemProto.getMaxStackSize();
    let give = amount;

    while (give > 0) {
        const stackSize = Math.min(maxStack, give);
        const copy = itemProto.clone();
        copy.setAmount(stackSize);
        const left = player.getInventory().addItem(copy);

        if (!left.isEmpty()) {
            const values = left.values();
            const iterator = values.iterator();
            while (iterator.hasNext()) {
                player.getWorld().dropItem(player.getLocation(), iterator.next());
            }
        }
        give -= stackSize;
    }
}

/** 构建主菜单界面 */
function buildMain() {
    const inv = Bukkit.createInventory(null, 54, MAIN_TITLE);
    applyBorder(inv);
    CATEGORIES.forEach(c => inv.setItem(c.slot, item(c.icon, c.name, [c.lore, '', '§a点击查看'])));
    inv.setItem(4, item(INFO_ITEM.material, INFO_ITEM.name, INFO_ITEM.lore));
    inv.setItem(49, item('BARRIER', '§c关闭', '§7关闭菜单'));
    return inv;
}

/**
 * 构建分类子菜单（支持翻页）
 * @param {string} cid - 分类ID
 * @param {number} page - 页码（从0开始）
 */
function catMenu(cid, page) {
    page = page || 0;
    const cat = CATEGORIES.find(c => c.id === cid);
    if (!cat) return null;
    const list = ITEMS[cid];
    if (!list || !list.length) return null;

    const totalPages = Math.ceil(list.length / PAGE_SIZE);
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;

    const inv = Bukkit.createInventory(null, 54, SUB_PRE + cat.name + SUB_SUF);
    applyBorder(inv);

    inv.setItem(4, item('PAPER', '§6' + cat.name + '说明', [
        '§7点击物品购买1个',
        '§7Shift+点击输入批量购买数量',
        '§e第 ' + (page + 1) + '/' + totalPages + ' 页，共' + list.length + '种'
    ]));

    // 翻页按钮（仅在有多页时显示）
    if (totalPages > 1) {
        if (page > 0) {
            inv.setItem(PREV_SLOT, item('ARROW', '§e← 上一页', ['§7点击返回上一页']));
        }
        if (page < totalPages - 1) {
            inv.setItem(NEXT_SLOT, item('ARROW', '§e下一页 →', ['§7点击前往下一页']));
        }
    }

    inv.setItem(49, item('ARROW', '§a返回', '§7返回主菜单'));

    const startIdx = page * PAGE_SIZE;
    const endIdx = Math.min(startIdx + PAGE_SIZE, list.length);

    for (let i = startIdx; i < endIdx; i++) {
        const e = list[i];
        const slot = ITEM_SLOTS[i - startIdx];

        let displayItem = null;
        if (e.type === 'vanilla') {
            const mat = Material.getMaterial(e.id);
            if (mat) {
                displayItem = new ItemStack(mat, 1);
                const meta = displayItem.getItemMeta();
                let lore = meta.getLore() || [];
                e.lines.forEach(l => lore.push(l));
                meta.setLore(lore);
                displayItem.setItemMeta(meta);
            }
        } else {
            const sf = SlimefunItem.getById(e.id);
            if (sf) {
                displayItem = sf.getItem().clone();
                const meta = displayItem.getItemMeta();
                let lore = meta.getLore() || [];
                if (!Array.isArray(lore)) lore = [lore];
                e.lines.forEach(l => lore.push(l));
                meta.setLore(lore);
                displayItem.setItemMeta(meta);
            }
        }

        if (displayItem) {
            inv.setItem(slot, displayItem);
        } else {
            inv.setItem(slot, item('BARRIER', '§c无效物品', ['§7ID: ' + e.id]));
        }
    }

    return inv;
}

// 记录当前打开菜单的玩家集合
const openPlayers = new java.util.HashSet();
const CAT_MAP = new java.util.HashMap();   // Player -> 当前分类ID
const PAGE_MAP = new java.util.HashMap();  // Player -> 当前页码
const PAGE_SWITCHING = new java.util.HashSet();  // 翻页中标记
let registered = false;

/** 确保事件监听器已注册（防止重复注册） */
function ensureListener() {
    if (registered) return;

    const DragEvent = Java.type('org.bukkit.event.inventory.InventoryDragEvent');

    if (plugin.lengshang_gj_qhgui) {
        ClickEvent.getHandlerList().unregister(plugin.lengshang_gj_qhgui);
        CloseEvent.getHandlerList().unregister(plugin.lengshang_gj_qhgui);
        DragEvent.getHandlerList().unregister(plugin.lengshang_gj_qhgui);
        plugin.lengshang_gj_qhgui = null;
    }

    const L = Java.extend(Listener, {});
    const listener = new L();

    // 注册点击事件监听
    Bukkit.getPluginManager().registerEvent(ClickEvent, listener, EventPriority.NORMAL, (l, e) => {
        try {
            const p = e.getWhoClicked();
            if (!openPlayers.contains(p)) return;

            const t = e.getView().getTitle();
            if (t !== MAIN_TITLE && !t.startsWith(SUB_PRE)) return;

            const topInv = e.getView().getTopInventory();
            const clickedInv = e.getClickedInventory();

            // ========== 点击商店上方界面 ==========
            if (clickedInv === topInv) {
                e.setCancelled(true);
                const slot = e.getSlot();
                const it = e.getCurrentItem();
                if (!it || it.getType() === Material.AIR) return;

                // ===== 主菜单逻辑 =====
                if (t === MAIN_TITLE) {
                    const cat = CATEGORIES.find(c => c.slot === slot && it.getItemMeta().getDisplayName() === c.name);
                    if (cat) {
                        CAT_MAP.put(p, cat.id);
                        PAGE_MAP.put(p, 0);
                        const sub = catMenu(cat.id, 0);
                        if (sub) openMenu(p, sub);
                        return;
                    }
                    if (slot === 49 && it.getItemMeta().getDisplayName() === '§c关闭') {
                        p.closeInventory();
                        return;
                    }
                }
                // ===== 子菜单逻辑 =====
                else {
                    // 功能按钮优先判断（翻页/返回）
                    if (slot === 49 && it.getItemMeta().getDisplayName() === '§a返回') {
                        openMain(p);
                        return;
                    }

                    const currentPage = PAGE_MAP.get(p) || 0;
                    const catId = CAT_MAP.get(p);
                    if (!catId) return;

                    if (slot === PREV_SLOT && it.getItemMeta().getDisplayName() === '§e← 上一页') {
                        if (currentPage > 0) {
                            PAGE_MAP.put(p, currentPage - 1);
                            const sub = catMenu(catId, currentPage - 1);
                            if (sub) openMenu(p, sub);
                        }
                        return;
                    }

                    if (slot === NEXT_SLOT && it.getItemMeta().getDisplayName() === '§e下一页 →') {
                        const list = ITEMS[catId];
                        const totalPages = Math.ceil(list.length / PAGE_SIZE);
                        if (currentPage < totalPages - 1) {
                            PAGE_MAP.put(p, currentPage + 1);
                            const sub = catMenu(catId, currentPage + 1);
                            if (sub) openMenu(p, sub);
                        }
                        return;
                    }

                    if (slot === 4 || BORDER_SLOTS.includes(slot)) return;

                    // 基于当前页码查找商品
                    const list = ITEMS[catId];
                    const page = PAGE_MAP.get(p) || 0;
                    let itemIndex = -1;

                    for (let i = 0; i < ITEM_SLOTS.length; i++) {
                        if (ITEM_SLOTS[i] === slot) {
                            itemIndex = page * PAGE_SIZE + i;
                            break;
                        }
                    }

                    if (itemIndex < 0 || itemIndex >= list.length) return;
                    const config = list[itemIndex];
                    if (!config || !config.price) {
                        p.sendMessage('§c价格配置错误');
                        return;
                    }

                    // 检查冷却
                    if (isOnCooldown(p)) {
                        p.sendMessage('§c操作过快，请稍后再试');
                        return;
                    }

                    const isShift = e.isShiftClick();

                    // 获取物品原型
                    let itemProto = null;
                    if (config.type === 'vanilla') {
                        const mat = Material.getMaterial(config.id);
                        if (mat) itemProto = new ItemStack(mat);
                    } else {
                        const sf = SlimefunItem.getById(config.id);
                        if (sf) itemProto = sf.getItem().clone();
                    }

                    if (!itemProto) {
                        p.sendMessage('§c物品配置错误');
                        return;
                    }

                    if (!isShift) {
                        // 普通点击：购买1个
                        if (!hasEnough(p, config.price, 1)) {
                            p.sendMessage('§c材料不足，无法购买');
                            return;
                        }

                        removeItems(p, config.price, 1);
                        giveItems(p, itemProto, 1);
                        p.sendMessage('§a购买成功！');
                        setCooldown(p);
                    } else {
                        // Shift+点击：批量购买模式
                        p.sendMessage('§a请在聊天栏输入购买数量（正整数），或输入 §eall §a购买全部：');
                        if (typeof getChatInput === 'function') {
                            getChatInput(p, new (Java.extend(Consumer, {
                                accept: function (input) {
                                    try {
                                        if (!p.isOnline()) return;
                                        let num;
                                        if (input.trim().toLowerCase() === 'all') {
                                            num = calcMaxBuyAmount(p, config.price);
                                            if (num < 1) {
                                                p.sendMessage('§c材料不足，无法购买');
                                                return;
                                            }
                                            p.sendMessage('§a已自动计算最大可购买数量：§e' + num + ' §a个');
                                        } else {
                                            num = parseInt(input);
                                            if (isNaN(num) || num < 1) {
                                                p.sendMessage('§c请输入大于0的整数，或输入 §eall §c购买全部');
                                                return;
                                            }
                                        }
                                        if (isOnCooldown(p)) {
                                            p.sendMessage('§c操作过快，请稍后再试');
                                            return;
                                        }
                                        if (!hasEnough(p, config.price, num)) {
                                            p.sendMessage('§c材料不足，无法购买');
                                            return;
                                        }

                                        removeItems(p, config.price, num);
                                        giveItems(p, itemProto, num);
                                        p.sendMessage('§a成功购买 ' + num + ' 个！');
                                        setCooldown(p);
                                    } catch (err) {
                                        print("批量购买错误: " + err);
                                    }
                                }
                            })));
                        } else {
                            p.sendMessage('§c错误：服务器不支持聊天栏输入功能');
                        }
                    }
                }
                return;
            }

            // ========== 点击玩家背包/快捷栏 ==========
            if (clickedInv === e.getView().getBottomInventory()) {
                // 禁止 Shift+点击，防止物品被自动送进商店
                if (e.isShiftClick()) {
                    e.setCancelled(true);
                }
                return;
            }
        } catch (err) {
            print("聚宝阁点击错误: " + err);
        }
    }, plugin);

    // 注册关闭事件监听
    Bukkit.getPluginManager().registerEvent(CloseEvent, listener, EventPriority.NORMAL, (l, e) => {
        try {
            const p = e.getPlayer();
            if (PAGE_SWITCHING.contains(p)) {
                return;
            }
            openPlayers.remove(p);
            COOLDOWN_MAP.remove(p);
            CAT_MAP.remove(p);
            PAGE_MAP.remove(p);
            if (openPlayers.isEmpty()) {
                ClickEvent.getHandlerList().unregister(listener);
                CloseEvent.getHandlerList().unregister(listener);
                DragEvent.getHandlerList().unregister(listener);
                plugin.lengshang_gj_qhgui = null;
                registered = false;
            }
        } catch (err) { }
    }, plugin);

    // 注册拖拽事件监听（防止鼠标拖物品进商店）
    Bukkit.getPluginManager().registerEvent(DragEvent, listener, EventPriority.NORMAL, (l, e) => {
        try {
            const p = e.getWhoClicked();
            if (!openPlayers.contains(p)) return;

            const t = e.getView().getTitle();
            if (t !== MAIN_TITLE && !t.startsWith(SUB_PRE)) return;

            const topSize = e.getView().getTopInventory().getSize();
            const rawSlots = e.getRawSlots();
            const itSlots = rawSlots.iterator();
            while (itSlots.hasNext()) {
                if (itSlots.next() < topSize) {
                    e.setCancelled(true);
                    return;
                }
            }
        } catch (err) { }
    }, plugin);

    plugin.lengshang_gj_qhgui = listener;
    registered = true;
}

/** 打开指定菜单并记录玩家 */
function openMenu(p, inv) {
    PAGE_SWITCHING.add(p);
    p.openInventory(inv);
    PAGE_SWITCHING.remove(p);
    openPlayers.add(p);
    ensureListener();
}
/** 打开主菜单 */
function openMain(p) { openMenu(p, buildMain()); }

// ============================================
// RSC 脚本入口函数
// ============================================

/** 按钮组点击回调 */
function onButtonGroupClick(player, slot, clickedItem, clickAction, guideMode) {
    try {
        openMain(player);
        return true;
    } catch (err) {
        player.sendMessage('§c无法打开商店菜单');
        return false;
    }
}

/** 物品使用回调 */
function onUse(e) {
    const p = e.getPlayer();
    try {
        openMain(p);
    } catch (err) {
        p.sendMessage('§c无法打开商店菜单');
    }
    return false;
}