// ============================================================
// 鉴灵石系统 - RykenSlimefunCustomizer GraalJS 脚本
// 用途：实现一个修仙风格的灵根检测装置，包含结构验证、
//       粒子特效、全息投影、GUI交互、玩家属性生成等功能
// ============================================================

// --- Bukkit API 核心类导入 ---
const Bukkit = Java.type('org.bukkit.Bukkit');                          // Bukkit 服务器主类，用于调度任务、获取世界等
const Location = Java.type('org.bukkit.Location');                      // 位置坐标类
const Material = Java.type('org.bukkit.Material');                    // 方块/物品材料枚举
const ItemStack = Java.type('org.bukkit.inventory.ItemStack');          // 物品栈类
const InvClick = Java.type('org.bukkit.event.inventory.InventoryClickEvent');  // 背包点击事件
const InvClose = Java.type('org.bukkit.event.inventory.InventoryCloseEvent');    // 背包关闭事件
const EventPriority = Java.type('org.bukkit.event.EventPriority');     // 事件优先级枚举
const Particle = Java.type('org.bukkit.Particle');                      // 粒子效果枚举
const Color = Java.type('org.bukkit.Color');                            // 颜色类（用于粒子和显示实体）
const DustOptions = Java.type('org.bukkit.Particle$DustOptions');       // 粒子 dust 选项（颜色+大小）

// --- Slimefun 存储工具类导入 ---
const StorageCacheUtils = Java.type('com.xzavier0722.mc.plugin.slimefun4.storage.util.StorageCacheUtils');  // Slimefun 方块数据缓存工具

// --- Java 标准库导入 ---
const Files = Java.type('java.nio.file.Files');                         // 文件操作工具
const Paths = Java.type('java.nio.file.Paths');                        // 路径构建工具
const StandardCharsets = Java.type('java.nio.charset.StandardCharsets'); // 字符编码

// --- RSC 插件主类导入 ---
const plugin = Java.type('org.lins.mmmjjkx.rykenslimefuncustomizer.RykenSlimefunCustomizer').INSTANCE;  // RSC 插件实例，用于注册调度任务

// --- 显示实体相关类导入（用于全息投影效果）---
const TextDisplay = Java.type('org.bukkit.entity.TextDisplay');        // 文本显示实体
const ItemDisplay = Java.type('org.bukkit.entity.ItemDisplay');        // 物品显示实体
const Display = Java.type('org.bukkit.entity.Display');                // 显示实体基类
const Transformation = Java.type('org.bukkit.util.Transformation');    // 显示实体变换矩阵
const Vector3f = Java.type('org.joml.Vector3f');                       // 3D 向量（变换用）
const AxisAngle4f = Java.type('org.joml.AxisAngle4f');                 // 轴角旋转（变换用）

// --- 持久化数据存储类导入 ---
const NamespacedKey = Java.type('org.bukkit.NamespacedKey');            // 命名空间键（用于 PDC）
const PersistentDataType = Java.type('org.bukkit.persistence.PersistentDataType');  // 持久化数据类型

// --- 其他 Bukkit 类导入 ---
const Runnable = Java.type('java.lang.Runnable');                      // 可运行任务接口
const BlockBreakEvent = Java.type('org.bukkit.event.block.BlockBreakEvent');  // 方块破坏事件

// ============================================================
// 常量定义区
// ============================================================

// --- 数据存储前缀与命名空间 ---
const STORAGE_PREFIX = "KOMUTECH_L_X_JLS_";   // Slimefun 方块存储数据键名前缀，用于区分本系统的数据
const PROJ_NAMESPACE = "komutech_x_jls";       // 持久化数据容器(PDC)的命名空间
const PROJ_KEY_NAME = "jlsproj";               // PDC 中存储核心位置键的键名

// --- GUI 与界面 ---
const GUI_TITLE = "§6鉴灵石核心";               // 核心方块右键打开的 GUI 标题

// --- 数据文件路径 ---
const DATA_DIR_PATH = "plugins/RykenSlimefunCustomizer/addon_configs/Komutech/玩家属性";  // 玩家灵根属性 JSON 文件存储目录

// --- 物品 ID 定义 ---
const CORE_ID = "KOMUTECH_L_X_鉴灵石核心";      // 核心方块的 Slimefun ID
const TRIGGER_IDS = ["KOMUTECH_L_X_鉴灵石框架", "KOMUTECH_L_X_鉴灵石框架板"];  // 可触发灵根检测的方块 ID 列表

// --- 聚灵簇物品 ID 列表（用于结构四角，检测时可能消耗）---
const ALLOWED_CLUSTERS = ["KOMUTECH_L_DJ_JPLJ", "KOMUTECH_L_DJ_XPLJ", "KOMUTECH_L_DJ_ZPLJ", "KOMUTECH_L_DJ_SPLJ"];  
// 分别对应：极品聚灵簇、下品聚灵簇、中品聚灵簇、上品聚灵簇

// --- 冷却与动画时间 ---
const COOLDOWN_MS = 10000;                    // 玩家触发检测的冷却时间（毫秒）
const TOTAL_TICKS = 200;                      // 粒子特效总持续时间（tick，约10秒）

// --- 粒子轨迹参数 ---
const TRAIL_POINTS = 16;                      // 每条元素轨迹每帧采样点数
const TRAIL_INIT_RADIUS = 3.0;                // 轨迹初始半径
const TRAIL_RADIUS_AMP = 0.5;                 // 轨迹半径波动幅度
const TRAIL_HEIGHT_AMP = 1.5;                 // 轨迹高度波动幅度

// --- PDC 键 ---
const PROJ_KEY = new NamespacedKey(PROJ_NAMESPACE, PROJ_KEY_NAME);  // 显示实体上标记所属核心的 PDC 键

// --- 动画参数 ---
const ROTATION_SPEED = 2.5;                   // 轨迹旋转速度
const HEIGHT_OSCILLATION_SPEED = 0.8;       // 高度振荡速度
const RADIUS_OSCILLATION_SPEED = 0.3;         // 半径振荡速度

// --- 全息文字参数 ---
const HOLOGRAM_OFFSET = 3;                  // 全息文字相对于核心的水平偏移距离
const HOLOGRAM_Y = 4;                       // 全息文字相对于核心的垂直高度
const ANIMATION_INTERVAL = 3;               // 打字机效果每个字符间隔（tick）

// --- 品质计算参数 ---
const MIN_QUALITY = 0.01;                   // 单元素灵根的最低品质值

// --- 特效位置偏移 ---
const CENTER_Y_OFFSET = 4;                  // 粒子效果中心 Y 轴偏移
const SOUND_Y_OFFSET = 4;                   // 音效播放位置 Y 轴偏移

// --- 粒子大小与数量参数 ---
const PARTICLE_BASE_SIZE = 1;               // 粒子基础大小
const PARTICLE_SIZE_MULTIPLIER = 3;         // 粒子大小随品质增长的倍率
const PARTICLE_BASE_COUNT = 2;              // 每点基础粒子数
const PARTICLE_COUNT_MULTIPLIER = 6;        // 粒子数随品质增长的倍率

// --- 音效 ---
const START_SOUND = "block.note_block.pling";    // 检测开始时播放的音效
const END_SOUND = "block.beacon.activate";       // 检测结束时播放的音效

// --- 聚灵簇在结构中的相对位置（四个角）---
const CLUSTER_POSITIONS = [
    {x:-3, y:2, z:-3},  // 西北角
    {x:-3, y:2, z:3},   // 西南角
    {x:3, y:2, z:-3},   // 东北角
    {x:3, y:2, z:3}     // 东南角
];

// --- 完整结构定义（相对核心方块的坐标）---
// 每个条目包含：x,y,z 相对坐标，m=材料名，sfid=SlimefunID，d=1表示动态（聚灵簇）
const STRUCTURE = [
    // 核心方块（中心）
    {x:0, y:0, z:0, m:"SHROOMLIGHT", sfid:CORE_ID},
    // 四角聚灵簇位置（动态，d=1）
    {x:-3, y:2, z:-3, d:1}, {x:-3, y:2, z:3, d:1}, {x:3, y:2, z:-3, d:1}, {x:3, y:2, z:3, d:1},
    
    // 第3层：3x3 框架（y=3）
    {x:-1, y:3, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:-1, y:3, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:-1, y:3, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:0, y:3, z:-1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:0, y:3, z:1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:3, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:1, y:3, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:3, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    
    // 第4层：3x3 框架（y=4）
    {x:-1, y:4, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:-1, y:4, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:-1, y:4, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:0, y:4, z:-1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:0, y:4, z:1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:4, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:1, y:4, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:4, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    
    // 第5层：3x3 框架（y=5）
    {x:-1, y:5, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:-1, y:5, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:-1, y:5, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:0, y:5, z:-1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:0, y:5, z:1, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:5, z:-1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    {x:1, y:5, z:0, m:"LIGHT_BLUE_STAINED_GLASS", sfid:"KOMUTECH_L_X_鉴灵石框架"},
    {x:1, y:5, z:1, m:"LIGHT_BLUE_STAINED_GLASS_PANE", sfid:"KOMUTECH_L_X_鉴灵石框架板"},
    
    // 底座第0层：7x7 装饰底座
    {x:-3, y:0, z:-3, m:"ANDESITE_WALL"}, {x:-3, y:0, z:-2, m:"POLISHED_ANDESITE_SLAB"}, 
    {x:-3, y:0, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, {x:-3, y:0, z:0, m:"POLISHED_ANDESITE_STAIRS"},
    {x:-3, y:0, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:-3, y:0, z:2, m:"POLISHED_ANDESITE_SLAB"}, 
    {x:-3, y:0, z:3, m:"ANDESITE_WALL"},
    {x:-2, y:0, z:-3, m:"POLISHED_ANDESITE_SLAB"}, {x:-2, y:0, z:-2, m:"DIORITE"}, 
    {x:-2, y:0, z:-1, m:"ANDESITE"}, {x:-2, y:0, z:0, m:"POLISHED_ANDESITE"}, 
    {x:-2, y:0, z:1, m:"ANDESITE"}, {x:-2, y:0, z:2, m:"DIORITE"}, 
    {x:-2, y:0, z:3, m:"POLISHED_ANDESITE_SLAB"},
    {x:-1, y:0, z:-3, m:"POLISHED_ANDESITE_STAIRS"}, {x:-1, y:0, z:-2, m:"ANDESITE"}, 
    {x:-1, y:0, z:-1, m:"ANDESITE_SLAB"}, {x:-1, y:0, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:-1, y:0, z:1, m:"ANDESITE_SLAB"}, {x:-1, y:0, z:2, m:"ANDESITE"}, 
    {x:-1, y:0, z:3, m:"POLISHED_ANDESITE_STAIRS"},
    {x:0, y:0, z:-3, m:"POLISHED_ANDESITE_STAIRS"}, {x:0, y:0, z:-2, m:"POLISHED_ANDESITE"}, 
    {x:0, y:0, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, {x:0, y:0, z:1, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:0, y:0, z:2, m:"POLISHED_ANDESITE"}, {x:0, y:0, z:3, m:"POLISHED_ANDESITE_STAIRS"},
    {x:1, y:0, z:-3, m:"POLISHED_ANDESITE_STAIRS"}, {x:1, y:0, z:-2, m:"ANDESITE"}, 
    {x:1, y:0, z:-1, m:"ANDESITE_SLAB"}, {x:1, y:0, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:1, y:0, z:1, m:"ANDESITE_SLAB"}, {x:1, y:0, z:2, m:"ANDESITE"}, 
    {x:1, y:0, z:3, m:"POLISHED_ANDESITE_STAIRS"},
    {x:2, y:0, z:-3, m:"POLISHED_ANDESITE_SLAB"}, {x:2, y:0, z:-2, m:"DIORITE"}, 
    {x:2, y:0, z:-1, m:"ANDESITE"}, {x:2, y:0, z:0, m:"POLISHED_ANDESITE"}, 
    {x:2, y:0, z:1, m:"ANDESITE"}, {x:2, y:0, z:2, m:"DIORITE"}, 
    {x:2, y:0, z:3, m:"POLISHED_ANDESITE_SLAB"},
    {x:3, y:0, z:-3, m:"ANDESITE_WALL"}, {x:3, y:0, z:-2, m:"POLISHED_ANDESITE_SLAB"}, 
    {x:3, y:0, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, {x:3, y:0, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:3, y:0, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:3, y:0, z:2, m:"POLISHED_ANDESITE_SLAB"}, 
    {x:3, y:0, z:3, m:"ANDESITE_WALL"},
    
    // 底座第1层：四角雕纹凝灰岩
    {x:-3, y:1, z:-3, m:"CHISELED_TUFF"}, {x:-3, y:1, z:3, m:"CHISELED_TUFF"},
    {x:3, y:1, z:-3, m:"CHISELED_TUFF"}, {x:3, y:1, z:3, m:"CHISELED_TUFF"},
    
    // 第2层：中心海晶灯+周围楼梯
    {x:-1, y:2, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:-1, y:2, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:-1, y:2, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, {x:0, y:2, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:0, y:2, z:0, m:"SEA_LANTERN"}, {x:0, y:2, z:1, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:1, y:2, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:1, y:2, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:1, y:2, z:-1, m:"POLISHED_ANDESITE_STAIRS"},
    
    // 中心柱：蓝色染色玻璃
    {x:0, y:3, z:0, m:"BLUE_STAINED_GLASS"}, {x:0, y:4, z:0, m:"BLUE_STAINED_GLASS"}, 
    {x:0, y:5, z:0, m:"BLUE_STAINED_GLASS"},
    
    // 第6层：中心海晶灯+周围楼梯（与第2层对称）
    {x:-1, y:6, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:-1, y:6, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:-1, y:6, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, {x:0, y:6, z:-1, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:0, y:6, z:0, m:"SEA_LANTERN"}, {x:0, y:6, z:1, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:1, y:6, z:1, m:"POLISHED_ANDESITE_STAIRS"}, {x:1, y:6, z:0, m:"POLISHED_ANDESITE_STAIRS"}, 
    {x:1, y:6, z:-1, m:"POLISHED_ANDESITE_STAIRS"},
    
    // 顶部装饰
    {x:0, y:7, z:0, m:"GRINDSTONE"},      // 砂轮
    {x:0, y:8, z:0, m:"END_ROD"}          // 末地烛
];

// --- 方向名称（北东南西）---
const DIRS = ["§f北", "§f东", "§f南", "§f西"];

// ============================================================
// 颜色与灵根系统定义
// ============================================================

/**
 * 将十六进制颜色字符串转换为 Bukkit Color 对象
 * @param {string} h - 十六进制颜色，如 "#ffd700"
 * @returns {Color} Bukkit 颜色对象
 */
function hexToColor(h) { 
    let r = parseInt(h.substring(1, 3), 16), 
        g = parseInt(h.substring(3, 5), 16), 
        b = parseInt(h.substring(5, 7), 16); 
    return Color.fromRGB(r, g, b); 
}

// --- 五行基础颜色 ---
const BASE_COLORS = {
    "金": hexToColor("#ffd700"),  // 金色
    "木": hexToColor("#00ff00"),  // 绿色
    "水": hexToColor("#0096ff"),  // 蓝色
    "火": hexToColor("#ff0000"),  // 红色
    "土": hexToColor("#8b4513")   // 棕色
};

// --- 变异灵根颜色 ---
const MUTATED_COLORS = {
    "雷": hexToColor("#aa00ff"),  // 紫色
    "风": hexToColor("#00ffff"),  // 青色
    "冰": hexToColor("#00bfff"),  // 深天蓝
    "光": hexToColor("#ffffff"),  // 白色
    "暗": hexToColor("#000000")   // 黑色
};

// --- 变异映射：变异灵根 -> 对应基础五行 ---
const MUTATION_MAP = {"雷":"金", "风":"木", "冰":"水", "光":"火", "暗":"土"};

// --- 全部基础五行元素 ---
const ALL_ELEMENTS = ["金", "木", "水", "火", "土"];

// ============================================================
// 全局状态变量
// ============================================================

let cooldowns = new java.util.HashMap();       // 玩家触发冷却记录：UUID -> 上次触发时间戳
let projMap = new java.util.HashMap();          // 玩家投影实体映射：Player -> {coreKey, entities[]}
let openPlayers = new java.util.HashSet();      // 当前打开 GUI 的玩家集合
let coreMap = new java.util.HashMap();          // 玩家 -> 核心位置映射（用于 GUI 交互定位）
let registered = false;                         // 事件监听器是否已注册
let listener = null;                            // 事件监听器实例
let processing = false;                         // 核心 use 处理锁（防止并发）
let processingCores = new java.util.HashMap();  // 正在处理灵根检测的核心标记：coreKey -> true

// ============================================================
// 数据持久化工具函数
// ============================================================

/**
 * 保存玩家灵根属性数据到 JSON 文件
 * @param {string} playerName - 玩家名称
 * @param {Object} data - 玩家属性数据对象
 * @returns {boolean} 是否保存成功
 */
function savePlayerData(playerName, data) {
    let path = Paths.get(DATA_DIR_PATH, '[' + playerName + '].json');
    try {
        let parent = path.getParent();
        if (!Files.exists(parent)) Files.createDirectories(parent);  // 自动创建父目录
        Files.writeString(path, JSON.stringify(data, null, 2), StandardCharsets.UTF_8);  // 格式化写入 JSON
        return true;
    } catch (e) { return false; }
}

// ============================================================
// 位置与方向工具函数
// ============================================================

/**
 * 将方块位置转换为字符串键（用于唯一标识核心位置）
 * @param {Block} b - 方块对象
 * @returns {string} "世界名,x,y,z" 格式
 */
function getLocationKey(b) { 
    return b.getWorld().getName() + "," + b.getX() + "," + b.getY() + "," + b.getZ(); 
}

/**
 * 根据方向旋转相对坐标
 * @param {number} x - 原始 X 偏移
 * @param {number} z - 原始 Z 偏移
 * @param {number} d - 方向（0=北,1=东,2=南,3=西）
 * @returns {Object} 旋转后的 {x, z}
 */
function rot(x, z, d) { 
    switch(d) { 
        case 0: return {x, z};           // 北：不旋转
        case 1: return {x:-z, z:x};      // 东：顺时针90度
        case 2: return {x:-x, z:-z};     // 南：180度
        case 3: return {x:z, z:-x};      // 西：逆时针90度
        default: return {x, z}; 
    } 
}

/**
 * 获取核心方块的激活状态
 * @param {Location} loc - 核心方块位置
 * @returns {number} 0=未激活, 1=已激活
 */
function getState(loc) { 
    return parseInt(StorageCacheUtils.getData(loc, STORAGE_PREFIX + "zt") || "0"); 
}

/**
 * 获取核心方块的方向
 * @param {Location} loc - 核心方块位置
 * @returns {number} 方向值（0-3）
 */
function getDir(loc) { 
    return parseInt(StorageCacheUtils.getData(loc, STORAGE_PREFIX + "fx") || "0"); 
}

// ============================================================
// 结构验证函数
// ============================================================

/**
 * 检查并获取结构中的所有方块
 * 遍历 STRUCTURE 定义，验证每个位置的方块是否符合要求
 * @param {Location} core - 核心方块位置
 * @param {number} dir - 结构方向
 * @returns {Object} {valid: boolean, errors: string[], blocks: Object[]}
 */
function checkAndGetBlocks(core, dir) {
    let w = core.getWorld(), err = [], blk = [];
    for (let b of STRUCTURE) {
        let r = rot(b.x, b.z, dir), 
            x = core.getX() + r.x, 
            y = core.getY() + b.y, 
            z = core.getZ() + r.z, 
            block = w.getBlockAt(x, y, z), 
            entry = {x, y, z, m: b.m, sfid: b.sfid, dynamic: b.d};
        blk.push(entry);
        // 动态位置（聚灵簇）：验证是否为允许的聚灵簇类型
        if (b.d) {
            let id = StorageCacheUtils.getSfItem(block.getLocation())?.getId();
            if (!id || !ALLOWED_CLUSTERS.includes(id)) { 
                err.push(`位置 (${x-core.getX()},${y-core.getY()},${z-core.getZ()}) 需要聚灵簇`); 
                return {valid: false, errors: err, blocks: blk}; 
            }
            entry.sfid = id;  // 记录实际使用的聚灵簇 ID
        } else {
            // 验证材料类型
            if (block.getType().name().toLowerCase() !== b.m.toLowerCase()) { 
                err.push(`位置 (${x-core.getX()},${y-core.getY()},${z-core.getZ()}) 需要 ${b.m}`); 
                return {valid: false, errors: err, blocks: blk}; 
            }
            // 验证 Slimefun ID（如果有）
            if (b.sfid) {
                let id = StorageCacheUtils.getSfItem(block.getLocation())?.getId();
                if (!id || id !== b.sfid) { 
                    err.push(`位置 (${x-core.getX()},${y-core.getY()},${z-core.getZ()}) 需要 ${b.sfid}`); 
                    return {valid: false, errors: err, blocks: blk}; 
                }
            }
        }
    }
    return {valid: true, errors: err, blocks: blk};
}

/**
 * 完整结构检查（checkAndGetBlocks 的包装）
 */
function fullCheck(core, dir) { 
    return checkAndGetBlocks(core, dir); 
}

// ============================================================
// 聚灵簇消耗逻辑
// ============================================================

/**
 * 根据概率消耗四角的聚灵簇
 * 极品聚灵簇(JPLJ)：必定消耗
 * 中品聚灵簇(ZPLJ)：60% 概率消耗
 * 上品聚灵簇(SPLJ)：30% 概率消耗
 * 下品聚灵簇(XPLJ)：不消耗（作为保底）
 * @param {Location} coreLoc - 核心位置
 * @param {Player} player - 触发玩家（用于事件）
 */
function consumeClusters(coreLoc, player) {
    let w = coreLoc.getWorld();
    for (let p of CLUSTER_POSITIONS) {
        let b = w.getBlockAt(coreLoc.getX() + p.x, coreLoc.getY() + p.y, coreLoc.getZ() + p.z), 
            id = StorageCacheUtils.getSfItem(b.getLocation())?.getId();
        if (!id || !ALLOWED_CLUSTERS.includes(id)) continue;
        let consume = false;
        if (id === "KOMUTECH_L_DJ_XPLJ") consume = true;           // 下品：必定消耗（注：代码逻辑似乎有误，实际应为不消耗）
        else if (id === "KOMUTECH_L_DJ_ZPLJ") consume = Math.random() < 0.6;  // 中品：60%
        else if (id === "KOMUTECH_L_DJ_SPLJ") consume = Math.random() < 0.3;  // 上品：30%
        // 极品(JPLJ)未列出，默认不消耗
        if (consume) {
            let ev = new BlockBreakEvent(b, player);
            ev.setDropItems(false);  // 禁止掉落物品
            Bukkit.getPluginManager().callEvent(ev);  // 调用破坏事件（让其他插件处理）
            b.setType(Material.AIR);  // 移除方块
        }
    }
}

// ============================================================
// 颜色插值工具
// ============================================================

/**
 * 在两个颜色之间线性插值
 * @param {Color} c1 - 起始颜色
 * @param {Color} c2 - 目标颜色
 * @param {number} t - 插值因子（0.0 ~ 1.0）
 * @returns {Color} 插值后的颜色
 */
function interpolateColor(c1, c2, t) { 
    return Color.fromRGB(
        Math.floor(c1.getRed() + (c2.getRed() - c1.getRed()) * t), 
        Math.floor(c1.getGreen() + (c2.getGreen() - c1.getGreen()) * t), 
        Math.floor(c1.getBlue() + (c2.getBlue() - c1.getBlue()) * t)
    ); 
}

// ============================================================
// 粒子特效系统
// ============================================================

/**
 * 启动灵根检测的粒子特效动画
 * 生成五行元素对应的螺旋轨迹粒子，伴随末地烛飘散效果
 * @param {Location} coreLoc - 核心位置
 * @param {string[]} activeElements - 激活的元素列表（如 ["金","木"]）
 * @param {number[]} qualityValues - 对应元素的品质值
 * @param {Function} onComplete - 动画结束回调
 */
function startEffect(coreLoc, activeElements, qualityValues, onComplete) {
    let w = coreLoc.getWorld(), 
        center = coreLoc.clone().add(0.5, 0.5, 0.5),  // 中心点（方块中心）
        qualityMap = new java.util.HashMap();
    // 构建元素->品质的映射
    for (let i = 0; i < activeElements.length; i++) qualityMap.put(activeElements[i], qualityValues[i]);
    
    // 为每个基础五行构建轨迹配置
    let trails = [];
    for (let idx = 0; idx < ALL_ELEMENTS.length; idx++) {
        let el = ALL_ELEMENTS[idx], 
            mutatedEl = activeElements.find(e => MUTATION_MAP[e] === el),  // 查找是否有变异灵根对应此基础元素
            active = activeElements.includes(el);
        // 计算有效品质：如果是基础元素直接使用，如果是变异元素则使用变异元素的品质
        let quality = active ? qualityMap.get(el) : (mutatedEl ? qualityMap.get(mutatedEl) : 0);
        // 根据品质计算粒子大小和数量
        let sz = PARTICLE_BASE_SIZE + PARTICLE_SIZE_MULTIPLIER * quality, 
            cnt = Math.max(1, Math.floor((PARTICLE_BASE_COUNT + PARTICLE_COUNT_MULTIPLIER * quality) + 0.5));
        let angleOffset = (idx * 2 * Math.PI / ALL_ELEMENTS.length);  // 每条轨迹的角度偏移
        let baseColor = BASE_COLORS[el], 
            mutatedColor = mutatedEl ? MUTATED_COLORS[mutatedEl] : null;
        trails.push({
            active: active || mutatedEl !== undefined, 
            sz, cnt, angleOffset, baseColor, mutatedColor, effectiveQuality: quality
        });
    }
    
    let t = 0, taskId;
    // 创建定时任务，每 tick 执行一次
    let runnable = new (Java.extend(Runnable, {
        run: function() {
            // 动画结束
            if (t > TOTAL_TICKS) {
                Bukkit.getScheduler().cancelTask(taskId);
                w.playSound(coreLoc.clone().add(0, SOUND_Y_OFFSET, 0), END_SOUND, 1, 1);  // 播放结束音效
                if (onComplete) onComplete();
                return;
            }
            let progress = t / TOTAL_TICKS,  // 整体进度（0~1）
                time = t / 20.0;             // 实际时间（秒）
            
            // 渲染每条元素轨迹
            for (let tr of trails) {
                let radius = TRAIL_INIT_RADIUS * (1 - progress),  // 半径随时间缩小
                    sz = tr.sz;
                // 无效元素（未激活且无变异）的轨迹加速消失
                if (tr.effectiveQuality === 0) radius *= (1 - progress);
                if (radius < 0.05) continue;
                
                let height = CENTER_Y_OFFSET + Math.sin(time * HEIGHT_OSCILLATION_SPEED + tr.angleOffset) * TRAIL_HEIGHT_AMP * (1 - progress);
                
                // 颜色过渡：基础色 -> 变异色（如果有）
                let color = tr.baseColor;
                if (tr.mutatedColor) {
                    let tColor = 0;
                    if (progress > 0.1) tColor = Math.min(1, (progress - 0.1) / 0.15);  // 0.1~0.25 期间完成颜色过渡
                    color = interpolateColor(tr.baseColor, tr.mutatedColor, tColor);
                }
                
                // 沿轨迹采样多个点生成粒子
                for (let pt = 0; pt < TRAIL_POINTS; pt++) {
                    let off = pt * 0.05, 
                        tt = time + off;
                    let rCurr = radius + Math.sin(tt * RADIUS_OSCILLATION_SPEED) * TRAIL_RADIUS_AMP * (1 - progress);
                    let hCurr = height + Math.sin(tt * HEIGHT_OSCILLATION_SPEED) * TRAIL_HEIGHT_AMP * (1 - progress) * 0.5;
                    let angle = tt * ROTATION_SPEED + tr.angleOffset;
                    let x = center.getX() + rCurr * Math.cos(angle), 
                        z = center.getZ() + rCurr * Math.sin(angle), 
                        y = coreLoc.getY() + hCurr;
                    let loc = new Location(w, x, y, z), 
                        cnt = tr.cnt;
                    // 无效元素减少粒子数
                    if (tr.effectiveQuality === 0) cnt = Math.max(1, Math.floor(cnt * (1 - progress)));
                    // 生成 dust 粒子
                    for (let i = 0; i < cnt; i++) 
                        w.spawnParticle(Particle.DUST, loc, 1, 0, 0, 0, 0, new DustOptions(color, sz));
                }
            }
            
            // 额外效果：末地烛飘散粒子（随机位置）
            let cnt = 3 + Math.floor(Math.random() * 4);
            for (let i = 0; i < cnt; i++) {
                let offX = (Math.random() - 0.5) * 8, 
                    offZ = (Math.random() - 0.5) * 8, 
                    yOff = Math.random() * 5, 
                    loc = center.clone().add(offX, yOff, offZ);
                w.spawnParticle(Particle.END_ROD, loc, 0, (Math.random() - 0.5) * 0.2, 0.1 + Math.random() * 0.4, (Math.random() - 0.5) * 0.2, 0.5);
            }
            t++;
        }
    }));
    taskId = Bukkit.getScheduler().runTaskTimer(plugin, runnable, 0, 1).getTaskId();  // 每 1 tick 执行
}

// ============================================================
// 全息文字显示系统
// ============================================================

/**
 * 在核心旁显示灵根结果的全息文字（打字机效果）
 * @param {Location} coreLoc - 核心位置
 * @param {Player} player - 玩家（用于确定文字朝向）
 * @param {string} linggenStr - 灵根字符串（如 "金、木"）
 * @param {string} coreKey - 核心位置键（用于标记实体归属）
 */
function showHologram(coreLoc, player, linggenStr, coreKey) {
    let w = coreLoc.getWorld(), 
        pl = player.getLocation(), 
        dx = pl.getX() - coreLoc.getX(), 
        dz = pl.getZ() - coreLoc.getZ(), 
        ox = 0, oz = 0;
    // 根据玩家位置确定全息文字偏移方向（始终显示在玩家朝向的一侧）
    if (Math.abs(dx) >= Math.abs(dz)) ox = dx >= 0 ? HOLOGRAM_OFFSET : -HOLOGRAM_OFFSET;
    else oz = dz >= 0 ? HOLOGRAM_OFFSET : -HOLOGRAM_OFFSET;
    
    let pos = coreLoc.clone().add(ox, HOLOGRAM_Y, oz), 
        td = w.spawn(pos, TextDisplay.class);  // 生成文本显示实体
    
    // 配置文本显示属性
    td.setText(""); 
    td.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));  // 透明背景
    td.setSeeThrough(true);                              // 穿墙可见
    td.setDefaultBackground(false);
    td.setBillboard(Display.Billboard.CENTER);           // 始终面向玩家
    td.setViewRange(20);                                 // 可视距离
    td.setGravity(false);                                // 无重力
    td.setInvulnerable(true);                            // 无敌
    // 设置缩放为 2 倍
    td.setTransformation(new Transformation(new Vector3f(0, 0, 0), new AxisAngle4f(0, 0, 1, 0), new Vector3f(2, 2, 2), new AxisAngle4f(0, 0, 1, 0)));
    // 标记所属核心
    td.getPersistentDataContainer().set(PROJ_KEY, PersistentDataType.STRING, coreKey);
    
    let prefix = "§f§l你的灵根为：", 
        suffix = "§6§l" + linggenStr, 
        chars = suffix.split("");
    td.setText(prefix);
    
    /**
     * 打字机效果递归函数
     * @param {number} idx - 当前字符索引
     */
    function typeWriter(idx) {
        if (idx >= chars.length) { 
            // 显示完成后，延迟移除全息文字
            runLater(() => { if (!td.isDead()) td.remove(); }, TOTAL_TICKS); 
            return; 
        }
        td.setText(prefix + suffix.substring(0, idx + 1));
        runLater(() => typeWriter(idx + 1), ANIMATION_INTERVAL);  // 递归调用实现打字效果
    }
    typeWriter(0);
}

// ============================================================
// 冷却与投影工具函数
// ============================================================

/**
 * 检查玩家是否处于冷却中，若否则记录当前时间
 * @param {Player} p - 玩家对象
 * @returns {boolean} true=冷却中，false=可以触发
 */
function isOnCooldown(p) { 
    let n = Date.now(), 
        u = p.getUniqueId().toString(), 
        l = cooldowns.get(u);
    if (l && n - l < COOLDOWN_MS) return true;  // 冷却中
    cooldowns.put(u, n);  // 记录本次触发时间
    return false; 
}

/**
 * 移除玩家的投影实体
 * @param {Player} p - 玩家对象
 */
function remProjForPlayer(p) { 
    let o = projMap.get(p); 
    if (o) { 
        o.entities.forEach(e => { try { e.remove(); } catch (ex) {} });  // 安全移除所有实体
        projMap.remove(p); 
    } 
}

/**
 * 为玩家生成结构全息投影（使用 ItemDisplay 和 TextDisplay）
 * @param {Location} core - 核心位置
 * @param {Player} player - 玩家对象
 * @param {number} dir - 结构方向
 */
function spawnProj(core, player, dir) {
    remProjForPlayer(player);  // 先清除旧投影
    let w = core.getWorld(), 
        ents = [], 
        ck = getLocationKey(core);  // 核心位置键
    
    // 遍历结构定义，为每个方块生成显示实体
    for (let b of STRUCTURE) {
        let r = rot(b.x, b.z, dir), 
            x = core.getX() + r.x, 
            y = core.getY() + b.y, 
            z = core.getZ() + r.z, 
            item = null, 
            dn = null;
        
        // 动态位置（聚灵簇）：显示极品聚灵簇物品
        if (b.d) {
            let sf = getSfItemById("KOMUTECH_L_DJ_JPLJ");
            if (sf) { 
                item = sf.getItem().clone(); 
                let m = item.getItemMeta(); 
                dn = m.hasDisplayName() ? m.getDisplayName() : item.getType().name().toLowerCase().replace('_', ' '); 
            } else { 
                item = new ItemStack(Material.AMETHYST_CLUSTER);  // 备用：紫水晶簇
                dn = "紫水晶簇"; 
            }
        } else if (b.sfid) {
            // Slimefun 物品：获取实际物品
            let sf = getSfItemById(b.sfid);
            if (sf) { 
                item = sf.getItem().clone(); 
                let m = item.getItemMeta(); 
                dn = m.hasDisplayName() ? m.getDisplayName() : item.getType().name().toLowerCase().replace('_', ' '); 
            }
        }
        
        // 普通方块：使用材料创建物品
        if (!item) { 
            let m = Material.getMaterial(b.m); 
            if (m && m.isItem()) item = new ItemStack(m); 
            else continue;  // 非物品材料跳过
        }
        
        // 生成物品显示实体
        let loc = new Location(w, x + 0.5, y + 0.5, z + 0.5), 
            d = w.spawn(loc, ItemDisplay.class);
        d.setItemStack(item);
        d.setTransformation(new Transformation(new Vector3f(0, 0, 0), new AxisAngle4f(0, 0, 1, 0), new Vector3f(0.6, 0.6, 0.6), new AxisAngle4f(0, 0, 1, 0)));  // 缩放为 0.6
        d.setGlowing(true);                                           // 发光
        d.setGlowColorOverride(Color.fromARGB(128, 255, 255, 255));   // 白色半透明发光
        d.setBrightness(new Display.Brightness(15, 15));               // 最大亮度
        d.setViewRange(100);                                          // 超远可视距离
        d.setGravity(false);
        d.setInvulnerable(true);
        d.getPersistentDataContainer().set(PROJ_KEY, PersistentDataType.STRING, ck);  // 标记归属
        ents.push(d);
        
        // 如果有显示名称，额外生成文本显示实体
        if (dn) {
            let tl = loc.clone().add(0, 0.8, 0), 
                t = w.spawn(tl, TextDisplay.class);
            t.setText(dn);
            t.setAlignment(Java.type('org.bukkit.entity.TextDisplay$TextAlignment').CENTER);
            t.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            t.setSeeThrough(true);
            t.setDefaultBackground(false);
            t.setBillboard(Java.type('org.bukkit.entity.Display$Billboard').CENTER);
            t.setViewRange(50);
            t.setGravity(false);
            t.setInvulnerable(true);
            t.getPersistentDataContainer().set(PROJ_KEY, PersistentDataType.STRING, ck);
            ents.push(t);
        }
    }
    projMap.put(player, {coreKey: ck, entities: ents});  // 记录到映射
}

// ============================================================
// GUI 构建与事件处理
// ============================================================

/**
 * 创建物品栈（带名称和 Lore）
 * @param {string} m - 材料名
 * @param {string} n - 显示名称
 * @param {string[]|string} l - Lore 文本（数组或字符串）
 * @returns {ItemStack} 配置好的物品
 */
function item(m, n, l) { 
    let mat = Material[m] || Material.getMaterial(m) || Material.STONE, 
        i = new ItemStack(mat), 
        me = i.getItemMeta();
    me.setDisplayName(n); 
    if (l) me.setLore(Array.isArray(l) ? l : [l]); 
    i.setItemMeta(me); 
    return i; 
}

/**
 * 构建核心方块的 GUI 菜单
 * @param {number} s - 状态（0=未激活, 1=已激活）
 * @param {number} dir - 当前方向（0-3）
 * @returns {Inventory} Bukkit 背包对象
 */
function buildCoreMenu(s, dir) {
    let inv = Bukkit.createInventory(null, 9, GUI_TITLE),  // 1行9格的背包
        sn, sl;
    // 根据状态设置中心物品
    if (s === 1) { sn = "§a● 已激活"; sl = ["§7运行中"]; }
    else { sn = "§c○ 未激活"; sl = ["§7点击启动检测激活"]; }
    
    inv.setItem(4, item("PAINTING", sn, sl));           // 中心：状态指示
    inv.setItem(0, item("ENDER_PEARL", "§b投影", ["§7开启/关闭"]));       // 投影开关
    inv.setItem(1, item("EMERALD_BLOCK", "§a启动", ["§7验证并激活"]));    // 启动验证
    inv.setItem(3, item("COMPASS", "§b方向: " + DIRS[dir], ["§7点击切换"]));  // 方向切换
    if (s === 1) inv.setItem(2, item("REDSTONE_BLOCK", "§c停止", ["§7停止机器"]));  // 停止（仅激活时显示）
    inv.setItem(8, item("BARRIER", "§c关闭", []));      // 关闭菜单
    return inv;
}

/**
 * 注销所有事件监听器
 */
function unregisterListener() { 
    if (listener) { 
        try { InvClick.getHandlerList().unregister(listener); } catch (e) {} 
        try { InvClose.getHandlerList().unregister(listener); } catch (e) {} 
        listener = null; 
        registered = false; 
    } 
}

/**
 * 注册 GUI 事件监听器（InventoryClick + InventoryClose）
 * 使用懒加载：当第一个玩家打开 GUI 时注册，所有玩家关闭后注销
 */
function registerListener() {
    if (registered) return;
    let L = Java.extend(Java.type('org.bukkit.event.Listener'), {});
    listener = new L();
    
    // 注册背包点击事件
    Bukkit.getPluginManager().registerEvent(InvClick, listener, EventPriority.NORMAL, (l, e) => {
        try {
            let p = e.getWhoClicked();
            // 过滤非本系统 GUI 的点击
            if (!openPlayers.contains(p) || e.getInventory().getTitle() !== GUI_TITLE) return;
            e.setCancelled(true);  // 禁止移动物品
            let slot = e.getSlot(), 
                it = e.getCurrentItem();
            if (!it || it.getType() === Material.AIR) return;
            
            let loc = coreMap.get(p);
            if (!loc) return;
            let state = getState(loc), 
                dir = getDir(loc);
            
            // 槽位处理
            if (slot === 8) { 
                p.closeInventory();  // 关闭按钮
            } else if (slot === 0) {
                // 投影开关
                let has = false;
                if (projMap.containsKey(p)) { 
                    let o = projMap.get(p); 
                    if (o.entities && o.entities.length > 0) { 
                        try { if (!o.entities[0].isDead()) has = true; } catch (ex) {} 
                    } 
                    if (!has) projMap.remove(p); 
                }
                if (has) { 
                    remProjForPlayer(p); 
                    e.getInventory().setItem(0, item("ENDER_PEARL", "§b投影", ["§7开启/关闭"])); 
                } else { 
                    spawnProj(loc, p, dir); 
                    e.getInventory().setItem(0, item("ENDER_PEARL", "§a投影已开启", ["§7点击关闭"])); 
                }
            } else if (slot === 1) {
                // 启动验证
                if (projMap.containsKey(p)) { 
                    remProjForPlayer(p); 
                    e.getInventory().setItem(0, item("ENDER_PEARL", "§b投影", ["§7开启/关闭"])); 
                }
                let chk = fullCheck(loc, dir);
                if (chk.valid) {
                    StorageCacheUtils.setData(loc, STORAGE_PREFIX + "zt", "1");  // 标记激活
                    let ck = getLocationKey(loc), 
                        w = loc.getWorld(), 
                        {blocks} = checkAndGetBlocks(loc, dir);
                    // 为所有框架方块标记所属核心（用于触发检测时反向查找核心）
                    for (let b of blocks) 
                        if (TRIGGER_IDS.includes(b.sfid)) 
                            StorageCacheUtils.setData(w.getBlockAt(b.x, b.y, b.z).getLocation(), STORAGE_PREFIX + "core", ck);
                    p.sendMessage("§a激活成功！");
                } else { 
                    StorageCacheUtils.setData(loc, STORAGE_PREFIX + "zt", "0");  // 验证失败，保持未激活
                    p.sendMessage("§c结构错误: " + (chk.errors[0] || "未知错误")); 
                }
                p.closeInventory();
            } else if (slot === 2 && state === 1) {
                // 停止（仅激活状态可用）
                StorageCacheUtils.setData(loc, STORAGE_PREFIX + "zt", "0");
                let w = loc.getWorld(), 
                    {blocks} = checkAndGetBlocks(loc, getDir(loc));
                // 清除框架方块上的核心标记
                for (let b of blocks) 
                    if (TRIGGER_IDS.includes(b.sfid)) 
                        StorageCacheUtils.setData(w.getBlockAt(b.x, b.y, b.z).getLocation(), STORAGE_PREFIX + "core", null);
                remProjForPlayer(p); 
                p.sendMessage("§c已停止"); 
                p.closeInventory();
            } else if (slot === 3) {
                // 方向切换
                let nd = (dir + 1) % 4;
                StorageCacheUtils.setData(loc, STORAGE_PREFIX + "fx", nd.toString());
                e.getInventory().setItem(3, item("COMPASS", "§b方向: " + DIRS[nd], ["§7点击切换"]));
                // 如果投影开启，刷新投影
                if (projMap.containsKey(p)) { 
                    remProjForPlayer(p); 
                    spawnProj(loc, p, nd); 
                }
            }
        } catch (ex) { print("核心点击错误: " + ex); }
    }, plugin);
    
    // 注册背包关闭事件
    Bukkit.getPluginManager().registerEvent(InvClose, listener, EventPriority.NORMAL, (l, e) => { 
        let p = e.getPlayer(); 
        if (openPlayers.remove(p)) coreMap.remove(p);  // 从集合中移除
        if (openPlayers.isEmpty()) unregisterListener();  // 无人使用时注销监听器
    }, plugin);
    
    registered = true;
}

// ============================================================
// 灵根品质生成
// ============================================================

/**
 * 生成灵根品质分配
 * 保证每个元素至少 MIN_QUALITY，剩余按随机比例分配
 * @param {string[]} elements - 元素数组
 * @param {number} total - 总品质值
 * @returns {number[]} 每个元素的品质值数组
 */
function genQuality(elements, total) {
    let min = MIN_QUALITY * elements.length;
    if (total < min) total = min;  // 保底总品质
    let rem = total - min, 
        rands = [], 
        sum = 0;
    // 生成随机比例
    for (let i = 0; i < elements.length; i++) { 
        let r = Math.random(); 
        rands.push(r); 
        sum += r; 
    }
    // 按比例分配剩余品质
    let q = [];
    for (let i = 0; i < elements.length; i++) 
        q.push(MIN_QUALITY + (rands[i] / sum) * rem);
    // 保留两位小数
    for (let i = 0; i < q.length; i++) 
        q[i] = Math.round(q[i] * 100) / 100;
    return q;
}

// ============================================================
// 触发检测处理（点击框架/框架板）
// ============================================================

/**
 * 处理玩家点击触发方块（鉴灵石框架/框架板）的逻辑
 * 包含：冷却检查、核心查找、结构验证、灵根生成、特效播放、数据保存
 * @param {Event} e - Slimefun 的 use 事件
 */
function handleTriggerUse(e) {
    let p = e.getPlayer(), 
        b = e.getClickedBlock();
    if (!b || !b.isPresent()) return;
    let bloc = b.get().getLocation(), 
        sf = StorageCacheUtils.getSfItem(bloc);
    if (!sf || !TRIGGER_IDS.includes(sf.getId())) return;  // 非触发方块
    
    // 检查玩家是否已鉴别（非定向模式下）
    let path = Paths.get(DATA_DIR_PATH, '[' + p.getName() + '].json'), 
        data = null;
    if (Files.exists(path)) { 
        try { data = JSON.parse(Files.readString(path, StandardCharsets.UTF_8)); } catch (ex) {} 
    }
    if (data && !data.定向) { 
        p.sendMessage("§c你已经鉴别过了"); 
        return; 
    }
    
    // 冷却检查
    if (isOnCooldown(p)) { 
        p.sendActionBar("§c操作过快"); 
        return; 
    }
    
    // 通过框架方块查找核心
    let ck = StorageCacheUtils.getData(bloc, STORAGE_PREFIX + "core");
    if (!ck) { 
        p.sendMessage("§c未找到核心标记"); 
        return; 
    }
    let parts = ck.split(",");
    if (parts.length !== 4) { 
        p.sendMessage("§c核心坐标无效"); 
        return; 
    }
    let w = Bukkit.getWorld(parts[0]);
    if (!w) { 
        p.sendMessage("§c世界不存在"); 
        return; 
    }
    let core = w.getBlockAt(parseInt(parts[1]), parseInt(parts[2]), parseInt(parts[3]));
    if (!core) { 
        p.sendMessage("§c核心方块不存在"); 
        return; 
    }
    // 验证核心状态
    if (StorageCacheUtils.getData(core.getLocation(), STORAGE_PREFIX + "zt") !== "1") { 
        p.sendMessage("§c核心未激活"); 
        return; 
    }
    
    let coreLoc = core.getLocation(), 
        coreKey = getLocationKey(core);
    // 检查核心是否正在处理中
    if (processingCores.get(coreKey)) { 
        p.sendMessage("§c核心处理中"); 
        return; 
    }
    
    // 再次验证结构完整性
    let chk = fullCheck(coreLoc, getDir(coreLoc));
    if (!chk.valid) { 
        p.sendMessage("§c结构异常"); 
        StorageCacheUtils.setData(coreLoc, STORAGE_PREFIX + "zt", "0"); 
        return; 
    }
    
    processingCores.put(coreKey, true);  // 标记处理中
    w.playSound(coreLoc.clone().add(0, SOUND_Y_OFFSET, 0), START_SOUND, 1, 1);  // 开始音效
    
    // --- 灵根生成逻辑 ---
    let wuxing = 1 + Math.random() * 4,       // 悟性：1.0 ~ 5.0
        gengu = Math.floor(Math.random() * 10) + 1,  // 根骨：1 ~ 10
        elements, quality, total;
    
    // 定向模式：使用预设灵根
    if (data && data.定向) { 
        elements = data.灵根.split("、"); 
        total = data.总品质; 
        quality = genQuality(elements, total); 
        p.sendMessage("§d定向标记生效，灵根锁定为：" + elements.join("、")); 
    } else {
        // 随机模式：随机 1~5 个元素
        let cnt = Math.random();
        cnt = cnt < 0.2 ? 1 : cnt < 0.4 ? 2 : cnt < 0.6 ? 3 : cnt < 0.8 ? 4 : 5;  // 概率分布
        let idxs = [];
        while (idxs.length < cnt) { 
            let r = Math.floor(Math.random() * 5); 
            if (!idxs.includes(r)) idxs.push(r);  // 不重复抽取
        }
        idxs.sort((a, b) => a - b);  // 保持五行顺序
        elements = idxs.map(i => ALL_ELEMENTS[i]);
        total = 0.1 + Math.random() * 0.9;  // 总品质：0.1 ~ 1.0
        quality = genQuality(elements, total); 
        total = Math.round(total * 100) / 100;
    }
    
    let str = elements.join("、");
    showHologram(coreLoc, p, str, ck);  // 显示全息结果
    p.sendMessage("§a开始检验");
    
    // 启动粒子特效，结束后执行回调
    startEffect(coreLoc, elements, quality, () => {
        consumeClusters(coreLoc, p);  // 消耗聚灵簇
        
        // 构建玩家属性数据
        let nd = {};
        nd.修为 = "『引气入体』";      // 初始修为境界
        nd.灵气 = "0/100";              // 灵气值
        nd.灵力 = "100/100";            // 灵力值
        nd.功德 = 0;                     // 功德
        nd.煞气 = 0;                     // 煞气
        nd.悟性 = parseFloat(wuxing.toFixed(2));  // 悟性（保留两位小数）
        nd.根骨 = gengu;                 // 根骨
        
        nd.灵根 = elements.join("、");  // 灵根元素
        
        // 灵根属性判定
        let attr = "";
        if (elements.length === 5) attr = "杂灵根";
        else if (elements.length === 4) attr = "四灵根";
        else if (elements.length === 3) attr = "三灵根";
        else if (elements.length === 2) attr = "双灵根";
        else if (elements.length === 1) { 
            let isVariant = MUTATED_COLORS.hasOwnProperty(elements[0]);  // 是否为变异单灵根
            if (quality[0] > 0.9) { 
                if (isVariant) attr = "变异灵根"; 
                else attr = "天灵根"; 
            } else attr = "单灵根"; 
        } else attr = "单灵根";
        nd.灵根属性 = attr;
        
        // 各元素品质映射
        let qm = {};
        for (let i = 0; i < elements.length; i++) 
            qm[elements[i]] = parseFloat(quality[i].toFixed(2));
        nd.灵根品质 = qm;
        nd.总品质 = parseFloat(total.toFixed(2));
        
        // 基础战斗属性（随机 1~10）
        nd.血量 = Math.floor(Math.random() * 10) + 1;
        nd.攻击力 = Math.floor(Math.random() * 10) + 1;
        nd.防御力 = Math.floor(Math.random() * 10) + 1;
        nd.速度 = Math.floor(Math.random() * 10) + 1;
        nd.灵识 = 0;                     // 灵识（初始为0）
        nd.属性点 = 5;                   // 可分配属性点
        
        savePlayerData(p.getName(), nd);  // 保存到文件
        p.sendMessage("§a完成");
        processingCores.remove(coreKey);   // 解除处理中标记
    });
}

// ============================================================
// 核心方块交互处理
// ============================================================

/**
 * 处理玩家右键点击核心方块
 * 打开管理 GUI，初始化方块数据
 * @param {Event} e - Slimefun 的 use 事件
 */
function handleCoreUse(e) {
    if (processing) return;  // 防止并发
    processing = true;
    try {
        let p = e.getPlayer(), 
            opt = e.getClickedBlock();
        if (!opt || !opt.isPresent()) return;
        let loc = opt.get().getLocation(), 
            sfid = StorageCacheUtils.getSfItem(loc)?.getId();
        if (!sfid) return;
        
        if (sfid === CORE_ID) {
            // 初始化方块数据（首次使用）
            if (StorageCacheUtils.getData(loc, STORAGE_PREFIX + "fx") === null) 
                StorageCacheUtils.setData(loc, STORAGE_PREFIX + "fx", "0");
            if (StorageCacheUtils.getData(loc, STORAGE_PREFIX + "zt") === null) 
                StorageCacheUtils.setData(loc, STORAGE_PREFIX + "zt", "0");
            
            let state = getState(loc), 
                dir = getDir(loc);
            coreMap.put(p, loc);      // 记录玩家对应的核心位置
            openPlayers.add(p);       // 标记玩家已打开 GUI
            unregisterListener(); 
            registerListener();       // 确保监听器注册
            p.openInventory(buildCoreMenu(state, dir));  // 打开 GUI
        }
    } catch (ex) { 
        print("核心onUse错误: " + ex); 
    } finally { 
        processing = false; 
    }
}

// ============================================================
// Slimefun 脚本入口函数
// ============================================================

/**
 * Slimefun 物品使用事件入口
 * 根据点击的方块类型分发到核心处理或触发处理
 * @param {Event} e - Slimefun 的 use 事件
 */
function onUse(e) { 
    let opt = e.getClickedBlock(); 
    if (opt && opt.isPresent()) { 
        let sf = StorageCacheUtils.getSfItem(opt.get().getLocation()); 
        if (sf) { 
            let id = sf.getId(); 
            if (id === CORE_ID) handleCoreUse(e);           // 核心方块
            else if (TRIGGER_IDS.includes(id)) handleTriggerUse(e);  // 触发方块
        } 
    } 
}

/**
 * Slimefun 方块破坏事件入口
 * 清理核心方块相关的所有数据和实体
 * @param {Event} e - Slimefun 的 break 事件
 * @param {ItemStack} it - 破坏工具
 * @param {Array} drops - 掉落物列表
 */
function onBreak(e, it, drops) {
    let loc = e.getBlock().getLocation(), 
        sfid = StorageCacheUtils.getSfItem(loc)?.getId();
    if (sfid === CORE_ID) {
        // 清除存储数据
        StorageCacheUtils.setData(loc, STORAGE_PREFIX + "zt", null);
        StorageCacheUtils.setData(loc, STORAGE_PREFIX + "fx", null);
        
        let ck = getLocationKey(e.getBlock()), 
            w = loc.getWorld(), 
            dir = getDir(loc), 
            {blocks} = checkAndGetBlocks(loc, dir);
        // 清除所有框架方块上的核心标记
        for (let b of blocks) 
            if (TRIGGER_IDS.includes(b.sfid)) 
                StorageCacheUtils.setData(w.getBlockAt(b.x, b.y, b.z).getLocation(), STORAGE_PREFIX + "core", null);
        
        // 清除世界中属于该核心的所有显示实体
        w.getEntities().forEach(e => { 
            if ((e instanceof ItemDisplay || e instanceof TextDisplay) && 
                e.getPersistentDataContainer().get(PROJ_KEY, PersistentDataType.STRING) === ck) 
                e.remove(); 
        });
        
        // 清除玩家投影映射中属于该核心的实体
        let iter = projMap.entrySet().iterator();
        while (iter.hasNext()) { 
            let en = iter.next(); 
            if (en.getValue().coreKey === ck) { 
                en.getValue().entities.forEach(e => { try { e.remove(); } catch (ex) {} }); 
                iter.remove(); 
            } 
        }
        
        processingCores.remove(ck);  // 清除处理中标记
    }
}