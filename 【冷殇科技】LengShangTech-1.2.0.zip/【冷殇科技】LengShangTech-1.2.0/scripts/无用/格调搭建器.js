/**
 * 一键建筑投影工具 - 幽灵方块实体版
 * 使用 FallingBlock 实体创建真正的半透明投影效果
 * 结构：中心 + 上×2 + 左 + 右（十字柱形）
 */

// ==================== Bukkit API 类导入 ====================
var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var BlockFace = Java.type("org.bukkit.block.BlockFace");
var Particle = Java.type("org.bukkit.Particle");
var Bukkit = Java.type("org.bukkit.Bukkit");
var EntityType = Java.type("org.bukkit.entity.EntityType");
var FallingBlock = Java.type("org.bukkit.entity.FallingBlock");
var PotionEffectType = Java.type("org.bukkit.potion.PotionEffectType");
var PotionEffect = Java.type("org.bukkit.potion.PotionEffect");

// ==================== 配置区域 ====================
var MAX_PLACE_DISTANCE = 6;

// 结构定义：相对于中心点的偏移 [dx, dy, dz]
// 十字柱形：中心 + 上×2 + 左 + 右
var STRUCTURE_OFFSETS = [
    [0, 1, 0],    // 上1
    [0, 2, 0],    // 上2
    [-1, 0, 0],   // 左
    [1, 0, 0]     // 右
];

// 存储每个玩家的投影状态：{ entities: [], locations: [], material: null, baseLoc: null }
var previewMap = new java.util.HashMap();

// ==================== 核心函数 ====================

function getOffhandItem(player) {
    return player.getInventory().getItemInOffHand();
}

function isPlaceableBlock(item) {
    if (!item || item.getType().isAir()) return false;
    var material = item.getType();
    return material.isBlock() && material !== Material.AIR;
}

/**
 * 获取玩家视线指向的基准位置（中心点）
 */
function getTargetBaseLocation(player) {
    var eyeLoc = player.getEyeLocation();
    var direction = eyeLoc.getDirection();
    var world = player.getWorld();
    
    for (var i = 1; i <= MAX_PLACE_DISTANCE * 5; i++) {
        var checkLoc = eyeLoc.clone().add(direction.clone().multiply(i / 5.0));
        var block = world.getBlockAt(checkLoc);
        
        if (!block.getType().isAir()) {
            // 找到碰撞方块，返回其前方位置
            var blockCenter = block.getLocation().add(0.5, 0.5, 0.5);
            var diff = checkLoc.clone().subtract(blockCenter);
            
            var face = BlockFace.UP;
            var absX = Math.abs(diff.getX());
            var absY = Math.abs(diff.getY());
            var absZ = Math.abs(diff.getZ());
            
            if (absX > absY && absX > absZ) {
                face = diff.getX() > 0 ? BlockFace.EAST : BlockFace.WEST;
            } else if (absZ > absX && absZ > absY) {
                face = diff.getZ() > 0 ? BlockFace.SOUTH : BlockFace.NORTH;
            } else {
                face = diff.getY() > 0 ? BlockFace.UP : BlockFace.DOWN;
            }
            
            return block.getRelative(face).getLocation();
        }
    }
    
    // 无碰撞，最大距离处
    var finalLoc = eyeLoc.clone().add(direction.clone().multiply(MAX_PLACE_DISTANCE));
    return world.getBlockAt(finalLoc).getLocation();
}

/**
 * 根据基准位置和偏移计算结构所有位置
 */
function getStructureLocations(baseLoc) {
    var locations = [];
    for (var i = 0; i < STRUCTURE_OFFSETS.length; i++) {
        var offset = STRUCTURE_OFFSETS[i];
        var loc = baseLoc.clone().add(offset[0], offset[1], offset[2]);
        locations.push(loc);
    }
    return locations;
}

/**
 * 创建幽灵方块实体 (FallingBlock)
 * 返回创建的实体列表
 */
function createGhostBlocks(player, locations, material) {
    var entities = [];
    var world = player.getWorld();
    var blockData = material.createBlockData();
    
    try {
        for (var i = 0; i < locations.length; i++) {
            var loc = locations[i].clone().add(0.5, 0, 0.5); // 居中
            
            // 创建 FallingBlock 实体
            var fallingBlock = world.spawn(loc, FallingBlock.class);
            
            // 设置方块数据
            fallingBlock.setBlockData(blockData);
            
            // 设置为幽灵方块效果
            fallingBlock.setGravity(false);           // 无重力
            fallingBlock.setDropItem(false);          // 不掉落物品
            fallingBlock.setHurtEntities(false);      // 不伤害实体
            fallingBlock.setInvulnerable(true);       // 无敌
            fallingBlock.setPersistent(true);         // 持久化
            fallingBlock.setSilent(true);             // 静音
            
            // 1.21.1 中设置 Glowing 来创建边框效果
            fallingBlock.setGlowing(true);
            
            // 设置发光颜色（通过队伍，但这里简化处理）
            // 在 1.21.1 中可以通过 scoreboard team 设置颜色
            try {
                fallingBlock.setVisibleByDefault(true);
                fallingBlock.setCustomNameVisible(false);
            } catch (e) {}
            
            // 添加粒子效果标记
            var centerLoc = loc.clone().add(0, 0.5, 0);
            player.spawnParticle(Particle.HAPPY_VILLAGER, centerLoc, 3, 0.15, 0.15, 0.15, 0);
            
            entities.push(fallingBlock);
        }
        
        return entities;
    } catch (e) {
        print("[投影工具] Ghost block creation error: " + e);
        // 清理已创建的实体
        for (var j = 0; j < entities.length; j++) {
            try { entities[j].remove(); } catch (err) {}
        }
        return [];
    }
}

/**
 * 清除幽灵方块实体
 */
function clearGhostBlocks(entities) {
    for (var i = 0; i < entities.length; i++) {
        try {
            var entity = entities[i];
            if (entity && entity.isValid()) {
                entity.remove();
            }
        } catch (e) {
            // 忽略移除错误
        }
    }
}

/**
 * 清除玩家所有投影
 */
function clearPlayerPreview(player) {
    var uuid = player.getUniqueId().toString();
    var preview = previewMap.get(uuid);
    if (preview) {
        if (preview.entities && preview.entities.length > 0) {
            clearGhostBlocks(preview.entities);
        }
        previewMap.remove(uuid);
    }
}

/**
 * 检查结构是否可以放置（所有位置都是空气）
 */
function canPlaceStructure(player, locations) {
    var world = player.getWorld();
    for (var i = 0; i < locations.length; i++) {
        var block = world.getBlockAt(locations[i]);
        if (!block.getType().isAir()) {
            player.sendMessage("§c位置 " + (i + 1) + " 已有方块阻挡！");
            return false;
        }
    }
    return true;
}

/**
 * 确认放置结构
 */
function confirmPlaceStructure(player, locations, material) {
    try {
        // 检查空间
        if (!canPlaceStructure(player, locations)) {
            return false;
        }
        
        // 检查物品数量
        var offhand = getOffhandItem(player);
        if (!offhand || offhand.getType() !== material) {
            player.sendMessage("§c副手物品已变更！");
            return false;
        }
        
        var needAmount = locations.length;
        if (offhand.getAmount() < needAmount) {
            player.sendMessage("§c副手方块不足！需要 " + needAmount + " 个，只有 " + offhand.getAmount() + " 个");
            return false;
        }
        
        // 消耗物品
        if (offhand.getAmount() > needAmount) {
            offhand.setAmount(offhand.getAmount() - needAmount);
        } else {
            player.getInventory().setItemInOffHand(null);
        }
        
        // 放置所有方块
        var world = player.getWorld();
        for (var i = 0; i < locations.length; i++) {
            var block = world.getBlockAt(locations[i]);
            block.setType(material, false);
        }
        
        // 播放放置效果
        try {
            var center = locations[0].clone().add(0.5, 1, 0.5);
            world.playSound(center, "block.stone.place", 1.0, 0.8);
            // 放置粒子效果
            for (var j = 0; j < locations.length; j++) {
                var pLoc = locations[j].clone().add(0.5, 0.5, 0.5);
                world.spawnParticle(Particle.HAPPY_VILLAGER, pLoc, 5, 0.2, 0.2, 0.2, 0.1);
            }
        } catch (soundErr) {}
        
        return true;
    } catch (e) {
        print("[投影工具] Place error: " + e);
        return false;
    }
}

// ==================== RSC 事件入口 ====================

function onUse(event) {
    var player = event.getPlayer();
    var item = event.getItem();
    
    // 检查副手
    var offhandItem = getOffhandItem(player);
    if (!isPlaceableBlock(offhandItem)) {
        player.sendMessage("§c副手必须持有可放置的方块！");
        player.sendActionBar("§7副手: §c无有效方块");
        return;
    }
    
    var material = offhandItem.getType();
    var uuid = player.getUniqueId().toString();
    
    // 获取基准位置
    var baseLoc = getTargetBaseLocation(player);
    
    // 计算结构所有位置
    var locations = getStructureLocations(baseLoc);
    
    // 获取当前投影状态
    var currentPreview = previewMap.get(uuid);
    
    // 如果已有投影且基准位置相同，确认放置
    if (currentPreview && currentPreview.baseLoc) {
        var prevBase = currentPreview.baseLoc;
        if (prevBase.getBlockX() === baseLoc.getBlockX() && 
            prevBase.getBlockY() === baseLoc.getBlockY() && 
            prevBase.getBlockZ() === baseLoc.getBlockZ()) {
            
            // 先清除投影实体
            clearPlayerPreview(player);
            
            if (confirmPlaceStructure(player, locations, material)) {
                player.sendMessage("§a结构已放置！共 " + locations.length + " 个方块");
                player.sendActionBar("§a已放置 " + material.name() + " ×" + locations.length);
            }
            return;
        } else {
            // 位置变更，清除旧投影
            clearPlayerPreview(player);
        }
    }
    
    // 检查新位置是否可以放置
    if (!canPlaceStructure(player, locations)) {
        player.sendMessage("§c目标区域有方块阻挡，无法建立投影！");
        return;
    }
    
    // 创建幽灵方块投影
    var entities = createGhostBlocks(player, locations, material);
    
    if (entities.length > 0) {
        // 保存投影状态
        previewMap.put(uuid, {
            baseLoc: baseLoc,
            locations: locations,
            material: material,
            entities: entities
        });
        
        player.sendMessage("§6幽灵投影已建立！再次右键确认放置");
        player.sendMessage("§7结构: §f十字柱形 §7(§e" + locations.length + "§7个方块)");
        player.sendActionBar("§7方块: §f" + material.name() + " §7| §e右键确认放置");
    } else {
        player.sendMessage("§c投影创建失败！请检查环境兼容性");
    }
}

function onQuit(player) {
    clearPlayerPreview(player);
}

function onOpen(player) {
    clearPlayerPreview(player);
}

function onClose(player) {
    clearPlayerPreview(player);
}