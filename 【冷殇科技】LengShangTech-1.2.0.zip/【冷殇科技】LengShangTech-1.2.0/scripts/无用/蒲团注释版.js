// ============================================================
// 蒲团修炼系统 - RykenSlimefunCustomizer GraalJS 脚本
// 用途：实现修仙风格的打坐修炼装置，包含灵气积累、修为突破、
//       天雷渡劫、属性成长、全息投影、GUI交互等功能
// ============================================================

// --- Bukkit API 核心类导入 ---
const KOMUTECH_L_X_PT_Bukkit = Java.type('org.bukkit.Bukkit');                                    // Bukkit 服务器主类
const KOMUTECH_L_X_PT_Material = Java.type('org.bukkit.Material');                                  // 方块/物品材料枚举
const KOMUTECH_L_X_PT_ItemStack = Java.type('org.bukkit.inventory.ItemStack');                    // 物品栈类
const KOMUTECH_L_X_PT_EntityType = Java.type('org.bukkit.entity.EntityType');                     // 实体类型枚举
const KOMUTECH_L_X_PT_Pose = Java.type('org.bukkit.entity.Pose');                                  // 玩家姿势枚举（坐姿/站姿）
const KOMUTECH_L_X_PT_NamespacedKey = Java.type('org.bukkit.NamespacedKey');                      // 命名空间键（PDC用）
const KOMUTECH_L_X_PT_PersistentDataType = Java.type('org.bukkit.persistence.PersistentDataType');// 持久化数据类型
const KOMUTECH_L_X_PT_EquipmentSlot = Java.type('org.bukkit.inventory.EquipmentSlot');            // 装备槽位枚举（区分主副手）
const KOMUTECH_L_X_PT_Color = Java.type('org.bukkit.Color');                                      // 颜色类
const KOMUTECH_L_X_PT_InvClick = Java.type('org.bukkit.event.inventory.InventoryClickEvent');     // 背包点击事件
const KOMUTECH_L_X_PT_InvClose = Java.type('org.bukkit.event.inventory.InventoryCloseEvent');   // 背包关闭事件
const KOMUTECH_L_X_PT_EventPriority = Java.type('org.bukkit.event.EventPriority');               // 事件优先级枚举

// --- RSC 插件主类导入 ---
const KOMUTECH_L_X_PT_plugin = Java.type('org.lins.mmmjjkx.rykenslimefuncustomizer.RykenSlimefunCustomizer').INSTANCE;  // RSC 插件实例

// --- Java 标准库导入 ---
const KOMUTECH_L_X_PT_Files = Java.type('java.nio.file.Files');                                   // 文件操作工具
const KOMUTECH_L_X_PT_Paths = Java.type('java.nio.file.Paths');                                  // 路径构建工具
const KOMUTECH_L_X_PT_StandardCharsets = Java.type('java.nio.charset.StandardCharsets');        // 字符编码

// --- 显示实体相关类导入（用于全息投影效果）---
const KOMUTECH_L_X_PT_BlockDisplay = Java.type('org.bukkit.entity.BlockDisplay');                 // 方块显示实体
const KOMUTECH_L_X_PT_Display = Java.type('org.bukkit.entity.Display');                         // 显示实体基类
const KOMUTECH_L_X_PT_Transformation = Java.type('org.bukkit.util.Transformation');              // 显示实体变换矩阵
const KOMUTECH_L_X_PT_Vector3f = Java.type('org.joml.Vector3f');                                // 3D 向量（变换用）
const KOMUTECH_L_X_PT_AxisAngle4f = Java.type('org.joml.AxisAngle4f');                           // 轴角旋转（变换用）

// --- 粒子效果类导入 ---
const KOMUTECH_L_X_PT_Particle = Java.type('org.bukkit.Particle');                              // 粒子效果枚举

// ============================================================
// 常量定义区
// ============================================================

// --- 默认蒲团 ID ---
const KOMUTECH_L_X_PT_DEFAULT_ID = 'KOMUTECH_L_X_蒲团';                                           // 默认蒲团的 Slimefun ID

// --- PDC 键定义（用于标记实体归属）---
const KOMUTECH_L_X_PT_SEAT_KEY = new KOMUTECH_L_X_PT_NamespacedKey('rsc_meditation', 'seat');    // 座位实体的 PDC 键
const KOMUTECH_L_X_PT_SEAT_TAG = 'meditation_seat';                                               // 座位实体标记值
const KOMUTECH_L_X_PT_PROJ_KEY = new KOMUTECH_L_X_PT_NamespacedKey('rsc_meditation', 'proj');    // 投影实体的 PDC 键
const KOMUTECH_L_X_PT_PROJ_TAG = 'meditation_proj';                                               // 投影实体标记值

// --- Slimefun 方块存储数据键 ---
const KOMUTECH_L_X_PT_STATE_KEY = 'meditation_state';                                             // 蒲团状态存储键（0=空闲,1=修炼中,2=突破中）
const KOMUTECH_L_X_PT_SEAT_UUID_KEY = 'meditation_seat_uuid';                                     // 座位实体 UUID 存储键
const KOMUTECH_L_X_PT_PROJ_UUID_KEY = 'meditation_proj_uuid';                                     // 投影实体 UUID 存储键
const KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY = 'prayer_mat_id';                                        // 蒲团材质配置 ID 存储键

// --- 数据文件路径 ---
const KOMUTECH_L_X_PT_DATA_DIR = 'plugins/RykenSlimefunCustomizer/addon_configs/Komutech/玩家属性';  // 玩家属性 JSON 存储目录
const KOMUTECH_L_X_PT_CONFIG_PATH = 'plugins/RykenSlimefunCustomizer/addon_configs/Komutech/蒲团配置.json';  // 蒲团配置文件路径

// --- 修为境界加成系数表 ---
// 9 个境界 × 9 个小阶段，每个值表示该阶段的修炼效率加成
const KOMUTECH_L_X_PT_REALM_BONUS = [
    [0.10,0.13,0.16,0.19,0.22,0.25,0.28,0.31,0.34],   // 引气入体
    [0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90],   // 练气
    [1.20,1.30,1.40,1.50,1.60,1.70,1.80,1.90,2.00],   // 筑基
    [2.50,2.70,2.90,3.10,3.30,3.50,3.70,3.90,4.10],   // 金丹
    [4.50,4.80,5.10,5.40,5.70,6.00,6.30,6.60,6.90],   // 元婴
    [7.50,8.00,8.50,9.00,9.50,10.00,10.50,11.00,11.50],// 化神
    [12.50,13.50,14.50,15.50,16.50,17.50,18.50,19.50,20.50], // 大成
    [22.00,23.50,25.00,26.50,28.00,29.50,31.00,32.50,34.00], // 渡劫
    [36.00,38.00,40.00,42.00,44.00,46.00,48.00,50.00,52.00]  // 飞升
];

// --- 突破持续时间（tick，每 60 tick = 3 秒执行一次，共 15 次 = 45 秒）---
const KOMUTECH_L_X_PT_BREAK_DUR = 15;

// --- 灵根数量衰减系数（元素越多，单个元素效率越低）---
const KOMUTECH_L_X_PT_DECAY = {1:1.0, 2:0.8, 3:0.5, 4:0.3, 5:0.1};

// --- 各元素灵力系数（影响修炼速度）---
const KOMUTECH_L_X_PT_LINGLI = {'金':1.0,'木':1.2,'水':1.5,'火':0.8,'土':0.9,'雷':1.5,'风':1.3,'冰':1.4,'光':1.5,'暗':1.3};

// --- 变异灵根标记表 ---
const KOMUTECH_L_X_PT_MUTATED = {'雷':true,'风':true,'冰':true,'光':true,'暗':true};

// --- 灵根属性系数（影响最终修炼效率倍率）---
const KOMUTECH_L_X_PT_ATTR_COEFF = {'杂灵根':0.1,'四灵根':0.3,'三灵根':0.5,'双灵根':0.8,'单灵根':1.0,'天灵根':1.2,'变异灵根':1.3,'变异多灵根':1.0,'混沌灵根':1.0};

// --- 雷劫配置：灵气上限阈值 -> 雷劫道数映射 ---
const KOMUTECH_L_X_PT_TRIBULATION_MAP = {100000:9, 1000000:16, 10000000:21, 100000000:36, 1000000000:49, 10000000000:81, 100000000000:99};

// --- 名称加密密钥（用于作者署名验证）---
const KOMUTECH_L_X_PT_NAME_KEY = 0x5F;

/**
 * 异或解密函数（用于还原加密存储的作者名称）
 * @param {number[]} encArr - 加密字符码数组
 * @returns {string} 解密后的字符串
 */
function KOMUTECH_L_X_PT_decrypt(encArr) {
    let str = '';
    for (let i = 0; i < encArr.length; i++) {
        str += String.fromCharCode(encArr[i] ^ KOMUTECH_L_X_PT_NAME_KEY);  // 逐字符异或解密
    }
    return str;
}

// --- 加密存储的作者名称（防止篡改）---
const KOMUTECH_L_X_PT_NAMES_ENCRYPTED = [
    [20287,30682,21818,65344],                                    // 作者名1
    [27452,22391,20401,28899,35752,21152,25100,25135,65374],      // 作者名2
    [20,48,50,42,0,30,22904,29652,105,105,105,65374,65374,65374] // 作者名3
];

// --- 校验用的加密名称（用于完整性验证）---
const KOMUTECH_L_X_PT_CHECK_ENCRYPTED = KOMUTECH_L_X_PT_NAMES_ENCRYPTED[0];

// --- 名称校验是否通过标记 ---
let KOMUTECH_L_X_PT_NAME_CHECK_PASSED = true;

// 运行时进行名称校验，检测脚本是否被篡改
try {
    const decryptedNames = KOMUTECH_L_X_PT_NAMES_ENCRYPTED.map(arr => KOMUTECH_L_X_PT_decrypt(arr));
    const expected = KOMUTECH_L_X_PT_decrypt(KOMUTECH_L_X_PT_CHECK_ENCRYPTED);
    if (!decryptedNames.includes(expected)) {
        KOMUTECH_L_X_PT_NAME_CHECK_PASSED = false;
        KOMUTECH_L_X_PT_Bukkit.getLogger().warning("[蒲团] 检测到代码被篡改，建议联系附属作者为作者口木啊~取得权限。");
    }
} catch(e) {
    KOMUTECH_L_X_PT_NAME_CHECK_PASSED = false;
    KOMUTECH_L_X_PT_Bukkit.getLogger().warning("[蒲团] 名字校验失败，请检查脚本完整性。");
}

// ============================================================
// 蒲团配置加载
// ============================================================

/**
 * 加载蒲团配置文件（支持中文键名和英文键名）
 * 配置文件格式：{ "蒲团ID": { "基础修炼速度": 1, "投影材质": "minecraft:horn_coral_fan" } }
 * @returns {Object} 蒲团配置映射表
 */
let KOMUTECH_L_X_PT_MAT_CONFIG = (() => {
    const path = KOMUTECH_L_X_PT_Paths.get(KOMUTECH_L_X_PT_CONFIG_PATH);
    const defaultConfig = { 'KOMUTECH_L_X_蒲团': { baseGain: 1, projMaterial: 'minecraft:horn_coral_fan' } };  // 默认配置
    try {
        if (KOMUTECH_L_X_PT_Files.exists(path)) {
            const raw = KOMUTECH_L_X_PT_Files.readString(path, KOMUTECH_L_X_PT_StandardCharsets.UTF_8);
            const loaded = JSON.parse(raw);
            const translated = {};
            for (const [id, props] of Object.entries(loaded)) {
                translated[id] = {
                    baseGain: props['基础修炼速度'] || props.baseGain || 1,           // 基础修炼速度
                    projMaterial: props['投影材质'] || props.projMaterial || 'minecraft:horn_coral_fan'  // 全息投影材质
                };
            }
            return translated;
        }
    } catch (e) { print('[蒲团] 读取配置失败，使用默认值: ' + e); }
    return defaultConfig;
})();

// --- 基础属性成长值（每次小阶段突破时随机增加）---
let KOMUTECH_L_X_PT_BASE_GROWTH = {'血量':3,'攻击力':1,'防御力':1,'速度':0.1,'灵识':0.01,'灵力':0.1};

// --- 定时任务存储表：位置键 -> 任务 ID ---
let KOMUTECH_L_X_PT_tasks = new java.util.HashMap();

// ============================================================
// 位置与任务工具函数
// ============================================================

/**
 * 将位置转换为字符串键（用于唯一标识蒲团位置）
 * @param {Location} loc - 位置对象
 * @returns {string} "世界名,x,y,z" 格式
 */
function KOMUTECH_L_X_PT_locKey(loc) { return loc.getWorld().getName() + ',' + loc.getBlockX() + ',' + loc.getBlockY() + ',' + loc.getBlockZ(); }

/**
 * 取消指定位置的修炼定时任务
 * @param {Location} loc - 蒲团位置
 */
function KOMUTECH_L_X_PT_cancelTask(loc) { let k = KOMUTECH_L_X_PT_locKey(loc); let t = KOMUTECH_L_X_PT_tasks.get(k); if (t) { try { KOMUTECH_L_X_PT_Bukkit.getScheduler().cancelTask(t); } catch (e) {} KOMUTECH_L_X_PT_tasks.remove(k); } }

/**
 * 取消指定位置的渡劫定时任务
 * @param {Location} loc - 蒲团位置
 */
function KOMUTECH_L_X_PT_cancelTribulationTask(loc) { let k = KOMUTECH_L_X_PT_locKey(loc) + '_trib'; let t = KOMUTECH_L_X_PT_tasks.get(k); if (t) { try { KOMUTECH_L_X_PT_Bukkit.getScheduler().cancelTask(t); } catch (e) {} KOMUTECH_L_X_PT_tasks.remove(k); } }

// ============================================================
// 玩家数据读写函数
// ============================================================

/**
 * 加载玩家修仙属性数据
 * @param {Player} p - 玩家对象
 * @returns {Object|null} 玩家数据对象，不存在则返回 null
 */
function KOMUTECH_L_X_PT_load(p) { let path = KOMUTECH_L_X_PT_Paths.get(KOMUTECH_L_X_PT_DATA_DIR, '[' + p.getName() + '].json'); if (!KOMUTECH_L_X_PT_Files.exists(path)) return null; try { return JSON.parse(KOMUTECH_L_X_PT_Files.readString(path, KOMUTECH_L_X_PT_StandardCharsets.UTF_8)); } catch (e) { return null; } }

/**
 * 保存玩家修仙属性数据到 JSON 文件
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 * @returns {boolean} 是否保存成功
 */
function KOMUTECH_L_X_PT_save(p, d) { let path = KOMUTECH_L_X_PT_Paths.get(KOMUTECH_L_X_PT_DATA_DIR, '[' + p.getName() + '].json'); try { KOMUTECH_L_X_PT_Files.writeString(path, JSON.stringify(d, null, 2), KOMUTECH_L_X_PT_StandardCharsets.UTF_8); return true; } catch (e) { return false; } }

// ============================================================
// 灵气解析与修为计算函数
// ============================================================

/**
 * 解析灵气字符串（格式："当前值/上限值+附加值"）
 * @param {string} s - 灵气字符串
 * @returns {Object} {cur: 当前值, max: 上限值, bonus: 附加值}
 */
function KOMUTECH_L_X_PT_parseSpirit(s) { let m = s.match(/^(\d+\.?\d*)\/(\d+)(?:\+(-?\d+))?$/); if (!m) return { cur: 0, max: 0, bonus: 0 }; return { cur: parseFloat(m[1]), max: parseFloat(m[2]), bonus: m[3] ? parseInt(m[3]) : 0 }; }

/**
 * 根据灵气值计算修为境界系数（用于修炼速度加成）
 * @param {number} v - 灵气值
 * @returns {number} 境界加成系数
 */
function KOMUTECH_L_X_PT_realmCoeff(v) { 
    let val = parseInt(v) || 0; 
    if (val < 100) return 0; 
    if (val >= 100000000000) return 18 + Math.floor((val - 100000000000) / 100000000000) * 2;  // 神人境界以上
    const rb = [100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]; 
    let idx = 0; 
    for (let i = 0; i < rb.length; i++) if (val < rb[i]) { idx = i - 1; break; } 
    if (idx === -1) idx = 0; 
    if (val >= 1000000000) idx = 7; 
    let base = rb[idx], range = idx === 7 ? 90000000000 : rb[idx + 1] - base, step = Math.floor(range / 9), rank = Math.floor((val - base) / step); 
    if (rank >= 9) rank = 8; 
    return KOMUTECH_L_X_PT_REALM_BONUS[idx][rank]; 
}

/**
 * 根据灵气值计算修为境界信息
 * @param {number} v - 灵气值
 * @returns {Object} {stage: 境界名称, spiritCap: 灵气上限, maxStr: 上限字符串}
 */
function KOMUTECH_L_X_PT_cultivation(v) {
    let val = parseInt(v) || 0;
    if (val <= 100) return { stage: '『引气入体』', spiritCap: 100, maxStr: '100' };  // 初始境界
    let b = [
        { base: 101, next: 1000, name: '练气' }, { base: 1001, next: 10000, name: '筑基' },
        { base: 10001, next: 100000, name: '金丹' }, { base: 100001, next: 1000000, name: '元婴' },
        { base: 1000001, next: 10000000, name: '化神' }, { base: 10000001, next: 100000000, name: '大成' },
        { base: 100000001, next: 1000000000, name: '渡劫' }, { base: 1000000001, next: 100000000000, name: '飞升' }
    ];
    // 查找所属境界
    for (let i of b) {
        if (val <= i.next) {
            let r = i.next - i.base + 1, s = Math.floor(r / 9), rank = Math.floor((val - i.base) / s);
            if (rank >= 9) rank = 8;
            let cap = Math.floor(i.next * ((rank + 1) * 0.1));  // 计算灵气上限
            return { stage: `『${i.name}·${rank + 1}阶』`, spiritCap: cap, maxStr: i.next.toString() };
        }
    }
    // 飞升之后的神人境界
    let rk = Math.floor((val - 100000000000) / 100000000000) + 1, cap = Math.floor(100000000000 * (rk * 0.1));
    return { stage: `『神人·${rk}阶』`, spiritCap: cap, maxStr: '無' };
}

// ============================================================
// 灵根计算函数
// ============================================================

/**
 * 计算灵根最终修炼效率倍率
 * 综合元素数量衰减、元素灵力系数、灵根属性系数
 * @param {string[]} els - 元素数组
 * @param {number} q - 总品质值
 * @returns {number} 最终效率倍率
 */
function KOMUTECH_L_X_PT_linggenFinal(els, q) {
    if (!els.length) return 1.0;
    let c = els.length, decay = KOMUTECH_L_X_PT_DECAY[c] || 0.1, sum = 0;
    for (let e of els) sum += KOMUTECH_L_X_PT_LINGLI[e] || 1.0;  // 累加各元素灵力系数
    let base = (sum / c) * q * decay;  // 基础效率 = 平均灵力 × 品质 × 衰减
    
    // 判定灵根属性类型
    let attrType = (function(els, q) {
        let c = els.length, mc = els.filter(e => KOMUTECH_L_X_PT_MUTATED[e]).length;  // 变异元素数量
        if (c === 1) { let e = els[0]; if (KOMUTECH_L_X_PT_MUTATED[e]) return '变异灵根'; if (q > 0.9) return '天灵根'; return '单灵根'; }
        if (c >= 5) return '杂灵根';
        if (c > 1 && mc > 0) return '变异多灵根';
        if (c === 4) return '四灵根'; if (c === 3) return '三灵根'; if (c === 2) return '双灵根';
        return '未知';
    })(els, q);
    
    let extra = KOMUTECH_L_X_PT_ATTR_COEFF[attrType] || 1.0;  // 灵根属性额外系数
    return (1.0 + base) * extra;
}

// ============================================================
// 灵力上限计算函数
// ============================================================

/**
 * 计算玩家灵力上限
 * 综合修为境界、灵根效率、根骨等属性
 * @param {Object} d - 玩家数据对象
 * @returns {number} 灵力上限值
 */
function KOMUTECH_L_X_PT_computeLingliMax(d) {
    let els = (d.灵根 || '').split('、').filter(e => e), q = parseFloat(d.总品质) || 0.01;
    let lc = KOMUTECH_L_X_PT_linggenFinal(els, q), info = KOMUTECH_L_X_PT_cultivation(d.灵气 || '0');
    let decay = KOMUTECH_L_X_PT_DECAY[els.length] || 0.1, gengu = d.根骨 || 1;
    return Math.floor(info.spiritCap * lc * decay * q * (KOMUTECH_L_X_PT_BASE_GROWTH['灵力'] || 0.1) * (gengu / 10)) + 100;
}

/**
 * 更新玩家灵力值（保持当前值不超过新上限）
 * @param {Object} d - 玩家数据对象
 */
function KOMUTECH_L_X_PT_updateLingliMax(d) {
    let nmax = KOMUTECH_L_X_PT_computeLingliMax(d), m = d.灵力.match(/^(\d+)\/(\d+)\+?(-?\d+)?$/);
    let cur = m ? parseInt(m[1]) : nmax; if (cur > nmax) cur = nmax;  // 超出则截断
    let bonus = m && m[3] ? parseInt(m[3]) : 0;
    d.灵力 = cur + '/' + nmax + (bonus !== 0 ? '+' + bonus : '');  // 保留附加值
}

// ============================================================
// 物品创建与实体工具函数
// ============================================================

/**
 * 创建带名称和 Lore 的物品栈
 * @param {string} mat - 材料名
 * @param {string} name - 显示名称
 * @param {string[]|string} lore - Lore 文本
 * @returns {ItemStack} 配置好的物品
 */
function KOMUTECH_L_X_PT_createItem(mat, name, lore) { let i = new KOMUTECH_L_X_PT_ItemStack(KOMUTECH_L_X_PT_Material[mat] || KOMUTECH_L_X_PT_Material.getMaterial(mat)), m = i.getItemMeta(); m.setDisplayName(name); if (lore) m.setLore(Array.isArray(lore) ? lore : [lore]); i.setItemMeta(m); return i; }

// --- 座位实体（ArmorStand）检测与标记 ---

/**
 * 检查实体是否为蒲团座位
 * @param {Entity} e - 实体对象
 * @returns {boolean} 是否为蒲团座位
 */
function KOMUTECH_L_X_PT_isSeat(e) { if (!e) return false; try { let p = e.getPersistentDataContainer(); return p.has(KOMUTECH_L_X_PT_SEAT_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING) && KOMUTECH_L_X_PT_SEAT_TAG === p.get(KOMUTECH_L_X_PT_SEAT_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING); } catch (x) { return false; } }

/**
 * 标记实体为蒲团座位
 * @param {Entity} e - 实体对象
 */
function KOMUTECH_L_X_PT_markSeat(e) { if (!e) return; try { e.getPersistentDataContainer().set(KOMUTECH_L_X_PT_SEAT_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING, KOMUTECH_L_X_PT_SEAT_TAG); } catch (x) {} }

// --- 投影实体（BlockDisplay）检测与标记 ---

/**
 * 检查实体是否为蒲团投影
 * @param {Entity} e - 实体对象
 * @returns {boolean} 是否为蒲团投影
 */
function KOMUTECH_L_X_PT_isProj(e) { if (!e) return false; try { let p = e.getPersistentDataContainer(); return p.has(KOMUTECH_L_X_PT_PROJ_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING) && KOMUTECH_L_X_PT_PROJ_TAG === p.get(KOMUTECH_L_X_PT_PROJ_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING); } catch (x) { return false; } }

/**
 * 标记实体为蒲团投影
 * @param {Entity} e - 实体对象
 */
function KOMUTECH_L_X_PT_markProj(e) { if (!e) return; try { e.getPersistentDataContainer().set(KOMUTECH_L_X_PT_PROJ_KEY, KOMUTECH_L_X_PT_PersistentDataType.STRING, KOMUTECH_L_X_PT_PROJ_TAG); } catch (x) {} }

// --- 实体移除函数 ---

/**
 * 移除座位实体（先弹射乘客再移除）
 * @param {Entity} s - 座位实体
 */
function KOMUTECH_L_X_PT_removeSeat(s) { if (s && !s.isDead()) { s.eject(); s.remove(); } }

/**
 * 移除投影实体
 * @param {Entity} p - 投影实体
 */
function KOMUTECH_L_X_PT_removeProj(p) { if (p && !p.isDead()) p.remove(); }

// --- 实体查找函数 ---

/**
 * 通过 UUID 查找座位实体
 * @param {Location} loc - 位置（用于获取世界）
 * @param {string} uid - UUID 字符串
 * @returns {Entity|null} 找到的实体或 null
 */
function KOMUTECH_L_X_PT_findSeat(loc, uid) { try { return loc.getWorld().getEntity(java.util.UUID.fromString(uid)); } catch (e) { return null; } }

/**
 * 通过 UUID 查找投影实体
 * @param {Location} loc - 位置（用于获取世界）
 * @param {string} uid - UUID 字符串
 * @returns {Entity|null} 找到的实体或 null
 */
function KOMUTECH_L_X_PT_findProj(loc, uid) { try { return loc.getWorld().getEntity(java.util.UUID.fromString(uid)); } catch (e) { return null; } }

/**
 * 在蒲团附近查找座位实体（备用查找方式）
 * @param {Location} loc - 蒲团位置
 * @returns {Entity|null} 找到的座位实体或 null
 */
function KOMUTECH_L_X_PT_nearbySeat(loc) { let ents = loc.getWorld().getNearbyEntities(loc, 2, 2, 2); for (let i = 0; i < ents.size(); i++) { let e = ents.get(i); if (e.getType() === KOMUTECH_L_X_PT_EntityType.ARMOR_STAND && KOMUTECH_L_X_PT_isSeat(e)) return e; } return null; }

/**
 * 在蒲团附近查找投影实体（备用查找方式）
 * @param {Location} loc - 蒲团位置
 * @returns {Entity|null} 找到的投影实体或 null
 */
function KOMUTECH_L_X_PT_nearbyProj(loc) { let ents = loc.getWorld().getNearbyEntities(loc, 2, 3, 2); for (let i = 0; i < ents.size(); i++) { let e = ents.get(i); if (e instanceof KOMUTECH_L_X_PT_BlockDisplay && KOMUTECH_L_X_PT_isProj(e)) return e; } return null; }

// ============================================================
// 座位与投影创建函数
// ============================================================

/**
 * 创建蒲团座位实体（ArmorStand）并可选创建全息投影
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Color} color - 头盔颜色（白色=修炼，红色=突破）
 * @param {boolean} med - 是否创建全息投影
 * @returns {Entity} 创建的座位实体
 */
function KOMUTECH_L_X_PT_createSeat(loc, p, color, med) {
    let w = loc.getWorld(), 
        seat = w.spawnEntity(loc.clone().add(0.5, 0.0, 0.5), KOMUTECH_L_X_PT_EntityType.ARMOR_STAND);  // 在蒲团中心上方生成盔甲架
    
    // 配置盔甲架为不可见的座位
    seat.setInvisible(true); seat.setInvulnerable(true); seat.setSilent(true); seat.setGravity(false);
    seat.setAI(false); seat.setCollidable(false); seat.setSmall(true); seat.setArms(false); seat.setBasePlate(false);
    seat.setCustomName(""); seat.setCustomNameVisible(false);
    
    // 设置染色皮帽（用于区分修炼/突破状态）
    let h = new KOMUTECH_L_X_PT_ItemStack(KOMUTECH_L_X_PT_Material.LEATHER_HELMET), m_ = h.getItemMeta(); 
    m_.setColor(color); h.setItemMeta(m_);
    seat.getEquipment().setHelmet(h); 
    
    KOMUTECH_L_X_PT_markSeat(seat);  // 标记为蒲团座位
    seat.addPassenger(p);              // 让玩家骑乘（实现坐下效果）
    p.setPose(KOMUTECH_L_X_PT_Pose.SITTING);  // 设置玩家姿势为坐下
    
    // 如果名称校验通过，显示随机作者名；否则显示无效授权
    if (KOMUTECH_L_X_PT_NAME_CHECK_PASSED) {
        let decryptedNames = KOMUTECH_L_X_PT_NAMES_ENCRYPTED.map(arr => KOMUTECH_L_X_PT_decrypt(arr));
        let randomName = decryptedNames[Math.floor(Math.random() * decryptedNames.length)];
        seat.setCustomName(randomName);
        seat.setCustomNameVisible(true);
    } else {
        seat.setCustomName("§c无效授权");
        seat.setCustomNameVisible(true);
    }
    
    // 创建全息投影（BlockDisplay）
    if (med) {
        let projLoc = loc.clone().add(-0.5, 1.0, -0.5),  // 偏移到蒲团上方
            proj = w.spawn(projLoc, KOMUTECH_L_X_PT_BlockDisplay.class);
        let mid = StorageCacheUtils.getData(loc, KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY) || KOMUTECH_L_X_PT_DEFAULT_ID;
        let config = KOMUTECH_L_X_PT_MAT_CONFIG[mid] || KOMUTECH_L_X_PT_MAT_CONFIG[KOMUTECH_L_X_PT_DEFAULT_ID];
        proj.setBlock(KOMUTECH_L_X_PT_Bukkit.createBlockData(config.projMaterial));  // 设置投影方块材质
        // 设置变换：缩放为 2 倍
        proj.setTransformation(new KOMUTECH_L_X_PT_Transformation(new KOMUTECH_L_X_PT_Vector3f(0,0,0), new KOMUTECH_L_X_PT_AxisAngle4f(0,0,1,0), new KOMUTECH_L_X_PT_Vector3f(2.0,2.0,2.0), new KOMUTECH_L_X_PT_AxisAngle4f(0,0,1,0)));
        proj.setBrightness(new KOMUTECH_L_X_PT_Display.Brightness(15,15));  // 最大亮度
        proj.setViewRange(100);       // 超远可视距离
        proj.setGravity(false);
        proj.setInvulnerable(true);
        KOMUTECH_L_X_PT_markProj(proj);  // 标记为蒲团投影
        KOMUTECH_L_X_PT_setProjUUID(loc, proj.getUniqueId());  // 记录 UUID
    }
    return seat;
}

// ============================================================
// 蒲团状态读写函数
// ============================================================

/**
 * 获取蒲团当前状态
 * @param {Location} loc - 蒲团位置
 * @returns {number} 0=空闲, 1=修炼中, 2=突破中
 */
function KOMUTECH_L_X_PT_getState(loc) { let d = StorageCacheUtils.getData(loc, KOMUTECH_L_X_PT_STATE_KEY); return d ? parseInt(d) : 0; }

/**
 * 设置蒲团状态
 * @param {Location} loc - 蒲团位置
 * @param {number} s - 状态值
 */
function KOMUTECH_L_X_PT_setState(loc, s) { StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_STATE_KEY, String(s)); }

/**
 * 获取座位实体 UUID
 * @param {Location} loc - 蒲团位置
 * @returns {string|null} UUID 字符串
 */
function KOMUTECH_L_X_PT_getSeatUUID(loc) { return StorageCacheUtils.getData(loc, KOMUTECH_L_X_PT_SEAT_UUID_KEY); }

/**
 * 设置座位实体 UUID
 * @param {Location} loc - 蒲团位置
 * @param {string} u - UUID 字符串
 */
function KOMUTECH_L_X_PT_setSeatUUID(loc, u) { StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_SEAT_UUID_KEY, u ? u.toString() : null); }

/**
 * 获取投影实体 UUID
 * @param {Location} loc - 蒲团位置
 * @returns {string|null} UUID 字符串
 */
function KOMUTECH_L_X_PT_getProjUUID(loc) { return StorageCacheUtils.getData(loc, KOMUTECH_L_X_PT_PROJ_UUID_KEY); }

/**
 * 设置投影实体 UUID
 * @param {Location} loc - 蒲团位置
 * @param {string} u - UUID 字符串
 */
function KOMUTECH_L_X_PT_setProjUUID(loc, u) { StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_PROJ_UUID_KEY, u ? u.toString() : null); }

// ============================================================
// 清理函数
// ============================================================

/**
 * 清理蒲团关联的所有实体和状态
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象（可选，用于重置玩家姿势）
 */
function KOMUTECH_L_X_PT_cleanup(loc, p) {
    KOMUTECH_L_X_PT_cancelTask(loc); KOMUTECH_L_X_PT_cancelTribulationTask(loc);  // 取消所有任务
    
    // 查找并移除座位实体
    let uid = KOMUTECH_L_X_PT_getSeatUUID(loc), seat = uid ? KOMUTECH_L_X_PT_findSeat(loc, uid) : null;
    if (!seat || seat.isDead()) seat = KOMUTECH_L_X_PT_nearbySeat(loc); 
    if (seat) KOMUTECH_L_X_PT_removeSeat(seat);
    
    // 查找并移除投影实体
    let pid = KOMUTECH_L_X_PT_getProjUUID(loc), proj = pid ? KOMUTECH_L_X_PT_findProj(loc, pid) : null;
    if (!proj || proj.isDead()) proj = KOMUTECH_L_X_PT_nearbyProj(loc); 
    if (proj) KOMUTECH_L_X_PT_removeProj(proj);
    
    // 清除存储数据
    KOMUTECH_L_X_PT_setSeatUUID(loc, null); KOMUTECH_L_X_PT_setProjUUID(loc, null);
    StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY, null);
    
    // 重置玩家姿势
    if (p) { let v = p.getVehicle(); if (v && KOMUTECH_L_X_PT_isSeat(v)) v.eject(); p.setPose(KOMUTECH_L_X_PT_Pose.STANDING); }
}

// ============================================================
// 灵气增加与修炼逻辑
// ============================================================

/**
 * 为玩家增加灵气（核心修炼逻辑）
 * 综合悟性、品质、境界、灵根、蒲团配置等计算增长量
 * 灵气满后转为溢出灵气，积累稳固值
 * @param {Player} p - 玩家对象
 * @param {Location} loc - 蒲团位置
 * @returns {boolean} 溢出灵气是否已达上限
 */
function KOMUTECH_L_X_PT_addSpirit(p, loc) {
    let d = KOMUTECH_L_X_PT_load(p); if (!d || !d.灵气) return false;  // 无数据则跳过
    
    let oldStage = d.修为;  // 记录旧境界用于检测突破
    let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气),  // 解析当前灵气
        wuxing = parseFloat(d.悟性) || 1,                    // 悟性
        quality = parseFloat(d.总品质) || 0.5;               // 灵根总品质
    
    let attr = d.灵根属性 || '', 
        coeff = (KOMUTECH_L_X_PT_ATTR_COEFF[attr] || 1.0) * KOMUTECH_L_X_PT_realmCoeff(d.灵气);  // 灵根属性系数 × 境界系数
    
    let mid = StorageCacheUtils.getData(loc, KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY) || KOMUTECH_L_X_PT_DEFAULT_ID;
    let config = KOMUTECH_L_X_PT_MAT_CONFIG[mid] || KOMUTECH_L_X_PT_MAT_CONFIG[KOMUTECH_L_X_PT_DEFAULT_ID];
    // 修炼增长量 = 悟性 × 品质 × 综合系数 + 蒲团基础速度（保底 0.01）
    let gain = Math.max(0.01, wuxing * quality * coeff + config.baseGain);
    
    // 初始化根基数据
    if (!d.根基) d.根基 = { 稳固值: 0, 溢出的灵气: '0/0', 破镜药力: 0, 保阶药力: 0 };
    if (typeof d.根基.稳固值 !== 'number') d.根基.稳固值 = 0;
    if (typeof d.根基.破镜药力 !== 'number') d.根基.破镜药力 = 0;
    if (typeof d.根基.保阶药力 !== 'number') d.根基.保阶药力 = 0;
    
    // 解析当前溢出灵气
    let ovStr = d.根基.溢出的灵气 || '0/0', 
        ovMatch = ovStr.match(/^(\d+\.?\d*)\/(\d+\.?\d*)$/), 
        ovCur = ovMatch ? parseFloat(ovMatch[1]) : 0;
    let gengu = parseFloat(d.根骨) || 1, 
        ovLimit = Math.floor((gengu / 10) * max * 100) / 100;  // 溢出上限由根骨决定
    
    // 灵气未满：直接增加
    if (cur < max) { 
        cur = Math.min(cur + gain, max); 
        d.灵气 = cur.toFixed(2) + '/' + max; 
    }
    // 灵气已满：转为溢出灵气
    if (cur >= max) {
        let extra = cur + gain - max, newOv = ovCur + extra; 
        if (newOv > ovLimit) newOv = ovLimit;
        let unit = max * 0.01, points = Math.floor(newOv / unit);  // 每 1% 灵气上限 = 1 稳固值
        d.根基.稳固值 = points; 
        d.根基.溢出的灵气 = newOv.toFixed(2) + '/' + ovLimit.toFixed(2); 
        ovCur = newOv;
    } else { 
        d.根基.溢出的灵气 = ovCur.toFixed(2) + '/' + ovLimit.toFixed(2); 
    }
    
    // 更新修为境界
    d.修为 = KOMUTECH_L_X_PT_cultivation(cur).stage;
    
    // 检测小阶段突破（境界变化）
    if (oldStage && oldStage !== d.修为) {
        let hasFailureMark = (d.突破失败 === true);
        if (!hasFailureMark) {
            // 无失败标记：奖励属性点 + 随机基础属性
            d.属性点 = (d.属性点 || 0) + Math.floor(Math.random() * 4) + 3;
            if (Math.random() < 0.5) d.血量 = (d.血量 || 0) + 1;
            if (Math.random() < 0.5) d.攻击力 = (d.攻击力 || 0) + 1;
            if (Math.random() < 0.5) d.防御力 = (d.防御力 || 0) + 1;
            if (Math.random() < 0.5) d.速度 = (d.速度 || 0) + 1;
            p.sendMessage('§a恭喜！修为突破小阶段，获得属性点奖励！');
        } else {
            // 有失败标记：不给予奖励
            p.sendMessage('§c修为突破小阶段，但因突破失败标记，不给予属性点奖励。');
        }
    }
    
    KOMUTECH_L_X_PT_updateLingliMax(d);  // 更新灵力上限
    
    // 发送 ActionBar 状态提示
    if (cur >= max) {
        let overflowStr = d.根基.溢出的灵气 || '0.00/0.00';
        let overflowMatch = overflowStr.match(/^(\d+\.?\d*)\/(\d+\.?\d*)$/);
        let overflowCur = overflowMatch ? parseFloat(overflowMatch[1]) : 0;
        let overflowMax = overflowMatch ? parseFloat(overflowMatch[2]) : 0;
        let solid = d.根基.稳固值 || 0;
        p.sendActionBar(`§b溢出的灵气: §6${overflowCur.toFixed(2)} §7/ §6${overflowMax.toFixed(2)} §7| §b稳固值: §6${solid}`);
    } else {
        p.sendActionBar('§b灵气: §6' + cur.toFixed(2) + ' §7/ §6' + max);
    }
    
    KOMUTECH_L_X_PT_save(p, d);  // 保存数据
    return ovCur >= ovLimit;      // 返回溢出是否已满
}

// ============================================================
// 粒子效果函数
// ============================================================

/**
 * 在玩家周围生成粒子效果
 * @param {Player} p - 玩家对象
 * @param {Particle} type - 粒子类型
 * @param {number} bcnt - 基础粒子数
 * @param {number} rRange - 半径范围
 * @param {number} yRange - 高度范围
 */
function KOMUTECH_L_X_PT_particles(p, type, bcnt, rRange, yRange) {
    let loc = p.getLocation(), w = p.getWorld(), cnt = bcnt + Math.floor(Math.random() * (bcnt / 2));  // 粒子数有随机波动
    for (let i = 0; i < cnt; i++) {
        let angle = Math.random() * 2 * Math.PI, radius = 0.6 + Math.random() * rRange;
        let x = loc.getX() + radius * Math.cos(angle), z = loc.getZ() + radius * Math.sin(angle);
        let y = loc.getY() + 0.5 + Math.random() * yRange;
        w.spawnParticle(type, x, y, z, 0, 0, 0, 0, 0);  // 生成粒子（无速度偏移）
    }
}

// ============================================================
// 监控任务系统
// ============================================================

// --- 需要监控的蒲团位置集合 ---
let KOMUTECH_L_X_PT_monitorLocs = new java.util.HashSet(), 
    KOMUTECH_L_X_PT_monitorTaskId = null;  // 监控任务 ID

/**
 * 确保监控任务正在运行（懒加载）
 * 每 60 tick（3 秒）扫描一次所有活跃蒲团
 */
function KOMUTECH_L_X_PT_ensureMonitor() {
    if (KOMUTECH_L_X_PT_monitorTaskId !== null) return;  // 已在运行
    let task = Java.extend(Java.type('java.lang.Runnable'), { 
        run: function() {
            let iter = KOMUTECH_L_X_PT_monitorLocs.iterator();
            while (iter.hasNext()) {
                let loc = iter.next(), st = KOMUTECH_L_X_PT_getState(loc); 
                // 状态异常则从监控列表移除
                if (st !== 1 && st !== 2) { iter.remove(); continue; }
                
                let uid = KOMUTECH_L_X_PT_getSeatUUID(loc); 
                if (!uid) { KOMUTECH_L_X_PT_setState(loc, 0); iter.remove(); continue; }
                
                let seat = KOMUTECH_L_X_PT_findSeat(loc, uid);
                // 座位不存在或玩家已离开则清理
                if (!seat || seat.isDead() || seat.getPassengers().isEmpty()) { 
                    KOMUTECH_L_X_PT_cleanup(loc, null); 
                    KOMUTECH_L_X_PT_setState(loc, 0); 
                    iter.remove(); 
                    continue; 
                }
                
                // 修炼状态：增加灵气
                if (st === 1) {
                    let pass = seat.getPassengers().get(0);
                    if (pass instanceof Java.type('org.bukkit.entity.Player') && pass.isOnline()) {
                        let d = KOMUTECH_L_X_PT_load(pass); if (!d) continue;
                        let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气), 
                            full = KOMUTECH_L_X_PT_addSpirit(pass, loc);
                        KOMUTECH_L_X_PT_particles(pass, KOMUTECH_L_X_PT_Particle.END_ROD, 3, 0.4, 1.0);  // 末地烛粒子效果
                        // 溢出满则自动结束修炼
                        if (full && cur >= max) { 
                            pass.sendMessage('§6溢出的灵气已达上限，修炼自动结束。'); 
                            KOMUTECH_L_X_PT_cleanup(loc, pass); 
                            KOMUTECH_L_X_PT_setState(loc, 0); 
                            iter.remove(); 
                        }
                    }
                }
            }
            // 无活跃蒲团则停止监控任务
            if (KOMUTECH_L_X_PT_monitorLocs.isEmpty()) { 
                if (KOMUTECH_L_X_PT_monitorTaskId) KOMUTECH_L_X_PT_Bukkit.getScheduler().cancelTask(KOMUTECH_L_X_PT_monitorTaskId); 
                KOMUTECH_L_X_PT_monitorTaskId = null; 
            }
        }
    });
    KOMUTECH_L_X_PT_monitorTaskId = KOMUTECH_L_X_PT_Bukkit.getScheduler().runTaskTimer(KOMUTECH_L_X_PT_plugin, new task(), 0, 60).getTaskId();
}

// ============================================================
// GUI 事件监听系统
// ============================================================

// --- GUI 状态变量 ---
let KOMUTECH_L_X_PT_openPlayers = new java.util.HashSet(),       // 当前打开 GUI 的玩家集合
    KOMUTECH_L_X_PT_playerLocMap = new java.util.HashMap(),      // 玩家 -> 蒲团位置映射
    KOMUTECH_L_X_PT_menuListener = null,                         // 事件监听器实例
    KOMUTECH_L_X_PT_listenerActive = false;                      // 监听器是否已注册

/**
 * 注销 GUI 事件监听器
 */
function KOMUTECH_L_X_PT_unreg() { 
    if (KOMUTECH_L_X_PT_menuListener) { 
        try { KOMUTECH_L_X_PT_InvClick.getHandlerList().unregister(KOMUTECH_L_X_PT_menuListener); } catch (e) {} 
        try { KOMUTECH_L_X_PT_InvClose.getHandlerList().unregister(KOMUTECH_L_X_PT_menuListener); } catch (e) {} 
        KOMUTECH_L_X_PT_menuListener = null; 
        KOMUTECH_L_X_PT_listenerActive = false; 
    } 
}

/**
 * 注册 GUI 事件监听器（InventoryClick + InventoryClose）
 * 使用懒加载：当第一个玩家打开 GUI 时注册，所有玩家关闭后注销
 */
function KOMUTECH_L_X_PT_reg() {
    if (KOMUTECH_L_X_PT_listenerActive) return;
    let Impl = Java.extend(Java.type('org.bukkit.event.Listener'), {}); 
    KOMUTECH_L_X_PT_menuListener = new Impl();
    
    // 注册背包点击事件
    KOMUTECH_L_X_PT_Bukkit.getPluginManager().registerEvent(KOMUTECH_L_X_PT_InvClick, KOMUTECH_L_X_PT_menuListener, KOMUTECH_L_X_PT_EventPriority.NORMAL, (l, e) => {
        let p = e.getWhoClicked(); 
        // 过滤非本系统 GUI 的点击
        if (!KOMUTECH_L_X_PT_openPlayers.contains(p) || e.getInventory().getTitle() !== '§d修炼蒲团') return;
        e.setCancelled(true);  // 禁止移动物品
        let slot = e.getSlot(), it = e.getCurrentItem(); 
        if (!it || it.getType() === KOMUTECH_L_X_PT_Material.AIR) return;
        
        let loc = KOMUTECH_L_X_PT_playerLocMap.get(p); 
        if (!loc) { p.closeInventory(); return; } 
        let st = KOMUTECH_L_X_PT_getState(loc);
        
        // 槽位 3：修炼开关
        if (slot === 3) {
            if (st === 0) {
                // 开始修炼
                let sfItem = StorageCacheUtils.getSfItem(loc);
                let mid = sfItem ? sfItem.getId() : KOMUTECH_L_X_PT_DEFAULT_ID;
                StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY, mid);
                let seat = KOMUTECH_L_X_PT_createSeat(loc, p, KOMUTECH_L_X_PT_Color.WHITE, true);  // 白色头盔 = 修炼
                KOMUTECH_L_X_PT_setState(loc, 1); 
                KOMUTECH_L_X_PT_setSeatUUID(loc, seat.getUniqueId()); 
                KOMUTECH_L_X_PT_monitorLocs.add(loc); 
                KOMUTECH_L_X_PT_ensureMonitor(); 
                p.sendMessage('§a你开始修炼了。');
            } else if (st === 1) { 
                // 停止修炼
                KOMUTECH_L_X_PT_cleanup(loc, p); 
                KOMUTECH_L_X_PT_setState(loc, 0); 
                KOMUTECH_L_X_PT_monitorLocs.remove(loc); 
                p.sendMessage('§e你停止了修炼。'); 
            } else p.sendMessage('§c请先停止突破。'); 
            p.closeInventory();
        } 
        // 槽位 5：突破开关
        else if (slot === 5) {
            if (st === 0) {
                // 开始突破（需灵气已满）
                let d = KOMUTECH_L_X_PT_load(p); 
                if (!d) { p.sendMessage('§c无法读取玩家数据'); p.closeInventory(); return; }
                let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气); 
                if (cur < max) { p.sendMessage('§c灵气未满，无法突破'); p.closeInventory(); return; }
                
                let sfItem = StorageCacheUtils.getSfItem(loc);
                let mid = sfItem ? sfItem.getId() : KOMUTECH_L_X_PT_DEFAULT_ID;
                StorageCacheUtils.setData(loc, KOMUTECH_L_X_PT_PRAYER_MAT_ID_KEY, mid);
                let seat = KOMUTECH_L_X_PT_createSeat(loc, p, KOMUTECH_L_X_PT_Color.RED, true);  // 红色头盔 = 突破
                KOMUTECH_L_X_PT_setState(loc, 2); 
                KOMUTECH_L_X_PT_setSeatUUID(loc, seat.getUniqueId()); 
                KOMUTECH_L_X_PT_monitorLocs.add(loc); 
                KOMUTECH_L_X_PT_ensureMonitor(); 
                p.sendMessage('§a你开始突破了！'); 
                p.closeInventory(); 
                KOMUTECH_L_X_PT_startBreak(loc, p, d);  // 启动突破流程
            } else if (st === 2) { 
                // 停止突破
                KOMUTECH_L_X_PT_cancelTask(loc); 
                KOMUTECH_L_X_PT_cancelTribulationTask(loc); 
                KOMUTECH_L_X_PT_cleanup(loc, p); 
                KOMUTECH_L_X_PT_setState(loc, 0); 
                KOMUTECH_L_X_PT_monitorLocs.remove(loc); 
                p.sendMessage('§e你停止了突破。'); 
                p.closeInventory(); 
            } else p.sendMessage('§c请先停止修炼。'); 
            p.closeInventory();
        } 
        // 槽位 8：强制关闭重置
        else if (slot === 8) { 
            KOMUTECH_L_X_PT_cancelTask(loc); 
            KOMUTECH_L_X_PT_cancelTribulationTask(loc); 
            KOMUTECH_L_X_PT_cleanup(loc, p); 
            KOMUTECH_L_X_PT_setState(loc, 0); 
            KOMUTECH_L_X_PT_monitorLocs.remove(loc); 
            p.closeInventory(); 
        }
    }, KOMUTECH_L_X_PT_plugin);
    
    // 注册背包关闭事件
    KOMUTECH_L_X_PT_Bukkit.getPluginManager().registerEvent(KOMUTECH_L_X_PT_InvClose, KOMUTECH_L_X_PT_menuListener, KOMUTECH_L_X_PT_EventPriority.NORMAL, (l, e) => { 
        let p = e.getPlayer(); 
        if (KOMUTECH_L_X_PT_openPlayers.remove(p)) KOMUTECH_L_X_PT_playerLocMap.remove(p); 
        if (KOMUTECH_L_X_PT_openPlayers.isEmpty()) KOMUTECH_L_X_PT_unreg();  // 无人使用时注销监听器
    }, KOMUTECH_L_X_PT_plugin);
    
    KOMUTECH_L_X_PT_listenerActive = true;
}

// ============================================================
// 突破流程系统
// ============================================================

/**
 * 启动突破流程（15 个周期，每 3 秒一次，共 45 秒）
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 */
function KOMUTECH_L_X_PT_startBreak(loc, p, d) {
    let key = KOMUTECH_L_X_PT_locKey(loc); 
    KOMUTECH_L_X_PT_cancelTask(loc); 
    KOMUTECH_L_X_PT_cancelTribulationTask(loc);
    
    // 计算突破成功率：基础 25% + 稳固值 + 破镜药力（上限 100%）
    let solid = (d.根基 || {}).稳固值 || 0, drug = (d.根基 || {}).破镜药力 || 0;
    let rate = Math.min(25 + solid + drug, 100), 
        success = Math.random() * 100 < rate;  // 预先判定是否成功
    
    p.sendMessage('§6突破中... 成功率: §e' + rate + '%'); 
    let taskId = null, tick = 0;
    
    // 突破动画任务（每 3 秒执行一次）
    let runnable = Java.extend(Java.type('java.lang.Runnable'), { 
        run: function() {
            tick++; 
            if (p.isOnline()) KOMUTECH_L_X_PT_particles(p, KOMUTECH_L_X_PT_Particle.HAPPY_VILLAGER, 8, 0.6, 1.8);  // 快乐村民粒子
            // 突破时间到，执行结果
            if (tick >= KOMUTECH_L_X_PT_BREAK_DUR) { 
                KOMUTECH_L_X_PT_Bukkit.getScheduler().cancelTask(taskId); 
                KOMUTECH_L_X_PT_tasks.remove(key); 
                KOMUTECH_L_X_PT_finishBreak(loc, p, d, success); 
            }
        }
    });
    taskId = KOMUTECH_L_X_PT_Bukkit.getScheduler().runTaskTimer(KOMUTECH_L_X_PT_plugin, new runnable(), 0, 60).getTaskId(); 
    KOMUTECH_L_X_PT_tasks.put(key, taskId);
}

/**
 * 突破结束处理
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 * @param {boolean} ok - 是否突破成功
 */
function KOMUTECH_L_X_PT_finishBreak(loc, p, d, ok) {
    // 突破失败处理
    if (!ok) {
        let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气);
        let baseReduce = 0.15 + Math.random() * 0.15;  // 基础损失 15%~30%
        let reduction = ((d.根基 || {}).保阶药力 || 0) / 100;  // 保阶药力减免
        let reduce = Math.max(0, baseReduce - reduction);  // 最终损失比例
        let reduced = cur * (1 - reduce); 
        if (reduced < 0) reduced = 0;
        d.灵气 = reduced.toFixed(2) + '/' + max; 
        d.根基.破镜药力 = 0; 
        d.根基.保阶药力 = 0;
        d.突破失败 = true;  // 标记突破失败
        p.sendMessage('§c突破失败... 灵气损失了 ' + (reduce * 100).toFixed(0) + '%');
        KOMUTECH_L_X_PT_save(p, d); 
        KOMUTECH_L_X_PT_cleanup(loc, p); 
        KOMUTECH_L_X_PT_setState(loc, 0); 
        KOMUTECH_L_X_PT_monitorLocs.remove(loc);
        return;
    }
    
    // 突破成功：灵气上限 ×10
    let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气);
    let nmax = max * 10; 
    if (nmax > 100000000000000) nmax = 100000000000000;  // 上限封顶
    
    // 高境界需要渡雷劫
    if (nmax >= 100000) {
        let tribCount = 0;
        for (let t in KOMUTECH_L_X_PT_TRIBULATION_MAP) { 
            if (nmax >= parseInt(t)) tribCount = KOMUTECH_L_X_PT_TRIBULATION_MAP[t]; 
        }
        p.sendMessage('§c§l雷劫降临！需承受 ' + tribCount + ' 道天雷！');
        KOMUTECH_L_X_PT_startTribulation(loc, p, d, nmax, tribCount, 1, cur);  // 启动渡劫
    } else {
        KOMUTECH_L_X_PT_applyBreakSuccess(loc, p, d, nmax, cur);  // 直接成功
    }
}

// ============================================================
// 雷劫渡劫系统
// ============================================================

/**
 * 启动/继续雷劫序列
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 * @param {number} nmax - 新灵气上限
 * @param {number} total - 总雷劫道数
 * @param {number} current - 当前雷劫序号
 * @param {number} cur - 突破前灵气值
 */
function KOMUTECH_L_X_PT_startTribulation(loc, p, d, nmax, total, current, cur) {
    // 玩家离线或死亡则渡劫失败
    if (!p.isOnline() || p.isDead()) { 
        p.sendMessage('§c渡劫失败...'); 
        KOMUTECH_L_X_PT_failTribulation(loc, p, d); 
        return; 
    }
    // 雷劫全部完成
    if (current > total) { 
        p.sendMessage('§a§l雷劫渡过！突破成功！'); 
        KOMUTECH_L_X_PT_applyBreakSuccess(loc, p, d, nmax, cur); 
        return; 
    }
    
    p.sendMessage('§e第 ' + current + '/' + total + ' 道雷劫');
    let world = p.getWorld(), locP = p.getLocation();
    world.strikeLightning(locP);  // 召唤闪电
    
    // 计算雷劫伤害（综合多属性）
    let baseDmg = (d.血量 || 0) * 3;  // 基础伤害与血量挂钩
    let realmMult = KOMUTECH_L_X_PT_realmCoeff(cur);  // 境界系数
    let els = (d.灵根 || '').split('、').filter(e => e);
    let q = parseFloat(d.总品质) || 0.5;
    let linggenMult = KOMUTECH_L_X_PT_linggenFinal(els, q);  // 灵根系数
    let shaQiMult = 1 + (d.煞气 || 0) / 10000;  // 煞气增伤
    let genguReduce = Math.min((d.根骨 || 0) * 0.03, 0.8);  // 根骨减伤（上限 80%）
    let genguMult = 1 - genguReduce;
    let growth = Math.pow(1.05, current - 1);  // 每道雷劫伤害递增 5%
    
    let finalDmg = baseDmg * realmMult * linggenMult * shaQiMult * genguMult * growth;
    let defenseReduce = (d['防御力_实际'] || 0) * (d['根骨'] || 0);  // 防御减免
    finalDmg = Math.max(1, Math.floor(finalDmg - defenseReduce));
    
    // 功德抵消伤害（每 100 功德抵消 1 点伤害）
    let gongDeReduce = Math.floor((d.功德 || 0) / 100);
    let reduced = Math.min(finalDmg, gongDeReduce);
    finalDmg = Math.max(1, Math.floor(finalDmg - reduced));
    d.功德 = (d.功德 || 0) - reduced * 100;  // 扣除功德
    
    p.damage(finalDmg);  // 造成伤害
    p.sendMessage('§c受到了 ' + finalDmg + ' 点雷劫伤害');
    
    // 玩家死亡则渡劫失败
    if (p.isDead()) { 
        p.sendMessage('§c你未能承受雷劫...'); 
        KOMUTECH_L_X_PT_failTribulation(loc, p, d); 
        return; 
    }
    
    KOMUTECH_L_X_PT_save(p, d);  // 保存数据
    
    // 3 秒后下一道雷劫
    let nextTask = Java.extend(Java.type('java.lang.Runnable'), { 
        run: function() { KOMUTECH_L_X_PT_startTribulation(loc, p, d, nmax, total, current + 1, cur); } 
    });
    let taskId = KOMUTECH_L_X_PT_Bukkit.getScheduler().runTaskLater(KOMUTECH_L_X_PT_plugin, new nextTask(), 60).getTaskId();
    KOMUTECH_L_X_PT_tasks.put(KOMUTECH_L_X_PT_locKey(loc) + '_trib', taskId);
}

/**
 * 渡劫失败处理（与突破失败类似）
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 */
function KOMUTECH_L_X_PT_failTribulation(loc, p, d) {
    let { cur, max } = KOMUTECH_L_X_PT_parseSpirit(d.灵气);
    let baseReduce = 0.15 + Math.random() * 0.15;
    let reduction = ((d.根基 || {}).保阶药力 || 0) / 100;
    let reduce = Math.max(0, baseReduce - reduction);
    let reduced = cur * (1 - reduce); 
    if (reduced < 0) reduced = 0;
    d.灵气 = reduced.toFixed(2) + '/' + max; 
    d.根基.破镜药力 = 0; 
    d.根基.保阶药力 = 0;
    d.突破失败 = true;
    p.sendMessage('§c雷劫失败... 灵气损失了 ' + (reduce * 100).toFixed(0) + '%');
    KOMUTECH_L_X_PT_save(p, d); 
    KOMUTECH_L_X_PT_cleanup(loc, p); 
    KOMUTECH_L_X_PT_setState(loc, 0); 
    KOMUTECH_L_X_PT_monitorLocs.remove(loc);
}

// ============================================================
// 突破成功结算（与之前版本相同，用于完整注释）
// ============================================================

/**
 * 突破/渡劫成功后的最终结算
 * 重置灵气、更新境界、发放奖励、清理状态
 * @param {Location} loc - 蒲团位置
 * @param {Player} p - 玩家对象
 * @param {Object} d - 玩家数据对象
 * @param {number} nmax - 新灵气上限
 * @param {number} cur - 突破前灵气值
 */
function KOMUTECH_L_X_PT_applyBreakSuccess(loc, p, d, nmax, cur) {
    // 新灵气 = 新上限的 10% + 1（保底）
    let ncur = nmax / 10 + 1; 
    if (ncur > nmax) ncur = nmax; 
    d.灵气 = ncur.toFixed(2) + '/' + nmax; 
    d.修为 = KOMUTECH_L_X_PT_cultivation(ncur).stage;  // 更新境界
    
    KOMUTECH_L_X_PT_updateLingliMax(d);  // 更新灵力上限
    let ovLimit = Math.floor((d.根骨 / 10) * nmax * 100) / 100;
    d.突破失败 = false;  // 清除失败标记
    
    // 判断是否使用了辅助丹药
    let hasDrug = ((d.根基 || {}).破镜药力 || 0) > 0;
    let hasTribDrug = ((d.根基 || {}).保阶药力 || 0) > 0;
    
    // 使用丹药时奖励较少，无丹药时奖励更多
    if (hasDrug || hasTribDrug) {
        d.属性点 = (d.属性点 || 0) + Math.floor(Math.random() * 6) + 5;
    } else {
        d.属性点 = (d.属性点 || 0) + 10;
        // 额外概率提升基础四维
        if (Math.random() < 0.5) d.血量 = (d.血量 || 0) + 1;
        if (Math.random() < 0.5) d.攻击力 = (d.攻击力 || 0) + 1;
        if (Math.random() < 0.5) d.防御力 = (d.防御力 || 0) + 1;
        if (Math.random() < 0.5) d.速度 = (d.速度 || 0) + 1;
    }
    
    // 重置根基数据
    d.根基 = { 稳固值: 0, 溢出的灵气: '0.00/' + ovLimit.toFixed(2), 破镜药力: 0, 保阶药力: 0 };
    
    p.playSound(p.getLocation(), 'entity.experience_orb.pickup', 1.0, 1.0);  // 成功音效
    p.sendMessage('§a§l恭喜！突破成功！修为提升至 ' + d.修为 + '，获得属性点奖励！');
    
    // 保存并清理
    KOMUTECH_L_X_PT_save(p, d); 
    KOMUTECH_L_X_PT_cleanup(loc, p); 
    KOMUTECH_L_X_PT_setState(loc, 0); 
    KOMUTECH_L_X_PT_monitorLocs.remove(loc);
}

// ============================================================
// GUI 菜单构建
// ============================================================

/**
 * 打开蒲团管理 GUI 菜单
 * @param {Player} p - 玩家对象
 * @param {Location} loc - 蒲团位置
 */
function KOMUTECH_L_X_PT_openMenu(p, loc) {
    let st = KOMUTECH_L_X_PT_getState(loc),  // 获取当前状态
        inv = KOMUTECH_L_X_PT_Bukkit.createInventory(null, 9, '§d修炼蒲团');  // 创建 9 格背包
    
    // 槽位 0-2：灰色玻璃板装饰
    inv.setItem(0, KOMUTECH_L_X_PT_createItem('GRAY_STAINED_GLASS_PANE', '§7 ', [])); 
    inv.setItem(1, KOMUTECH_L_X_PT_createItem('GRAY_STAINED_GLASS_PANE', '§7 ', [])); 
    inv.setItem(2, KOMUTECH_L_X_PT_createItem('GRAY_STAINED_GLASS_PANE', '§7 ', []));
    
    // 槽位 3：修炼按钮（根据状态切换）
    inv.setItem(3, st === 1 ? KOMUTECH_L_X_PT_createItem('REDSTONE', '§c■ 停止修炼 ■', ['§7点击结束修炼']) : KOMUTECH_L_X_PT_createItem('EMERALD', '§a✦ 开始修炼 ✦', ['§7点击坐下并开始修炼']));
    
    // 槽位 4：状态显示
    let status = st === 0 ? '§7○ 空闲' : (st === 1 ? '§a● 修炼中' : '§d● 突破中'); 
    inv.setItem(4, KOMUTECH_L_X_PT_createItem('BOOK', status, ['§7当前状态']));
    
    // 槽位 5：突破按钮（根据状态
    inv.setItem(5, st === 2 ? KOMUTECH_L_X_PT_createItem('REDSTONE', '§c■ 停止突破 ■', ['§7点击结束突破']) : KOMUTECH_L_X_PT_createItem('DIAMOND', '§b✦ 开始突破 ✦', ['§7点击坐下并开始突破']));
    
    // 槽位 6-7：灰色玻璃板装饰
    inv.setItem(6, KOMUTECH_L_X_PT_createItem('GRAY_STAINED_GLASS_PANE', '§7 ', [])); 
    inv.setItem(7, KOMUTECH_L_X_PT_createItem('GRAY_STAINED_GLASS_PANE', '§7 ', []));
    
    // 槽位 8：强制关闭重置按钮
    inv.setItem(8, KOMUTECH_L_X_PT_createItem('BARRIER', '§c关闭并重置', ['§7强制清理并关闭']));
    
    // 打开背包界面
    p.openInventory(inv);
}

// ============================================================
// Slimefun 脚本入口函数
// ============================================================

/**
 * Slimefun 物品使用事件入口
 * 玩家右键点击蒲团方块时触发，打开管理菜单
 * @param {Event} e - Slimefun 的 use 事件
 */
function onUse(e) { 
    // 仅响应主手交互，忽略副手
    if (e.getHand() !== KOMUTECH_L_X_PT_EquipmentSlot.HAND) return; 
    let p = e.getPlayer(), b = e.getClickedBlock(); 
    // 检查点击的方块是否存在
    if (!b || !b.isPresent()) return; 
    let loc = b.get().getLocation(), sf = StorageCacheUtils.getSfItem(loc); 
    // 检查是否为已配置的蒲团类型（通过 MAT_CONFIG 配置表验证）
    if (!sf || !KOMUTECH_L_X_PT_MAT_CONFIG.hasOwnProperty(sf.getId())) return; 
    
    // 记录玩家与蒲团位置的映射关系
    KOMUTECH_L_X_PT_playerLocMap.put(p, loc); 
    KOMUTECH_L_X_PT_openPlayers.add(p);
    // 重新注册 GUI 事件监听器
    KOMUTECH_L_X_PT_unreg(); 
    KOMUTECH_L_X_PT_reg(); 
    // 打开蒲团管理菜单
    KOMUTECH_L_X_PT_openMenu(p, loc); 
}

/**
 * Slimefun 方块破坏事件入口
 * 蒲团方块被破坏时触发，清理所有关联实体、任务和玩家状态
 * @param {Event} e - Slimefun 的 break 事件
 * @param {ItemStack} it - 破坏工具
 * @param {Array} drops - 掉落物列表
 */
function onBreak(e, it, drops) { 
    let loc = e.getBlock().getLocation(), sf = StorageCacheUtils.getSfItem(loc); 
    // 检查是否为已配置的蒲团类型
    if (!sf || !KOMUTECH_L_X_PT_MAT_CONFIG.hasOwnProperty(sf.getId())) return; 
    
    // 取消该位置的所有定时任务（修炼任务 + 渡劫任务）
    KOMUTECH_L_X_PT_cancelTask(loc); 
    KOMUTECH_L_X_PT_cancelTribulationTask(loc);
    
    // 清理座位实体、投影实体及玩家骑乘状态
    KOMUTECH_L_X_PT_cleanup(loc, null);
    
    // 重置蒲团状态为空闲
    KOMUTECH_L_X_PT_setState(loc, 0); 
    KOMUTECH_L_X_PT_setSeatUUID(loc, null); 
    KOMUTECH_L_X_PT_setProjUUID(loc, null);
    
    // 从监控列表中移除
    KOMUTECH_L_X_PT_monitorLocs.remove(loc);
    
    // 遍历所有打开 GUI 的玩家，关闭正在查看该蒲团界面的玩家的背包
    let iter = KOMUTECH_L_X_PT_playerLocMap.entrySet().iterator(); 
    while (iter.hasNext()) { 
        let en = iter.next(); 
        // 如果玩家查看的是当前被破坏的蒲团
        if (en.getValue().equals(loc)) { 
            en.getKey().closeInventory();  // 强制关闭背包
            iter.remove();                   // 从位置映射中移除
            KOMUTECH_L_X_PT_openPlayers.remove(en.getKey());  // 从打开集合中移除
        } 
    } 
}