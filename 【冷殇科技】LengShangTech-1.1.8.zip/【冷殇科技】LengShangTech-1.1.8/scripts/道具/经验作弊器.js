let isWaitingForInput = false;
let Bukkit = Java.type('org.bukkit.Bukkit');
let Consumer = Java.type('java.util.function.Consumer');

// ========== 配置区域 ==========
const MAX_LEVEL_LIMIT = 100;  // 最高限制每次提升100级
const VALUE_LORE_PREFIX = "§7每次提升: §6";
const INTEGER_MAX = 2147483647;

function onUse(event) {
    const player = event.getPlayer();
    const item = event.getItem();

    // 基础验证
    if (!item || item.getType().isAir()) {
        player.sendMessage("§c❌ 请手持等级作弊器");
        event.cancel();
        return;
    }

    if (player.isSneaking()) {
        handleSneakRightClick(player, item);
    } else {
        handleNormalRightClick(player, item);
    }
    
    event.cancel();
}

// 蹲下右键：输入目标等级（带限制）
function handleSneakRightClick(player, item) {
    if (isWaitingForInput) {
        player.sendMessage("§c⚠️ 你已经在输入状态中");
        return;
    }

    const currentValue = getStoredValue(item);
    if (currentValue !== null) {
        player.sendMessage("§6当前每次提升: §b" + formatNumber(currentValue) + " 级");
    }

    player.sendMessage("§6请输入每次要提升的等级数量：");
    player.sendMessage("§7支持格式: 1-100 §c最高限制: " + MAX_LEVEL_LIMIT + "级");
    player.sendMessage("§7输入 'cancel' 取消操作");

    isWaitingForInput = true;

    let JSConsumer = Java.extend(Consumer, {
        accept: function(input) {
            isWaitingForInput = false;
            input = input.trim();

            if (input.toLowerCase() === "cancel") {
                player.sendMessage("§a✅ 已取消操作");
                return;
            }

            const num = parseInputNumber(input);
            if (num === null || num <= 0) {
                player.sendMessage("§c❌ 请输入有效的正整数！");
                return;
            }

            // ========== 等级限制检查 ==========
            if (num > MAX_LEVEL_LIMIT) {
                player.sendMessage("§c❌ 设置的等级过高！");
                player.sendMessage("§7最大允许设置: §e" + MAX_LEVEL_LIMIT + "级");
                player.sendMessage("§7你输入了: §c" + formatNumber(num) + "级");
                return;
            }
            // =================================

            const currentItem = player.getInventory().getItemInMainHand();
            if (!currentItem || currentItem.getType().isAir()) {
                player.sendMessage("§c❌ 主手工具已空");
                return;
            }

            if (setStoredValue(currentItem, num)) {
                player.sendMessage("§a✅ 每次提升等级已设置为: §b" + formatNumber(num) + " 级");
                player.sendMessage("§7请使用普通右键提升等级");
            }
        }
    });

    getChatInput(player, new JSConsumer());
}

// 普通右键：应用等级提升
function handleNormalRightClick(player, item) {
    const targetLevel = getStoredValue(item);
    if (targetLevel === null || targetLevel <= 0) {
        player.sendMessage("§c❌ 请先蹲下右键设置要提升的等级数量");
        player.sendMessage("§7例如输入: 20 (表示每次右键增加20级)");
        return;
    }

    const currentLevel = player.getLevel();
    const newLevel = currentLevel + targetLevel;
    
    // 检查溢出
    if (newLevel > INTEGER_MAX) {
        player.sendMessage("§c❌ 提升后的等级超过游戏限制！");
        return;
    }

    // 提升等级
    player.setLevel(newLevel);
    
    player.sendMessage("§a✅ 等级提升成功！");
    player.sendMessage("§7原等级: §f" + formatNumber(currentLevel));
    player.sendMessage("§7新等级: §b" + formatNumber(newLevel));
    player.sendMessage("§7本次增加: §a+" + formatNumber(targetLevel) + " 级");
}

// 从Lore读取存储的数值
function getStoredValue(item) {
    if (!item || !item.hasItemMeta()) return null;
    const lore = item.getItemMeta().getLore();
    if (!lore) return null;
    
    for (let i = 0; i < lore.size(); i++) {
        const line = lore.get(i);
        if (line.startsWith(VALUE_LORE_PREFIX)) {
            const numStr = line.substring(VALUE_LORE_PREFIX.length);
            // 移除可能的逗号和"级"字样，只保留数字
            const cleanNum = numStr.replace(/[,\s级]/g, '');
            const val = parseInt(cleanNum);
            return isNaN(val) ? null : val;
        }
    }
    return null;
}

// 保存数值到Lore
function setStoredValue(item, value) {
    if (!item || !item.hasItemMeta()) return false;
    const meta = item.getItemMeta();
    const lore = meta.hasLore() ? meta.getLore() : [];
    
    let updated = false;
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(VALUE_LORE_PREFIX)) {
            lore.set(i, VALUE_LORE_PREFIX + formatNumber(value) + " 级");
            updated = true;
            break;
        }
    }
    if (!updated) lore.add(VALUE_LORE_PREFIX + formatNumber(value) + " 级");
    
    meta.setLore(lore);
    item.setItemMeta(meta);
    return true;
}

// 解析输入的数字（支持 k, m, 后缀）
function parseInputNumber(input) {
    try {
        input = input.trim().toLowerCase();
        let multiplier = 1;
        
        if (input.endsWith('m')) multiplier = 1000000;
        else if (input.endsWith('k')) multiplier = 1000;
        
        if (multiplier !== 1) input = input.slice(0, -1);
        
        const number = parseFloat(input);
        return isNaN(number) ? null : Math.floor(number * multiplier);
    } catch (e) {
        return null;
    }
}

// 格式化数字（添加千分位逗号）
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}