/*******************************************************************
 * 触发：右键主手使用
 * 行为：强制掉落 + 20 tick 不可拾取 + 惩罚/刷怪/结构/物品
 * 注：vanilla 条目已移除 name 字段，保留原版物品名称，不写入任何 NBT
 *******************************************************************/
const ItemStack   = Java.type('org.bukkit.inventory.ItemStack');
const Material    = Java.type('org.bukkit.Material');
const ChatColor   = Java.type('org.bukkit.ChatColor');

/* 1.21 药水 API */
const Registry        = Java.type('org.bukkit.Registry');
const NamespacedKey   = Java.type('org.bukkit.NamespacedKey');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const DurationTicks   = 20 * 15;

/* 掉落物控制 */
const PickupDelay = 20; // 1 秒不可拾取

/* 随机整数 [min, max] */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* 1. 配置组 ====================================================== */
const SlimyGroup = [
    /* 普通单抽组 40% */
    {
        groupWeight: 50,
        allDrop: false,
        items: [
            { type: 'vanilla', id: 'OAK_LOG', amount: {min:1, max:64} },//橡木原木
            { type: 'vanilla', id: 'SPRUCE_LOG', amount: {min:1, max:64} },//云杉原木
            { type: 'vanilla', id: 'OAK_LOG', amount: {min:1, max:64} },//橡木原木
            { type: 'vanilla', id: 'SPRUCE_LOG', amount: {min:1, max:64} },//云杉原木
            { type: 'vanilla', id: 'BIRCH_LOG', amount: {min:1, max:64} },//白桦原木
            { type: 'vanilla', id: 'JUNGLE_LOG', amount: {min:1, max:64} },//丛林原木
            { type: 'vanilla', id: 'ACACIA_LOG', amount: {min:1, max:64} },//金合欢原木
            { type: 'vanilla', id: 'DARK_OAK_LOG', amount: {min:1, max:64} },//深色橡木原木
            { type: 'vanilla', id: 'CRIMSON_STEM', amount: {min:1, max:64} },//绯红菌柄
            { type: 'vanilla', id: 'WARPED_STEM', amount: {min:1, max:64} },//诡异菌柄
            { type: 'vanilla', id: 'MANGROVE_LOG', amount: {min:1, max:64} },//红树原木
            { type: 'vanilla', id: 'CHERRY_LOG', amount: {min:1, max:64} },//樱花原木
            { type: 'vanilla', id: 'BAMBOO_BLOCK', amount: {min:1, max:64} },//竹块

            { type: 'vanilla', id: 'OAK_LEAVES', amount: {min:1, max:64} },//橡树树叶
            { type: 'vanilla', id: 'SPRUCE_LEAVES', amount: {min:1, max:64} },//云杉树叶
            { type: 'vanilla', id: 'BIRCH_LEAVES', amount: {min:1, max:64} },//白桦树叶
            { type: 'vanilla', id: 'JUNGLE_LEAVES', amount: {min:1, max:64} },//丛林树叶
            { type: 'vanilla', id: 'ACACIA_LEAVES', amount: {min:1, max:64} },//金合欢树叶
            { type: 'vanilla', id: 'DARK_OAK_LEAVES', amount: {min:1, max:64} },//深色橡树树叶
            { type: 'vanilla', id: 'CRIMSON_NYLIUM', amount: {min:1, max:64} },//绯红菌岩
            { type: 'vanilla', id: 'WARPED_NYLIUM', amount: {min:1, max:64} },//诡异菌岩
            { type: 'vanilla', id: 'MANGROVE_LEAVES', amount: {min:1, max:64} },//红树树叶
            { type: 'vanilla', id: 'CHERRY_LEAVES', amount: {min:1, max:64} },//樱花树叶
            { type: 'vanilla', id: 'AZALEA_LEAVES', amount: {min:1, max:64} },//杜鹃树叶
            { type: 'vanilla', id: 'FLOWERING_AZALEA_LEAVES', amount: {min:1, max:64} },//开花杜鹃树叶

            { type: 'vanilla', id: 'OAK_SAPLING', amount: {min:1, max:64} },//橡树树苗
            { type: 'vanilla', id: 'SPRUCE_SAPLING', amount: {min:1, max:64} },//云杉树苗
            { type: 'vanilla', id: 'BIRCH_SAPLING', amount: {min:1, max:64} },//白桦树苗
            { type: 'vanilla', id: 'JUNGLE_SAPLING', amount: {min:1, max:64} },//丛林树苗
            { type: 'vanilla', id: 'ACACIA_SAPLING', amount: {min:1, max:64} },//金合欢树苗
            { type: 'vanilla', id: 'DARK_OAK_SAPLING', amount: {min:1, max:64} },//深色橡树树苗
            { type: 'vanilla', id: 'MANGROVE_PROPAGULE', amount: {min:1, max:64} },//红树胎生苗
            { type: 'vanilla', id: 'CHERRY_SAPLING', amount: {min:1, max:64} },//樱花树苗
            { type: 'vanilla', id: 'BAMBOO', amount: {min:1, max:64} },//竹子

            { type: 'vanilla', id: 'OAK_PLANKS', amount: {min:1, max:64} },//橡木木板
            { type: 'vanilla', id: 'SPRUCE_PLANKS', amount: {min:1, max:64} },//云杉木板
            { type: 'vanilla', id: 'BIRCH_PLANKS', amount: {min:1, max:64} },//白桦木板
            { type: 'vanilla', id: 'JUNGLE_PLANKS', amount: {min:1, max:64} },//丛林木板
            { type: 'vanilla', id: 'ACACIA_PLANKS', amount: {min:1, max:64} },//金合欢木板
            { type: 'vanilla', id: 'DARK_OAK_PLANKS', amount: {min:1, max:64} },//深色橡木木板
            { type: 'vanilla', id: 'CRIMSON_PLANKS', amount: {min:1, max:64} },//绯红木板
            { type: 'vanilla', id: 'WARPED_PLANKS', amount: {min:1, max:64} },//诡异木板
            { type: 'vanilla', id: 'MANGROVE_PLANKS', amount: {min:1, max:64} },//红树木板
            { type: 'vanilla', id: 'CHERRY_PLANKS', amount: {min:1, max:64} },//樱花木板
            { type: 'vanilla', id: 'BAMBOO_PLANKS', amount: {min:1, max:64} },//竹板

            { type: 'vanilla', id: 'OAK_PRESSURE_PLATE', amount: {min:1, max:64} },//橡木压力板
            { type: 'vanilla', id: 'SPRUCE_PRESSURE_PLATE', amount: {min:1, max:64} },//云杉压力板
            { type: 'vanilla', id: 'BIRCH_PRESSURE_PLATE', amount: {min:1, max:64} },//白桦压力板
            { type: 'vanilla', id: 'JUNGLE_PRESSURE_PLATE', amount: {min:1, max:64} },//丛林压力板
            { type: 'vanilla', id: 'ACACIA_PRESSURE_PLATE', amount: {min:1, max:64} },//金合欢压力板
            { type: 'vanilla', id: 'DARK_OAK_PRESSURE_PLATE', amount: {min:1, max:64} },//深色橡木压力板
            { type: 'vanilla', id: 'MANGROVE_PRESSURE_PLATE', amount: {min:1, max:64} },//红树压力板
            { type: 'vanilla', id: 'CHERRY_PRESSURE_PLATE', amount: {min:1, max:64} },//樱花压力板
            { type: 'vanilla', id: 'BAMBOO_PRESSURE_PLATE', amount: {min:1, max:64} },//竹压力板
            { type: 'vanilla', id: 'CRIMSON_PRESSURE_PLATE', amount: {min:1, max:64} },//绯木压力板
            { type: 'vanilla', id: 'WARPED_PRESSURE_PLATE', amount: {min:1, max:64} },//诡木压力板

            { type: 'vanilla', id: 'OAK_BUTTON', amount: {min:1, max:64} },//橡木按钮
            { type: 'vanilla', id: 'SPRUCE_BUTTON', amount: {min:1, max:64} },//云杉按钮
            { type: 'vanilla', id: 'BIRCH_BUTTON', amount: {min:1, max:64} },//白桦按钮
            { type: 'vanilla', id: 'JUNGLE_BUTTON', amount: {min:1, max:64} },//丛林按钮
            { type: 'vanilla', id: 'ACACIA_BUTTON', amount: {min:1, max:64} },//金合欢按钮
            { type: 'vanilla', id: 'DARK_OAK_BUTTON', amount: {min:1, max:64} },//深色橡木按钮
            { type: 'vanilla', id: 'MANGROVE_BUTTON', amount: {min:1, max:64} },//红树按钮
            { type: 'vanilla', id: 'CHERRY_BUTTON', amount: {min:1, max:64} },//樱花按钮
            { type: 'vanilla', id: 'BAMBOO_BUTTON', amount: {min:1, max:64} },//竹按钮
            { type: 'vanilla', id: 'CRIMSON_BUTTON', amount: {min:1, max:64} },//绯木按钮
            { type: 'vanilla', id: 'WARPED_BUTTON', amount: {min:1, max:64} },//诡木按钮

            { type: 'vanilla', id: 'OAK_STAIRS', amount: {min:1, max:64} },//橡木楼梯
            { type: 'vanilla', id: 'SPRUCE_STAIRS', amount: {min:1, max:64} },//云杉楼梯
            { type: 'vanilla', id: 'BIRCH_STAIRS', amount: {min:1, max:64} },//白桦楼梯
            { type: 'vanilla', id: 'JUNGLE_STAIRS', amount: {min:1, max:64} },//丛林楼梯
            { type: 'vanilla', id: 'ACACIA_STAIRS', amount: {min:1, max:64} },//金合欢楼梯
            { type: 'vanilla', id: 'DARK_OAK_STAIRS', amount: {min:1, max:64} },//深色橡木楼梯
            { type: 'vanilla', id: 'MANGROVE_STAIRS', amount: {min:1, max:64} },//红树楼梯
            { type: 'vanilla', id: 'CHERRY_STAIRS', amount: {min:1, max:64} },//樱花楼梯
            { type: 'vanilla', id: 'BAMBOO_STAIRS', amount: {min:1, max:64} },//竹楼梯
            { type: 'vanilla', id: 'CRIMSON_STAIRS', amount: {min:1, max:64} },//绯木楼梯
            { type: 'vanilla', id: 'WARPED_STAIRS', amount: {min:1, max:64} },//诡木楼梯

            { type: 'vanilla', id: 'OAK_SLAB', amount: {min:1, max:64} },//橡木台阶
            { type: 'vanilla', id: 'SPRUCE_SLAB', amount: {min:1, max:64} },//云杉台阶
            { type: 'vanilla', id: 'BIRCH_SLAB', amount: {min:1, max:64} },//白桦台阶
            { type: 'vanilla', id: 'JUNGLE_SLAB', amount: {min:1, max:64} },//丛林台阶
            { type: 'vanilla', id: 'ACACIA_SLAB', amount: {min:1, max:64} },//金合欢台阶
            { type: 'vanilla', id: 'DARK_OAK_SLAB', amount: {min:1, max:64} },//深色橡木台阶
            { type: 'vanilla', id: 'MANGROVE_SLAB', amount: {min:1, max:64} },//红树台阶
            { type: 'vanilla', id: 'CHERRY_SLAB', amount: {min:1, max:64} },//樱花台阶
            { type: 'vanilla', id: 'BAMBOO_SLAB', amount: {min:1, max:64} },//竹台阶
            { type: 'vanilla', id: 'CRIMSON_SLAB', amount: {min:1, max:64} },//绯木台阶
            { type: 'vanilla', id: 'WARPED_SLAB', amount: {min:1, max:64} },//诡木台阶

            { type: 'vanilla', id: 'OAK_FENCE', amount: {min:1, max:64} },//橡木栅栏
            { type: 'vanilla', id: 'SPRUCE_FENCE', amount: {min:1, max:64} },//云杉栅栏
            { type: 'vanilla', id: 'BIRCH_FENCE', amount: {min:1, max:64} },//白桦栅栏
            { type: 'vanilla', id: 'JUNGLE_FENCE', amount: {min:1, max:64} },//丛林栅栏
            { type: 'vanilla', id: 'ACACIA_FENCE', amount: {min:1, max:64} },//金合欢栅栏
            { type: 'vanilla', id: 'DARK_OAK_FENCE', amount: {min:1, max:64} },//深色橡木栅栏
            { type: 'vanilla', id: 'MANGROVE_FENCE', amount: {min:1, max:64} },//红树栅栏
            { type: 'vanilla', id: 'CHERRY_FENCE', amount: {min:1, max:64} },//樱花栅栏
            { type: 'vanilla', id: 'BAMBOO_FENCE', amount: {min:1, max:64} },//竹栅栏
            { type: 'vanilla', id: 'CRIMSON_FENCE', amount: {min:1, max:64} },//绯木栅栏
            { type: 'vanilla', id: 'WARPED_FENCE', amount: {min:1, max:64} },//诡木栅栏

            { type: 'vanilla', id: 'OAK_FENCE_GATE', amount: {min:1, max:64} },//橡木栅栏门
            { type: 'vanilla', id: 'SPRUCE_FENCE_GATE', amount: {min:1, max:64} },//云杉栅栏门
            { type: 'vanilla', id: 'BIRCH_FENCE_GATE', amount: {min:1, max:64} },//白桦栅栏门
            { type: 'vanilla', id: 'JUNGLE_FENCE_GATE', amount: {min:1, max:64} },//丛林栅栏门
            { type: 'vanilla', id: 'ACACIA_FENCE_GATE', amount: {min:1, max:64} },//金合欢栅栏门
            { type: 'vanilla', id: 'DARK_OAK_FENCE_GATE', amount: {min:1, max:64} },//深色橡木栅栏门
            { type: 'vanilla', id: 'MANGROVE_FENCE_GATE', amount: {min:1, max:64} },//红树栅栏门
            { type: 'vanilla', id: 'CHERRY_FENCE_GATE', amount: {min:1, max:64} },//樱花栅栏门
            { type: 'vanilla', id: 'BAMBOO_FENCE_GATE', amount: {min:1, max:64} },//竹栅栏门
            { type: 'vanilla', id: 'CRIMSON_FENCE_GATE', amount: {min:1, max:64} },//绯木栅栏门
            { type: 'vanilla', id: 'WARPED_FENCE_GATE', amount: {min:1, max:64} },//诡木栅栏门

            { type: 'vanilla', id: 'OAK_DOOR', amount: {min:1, max:64} },//橡木门
            { type: 'vanilla', id: 'SPRUCE_DOOR', amount: {min:1, max:64} },//云杉门
            { type: 'vanilla', id: 'BIRCH_DOOR', amount: {min:1, max:64} },//白桦门
            { type: 'vanilla', id: 'JUNGLE_DOOR', amount: {min:1, max:64} },//丛林门
            { type: 'vanilla', id: 'ACACIA_DOOR', amount: {min:1, max:64} },//金合欢门
            { type: 'vanilla', id: 'DARK_OAK_DOOR', amount: {min:1, max:64} },//深色橡木门
            { type: 'vanilla', id: 'MANGROVE_DOOR', amount: {min:1, max:64} },//红树门
            { type: 'vanilla', id: 'CHERRY_DOOR', amount: {min:1, max:64} },//樱花门
            { type: 'vanilla', id: 'BAMBOO_DOOR', amount: {min:1, max:64} },//竹门
            { type: 'vanilla', id: 'CRIMSON_DOOR', amount: {min:1, max:64} },//绯木门
            { type: 'vanilla', id: 'WARPED_DOOR', amount: {min:1, max:64} },//诡木门

            { type: 'vanilla', id: 'OAK_TRAPDOOR', amount: {min:1, max:64} },//橡木活板门
            { type: 'vanilla', id: 'SPRUCE_TRAPDOOR', amount: {min:1, max:64} },//云杉活板门
            { type: 'vanilla', id: 'BIRCH_TRAPDOOR', amount: {min:1, max:64} },//白桦活板门
            { type: 'vanilla', id: 'JUNGLE_TRAPDOOR', amount: {min:1, max:64} },//丛林活板门
            { type: 'vanilla', id: 'ACACIA_TRAPDOOR', amount: {min:1, max:64} },//金合欢活板门
            { type: 'vanilla', id: 'DARK_OAK_TRAPDOOR', amount: {min:1, max:64} },//深色橡木活板门
            { type: 'vanilla', id: 'MANGROVE_TRAPDOOR', amount: {min:1, max:64} },//红树活板门
            { type: 'vanilla', id: 'CHERRY_TRAPDOOR', amount: {min:1, max:64} },//樱花活板门
            { type: 'vanilla', id: 'BAMBOO_TRAPDOOR', amount: {min:1, max:64} },//竹活板门
            { type: 'vanilla', id: 'CRIMSON_TRAPDOOR', amount: {min:1, max:64} },//绯木活板门
            { type: 'vanilla', id: 'WARPED_TRAPDOOR', amount: {min:1, max:64} }//诡木活板门
        ]
    },
    /* 幸运套装 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'LENGSHANG_幸运头盔', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运胸甲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运护腿', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运靴子', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运剑', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运镐', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运斧', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运铲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_黄金切尔西', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_万能附魔书', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_击退棒', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_秒人斧', amount: 1 }
        ]
    },
    /* 原木 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'OAK_LOG', amount: 1 },//橡木原木
            { type: 'vanilla', id: 'SPRUCE_LOG', amount: 1 },//云杉原木
            { type: 'vanilla', id: 'OAK_LOG', amount: 1 },//橡木原木
            { type: 'vanilla', id: 'SPRUCE_LOG', amount: 1 },//云杉原木
            { type: 'vanilla', id: 'BIRCH_LOG', amount: 1 },//白桦原木
            { type: 'vanilla', id: 'JUNGLE_LOG', amount: 1 },//丛林原木
            { type: 'vanilla', id: 'ACACIA_LOG', amount: 1 },//金合欢原木
            { type: 'vanilla', id: 'DARK_OAK_LOG', amount: 1 },//深色橡木原木
            { type: 'vanilla', id: 'CRIMSON_STEM', amount: 1 },//绯红菌柄
            { type: 'vanilla', id: 'WARPED_STEM', amount: 1 },//诡异菌柄
            { type: 'vanilla', id: 'MANGROVE_LOG', amount: 1 },//红树原木
            { type: 'vanilla', id: 'CHERRY_LOG', amount: 1 },//樱花原木
            { type: 'vanilla', id: 'BAMBOO_BLOCK', amount: 1 }//竹块
        ]
    },
    /* 事件触发组 5% */
    {
        groupWeight: 5,
        eventType: 'punish',
        strikeLightning: true,
        effects: [
            { type: 'POISON',   amplifier: 2 },
            { type: 'SLOWNESS', amplifier: 1 },
            { type: 'WEAKNESS', amplifier: 1 }
        ]
    },
    /* 刷怪组 苦力怕 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CREEPER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 羊 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SHEEP',
        count: 3,
        radius: 3
    },
    /* 刷怪组 牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'COW',
        count: 3,
        radius: 3
    },
    /* 刷怪组 猪 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PIG',
        count: 3,
        radius: 3
    },
    /* 刷怪组 蘑菇牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'MOOSHROOM',
        count: 3,
        radius: 3
    },
    /* 刷怪组 鹦鹉 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PARROT',
        count: 2,
        radius: 3
    },
    /* 刷怪组 史莱姆 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SLIME',
        count: 2,
        radius: 3
    },
    /* 刷怪组 村民 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'VILLAGER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 流浪商人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WANDERING_TRADER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 铁傀儡 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'IRON_GOLEM',
        count: 2,
        radius: 3
    },
    /* 刷怪组 骆驼 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CAMEL',
        count: 1,
        radius: 3
    },
    /* 刷怪组 恶魂 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GHAST',
        count: 1,
        radius: 3
    },
    /* 刷怪组 凋零骷髅 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER_SKELETON',
        count: 3,
        radius: 3
    },
    /* 刷怪组 巨人僵尸 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GIANT',
        count: 1,
        radius: 3
    },
    /* 刷怪组 烈焰人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'BLAZE',
        count: 1,
        radius: 3
    }
];

/* 2. 核心抽奖 ================================================ */
function pickSlimyItem() {
    const total = SlimyGroup.reduce((sum, g) => sum + g.groupWeight, 0);
    let r = Math.random() * total;
    let pickedGroup = null;
    for (const g of SlimyGroup) {
        if (r < g.groupWeight) { pickedGroup = g; break; }
        r -= g.groupWeight;
    }
    if (!pickedGroup) pickedGroup = SlimyGroup[SlimyGroup.length - 1];

    if (pickedGroup.eventType === 'punish') {
        return { eventType: 'punish', punish: pickedGroup };
    }
    if (pickedGroup.eventType === 'spawn') {
        return { eventType: 'spawn', spawn: pickedGroup };
    }

    /* 物品组（单抽） */
    if (!pickedGroup.allDrop) {
        const entry = pickedGroup.items[Math.floor(Math.random() * pickedGroup.items.length)];
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            return { eventType: 'item', stacks: [item] };
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            return { eventType: 'item', stacks: [item] };
        }
    }

    /* 物品组（全掉） */
    const list = [];
    for (const entry of pickedGroup.items) {
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            list.push(item);
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            list.push(item);
        }
    }
    return { eventType: 'item', allDrop: true, stacks: list };
}

/* 3. 负面事件 ================================================ */
function applyPunish(player, group) {
    if (group.strikeLightning) {
        player.getWorld().strikeLightning(player.getLocation());
    }
    const keyMap = {
        'POISON':    'poison',
        'SLOW':      'slowness',
        'SLOWNESS':  'slowness',
        'WEAKNESS':  'weakness',
        'BLINDNESS': 'blindness',
        'WITHER':    'wither',
        'NAUSEA':    'nausea',
        'HUNGER':    'hunger',
        'MINING_FATIGUE': 'mining_fatigue'
    };
    if (group.effects) {
        for (const ef of group.effects) {
            const key = keyMap[ef.type] || ef.type.toLowerCase();
            const type = Registry.EFFECT.get(NamespacedKey.minecraft(key));
            if (type == null) {
                throw new Error('[天命盲盒] 无效药水类型: ' + ef.type + ' (key=' + key + ')');
            }
            player.addPotionEffect(new PotionEffect(type, DurationTicks, ef.amplifier, false, true));
        }
    }
}

/* 4. 刷怪逻辑 ================================================ */
function applySpawn(player, group) {
    const loc = player.getLocation();
    const world = player.getWorld();
    const count = group.count || 1;
    const radius = group.radius || 3;
    const mobType = Java.type('org.bukkit.entity.EntityType').valueOf(group.mobType || 'CREEPER');

    for (let i = 0; i < count; i++) {
        const angle = Math.random() * 2 * Math.PI;
        const r = Math.random() * radius;
        const x = loc.getX() + r * Math.cos(angle);
        const z = loc.getZ() + r * Math.sin(angle);
        const y = loc.getY();
        world.spawnEntity(new org.bukkit.Location(world, x, y, z), mobType);
    }
}

/* 6. 开箱事件 – 强制掉落 + 1 秒不可拾取 ===================== */
function onUse(event) {
    const player = event.getPlayer();
    if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

    const itemInMain = player.getInventory().getItemInMainHand();
    const result = pickSlimyItem();

    if (result.eventType === 'punish') {
        applyPunish(player, result.punish);
    } else if (result.eventType === 'spawn') {
        applySpawn(player, result.spawn);
    } else if (result.eventType === 'item') {
        const stacks = result.stacks;
        for (const item of stacks) {
            const drop = player.getWorld().dropItem(player.getLocation(), item);
            drop.setPickupDelay(PickupDelay);
        }
    }
    // 消耗幸运方块
    if (itemInMain.getAmount() > 1) {
        itemInMain.setAmount(itemInMain.getAmount() - 1);
    } else {
        itemInMain.setAmount(0);
    }
}