const DISPLAY_NAME = '§c§l修罗·破界神镐';

const RANGE = 1;          // 3×3×3 半径1（含中心共27格）
const COOLDOWN_MS = 500;  // 半秒冷却

const cdMap = new Map();

/* ===== 3×3×3 瞬间挖掘（无掉落延迟） ===== */
function onUse(evt) 
{
    const player = evt.getPlayer();
    const uuid = player.getUniqueId().toString();
    const now = Date.now();

    // 冷却
    if (cdMap.has(uuid) && now - cdMap.get(uuid) < COOLDOWN_MS) {
        player.sendActionBar('§c破界之力尚未凝聚...');
        return;
    }
    cdMap.set(uuid, now);

    const world = player.getWorld();
    const loc = player.getLocation();
    const center = loc.getBlock();

    // 特效
    world.playSound(loc, 'block.beacon.activate', 1, 0.8);
    world.playSound(loc, 'entity.enderman.scream', 1, 1.2);

    let breakCount = 0;

    // 3×3×3 立方体
    for (let dx = -RANGE; dx <= RANGE; dx++) {
        for (let dy = -RANGE; dy <= RANGE; dy++) {
            for (let dz = -RANGE; dz <= RANGE; dz++) {
                const block = center.getRelative(dx, dy, dz);
                if (block.isEmpty()) continue;

                // 瞬间破坏并直接掉落（无延迟）
                block.breakNaturally(player.getItemInHand(), true, true);
                breakCount++;
            }
        }
    }

    // 反馈
    if (breakCount > 0) {
        player.sendMessage(`§8[破界领域] §e${breakCount}§7格空间已粉碎。`);
        player.sendTitle('§e破界', `§8${breakCount} 格已清空`, 5, 25, 10);
    } else {
        player.sendMessage('§8[破界领域] §73×3×3 范围内无可破碎之物。');
    }
}

/* ===== 事件绑定 ===== */
function onLoad() 
{
    return {
        PlayerInteractEvent: function (evt) {
            const action = evt.getAction().name();
            if (action !== 'RIGHT_CLICK_AIR' && action !== 'RIGHT_CLICK_BLOCK') return;
            if (evt.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

            const item = evt.getPlayer().getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() !== DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();