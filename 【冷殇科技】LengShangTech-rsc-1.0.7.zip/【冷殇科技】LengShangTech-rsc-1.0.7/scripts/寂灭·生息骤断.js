// 文件：寂灭生息骤断.js  (供 RykenSlimefunCustomizer 加载)
const displayName = '§5§l寂§9§l灭§3§l生§c§l息§6§l骤§8§l断';
const cooldown = new Map();
const COOL_MS = 1000;

// RSC 要求的主入口函数
function onLoad() {
    // 把事件监听器 return 出去，RSC 会帮你注册
    return {
        // 对应 Bukkit 的 PlayerInteractEvent
        'PlayerInteractEvent': function (event) {
            const act = event.getAction().name();
            if (act !== 'RIGHT_CLICK_AIR' && act !== 'RIGHT_CLICK_BLOCK') return;

            const p = event.getPlayer();
            const item = p.getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() !== displayName) return;

            // 冷却
            const uuid = p.getUniqueId().toString();
            const now = Date.now();
            if (cooldown.has(uuid) && now - cooldown.get(uuid) < COOL_MS) {
                p.sendActionBar('§7技能冷却中...');
                return;
            }
            cooldown.set(uuid, now);

            // 直线 10 格瞬杀
            const start = p.getEyeLocation();
            const dir = start.getDirection().normalize();
            const world = p.getWorld();
            for (let i = 1; i <= 10; i++) {
                const check = start.clone().add(dir.clone().multiply(i));
                world.getNearbyEntities(check, 0.8, 0.8, 0.8).forEach(function (ent) {
                    if (ent instanceof org.bukkit.entity.Player && ent !== p) {
                        ent.setHealth(0);
                    }
                });
            }

            // 消耗耐久
            const meta = item.getItemMeta();
            if (meta.isUnbreakable()) return;
            const newDamage = meta.getDamage() + 1;
            if (newDamage >= item.getType().getMaxDurability()) {
                p.getInventory().setItemInMainHand(null);
                p.sendActionBar('§c寂灭归墟，杖身碎裂...');
            } else {
                meta.setDamage(newDamage);
                item.setItemMeta(meta);
                p.sendActionBar('§a生息骤断，万物归寂。');
            }

            // 特效
            world.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_WITHER_SHOOT, 1, 1);
            world.spawnParticle(org.bukkit.Particle.SPELL_WITCH,
                start.clone().add(dir.multiply(5)), 50, 0.5, 0.5, 0.5, 0.1);
        }
    };
}

// 必须存在，RSC 会调用
onLoad();