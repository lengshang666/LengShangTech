/*******************************************************************
 * 触发：右键主手使用
 * 行为：强制掉落 + 20 tick 不可拾取 + 惩罚/刷怪/结构/物品
 * 注：vanilla 条目已移除 name 字段，保留原版物品名称，不写入任何 NBT
 *******************************************************************/
const ItemStack   = Java.type('org.bukkit.inventory.ItemStack');
const Material    = Java.type('org.bukkit.Material');
const ChatColor   = Java.type('org.bukkit.ChatColor');

/* 1.21 药水 API */
const Registry        = Java.type('org.bukkit.Registry');
const NamespacedKey   = Java.type('org.bukkit.NamespacedKey');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const DurationTicks   = 20 * 15;

/* 掉落物控制 */
const PickupDelay = 20; // 1 秒不可拾取

/* 随机整数 [min, max] */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* 1. 配置组 ====================================================== */
const SlimyGroup = [
    /* 普通单抽组 40% */
    {
        groupWeight: 50,
        allDrop: false,
        items: [
            { type: 'vanilla', id: 'POPPY', amount: {min:1, max:64} },//罂粟
            { type: 'vanilla', id: 'DANDELION', amount: {min:1, max:64} },//蒲公英
            { type: 'vanilla', id: 'BLUE_ORCHID', amount: {min:1, max:64} },//兰花
            { type: 'vanilla', id: 'ALLIUM', amount: {min:1, max:64} },//绒球葱
            { type: 'vanilla', id: 'AZURE_BLUET', amount: {min:1, max:64} },//茜草花
            { type: 'vanilla', id: 'RED_TULIP', amount: {min:1, max:64} },//红色郁金香
            { type: 'vanilla', id: 'ORANGE_TULIP', amount: {min:1, max:64} },//橙色郁金香
            { type: 'vanilla', id: 'WHITE_TULIP', amount: {min:1, max:64} },//白色郁金香
            { type: 'vanilla', id: 'PINK_TULIP', amount: {min:1, max:64} },//粉色郁金香
            { type: 'vanilla', id: 'OXEYE_DAISY', amount: {min:1, max:64} },//滨菊
            { type: 'vanilla', id: 'CORNFLOWER', amount: {min:1, max:64} },//矢车菊
            { type: 'vanilla', id: 'LILY_OF_THE_VALLEY', amount: {min:1, max:64} },//铃兰
            { type: 'vanilla', id: 'SUNFLOWER', amount: {min:1, max:64} },//向日葵
            { type: 'vanilla', id: 'LILAC', amount: {min:1, max:64} },//丁香
            { type: 'vanilla', id: 'ROSE_BUSH', amount: {min:1, max:64} },//玫瑰丛
            { type: 'vanilla', id: 'PEONY', amount: {min:1, max:64} },//牡丹
            { type: 'vanilla', id: 'TALL_GRASS', amount: {min:1, max:64} },//高草丛
            { type: 'vanilla', id: 'LARGE_FERN', amount: {min:1, max:64} },//大型蕨
            { type: 'vanilla', id: 'PITCHER_PLANT', amount: {min:1, max:64} },//猪笼草
            { type: 'vanilla', id: 'TORCHFLOWER', amount: {min:1, max:64} },//火把花
            { type: 'vanilla', id: 'BROWN_MUSHROOM', amount: {min:1, max:64} },//棕色蘑菇
            { type: 'vanilla', id: 'RED_MUSHROOM', amount: {min:1, max:64} },//红色蘑菇
            { type: 'vanilla', id: 'CRIMSON_FUNGUS', amount: {min:1, max:64} },//绯红菌
            { type: 'vanilla', id: 'WARPED_FUNGUS', amount: {min:1, max:64} },//诡异菌
            { type: 'vanilla', id: 'WITHER_ROSE', amount: {min:1, max:64} },//凋零玫瑰
            { type: 'vanilla', id: 'PINK_PETALS', amount: {min:1, max:64} },//粉红色花族
            { type: 'vanilla', id: 'SPORE_BLOSSOM', amount: {min:1, max:64} }//袍子花
        ]
    },
    /* 幸运套装 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'LENGSHANG_幸运头盔', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运胸甲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运护腿', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运靴子', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运剑', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运镐', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运斧', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运铲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_黄金切尔西', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_万能附魔书', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_击退棒', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_秒人斧', amount: 1 }
        ]
    },
    /* 事件触发组 5% */
    {
        groupWeight: 5,
        eventType: 'punish',
        strikeLightning: true,
        effects: [
            { type: 'POISON',   amplifier: 2 },
            { type: 'SLOWNESS', amplifier: 1 },
            { type: 'WEAKNESS', amplifier: 1 }
        ]
    },
    /* 刷怪组（苦力怕×5）3% */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CREEPER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 羊 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SHEEP',
        count: 3,
        radius: 3
    },
    /* 刷怪组 牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'COW',
        count: 3,
        radius: 3
    },
    /* 刷怪组 猪 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PIG',
        count: 3,
        radius: 3
    },
    /* 刷怪组 蘑菇牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'MOOSHROOM',
        count: 3,
        radius: 3
    },
    /* 刷怪组 鹦鹉 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PARROT',
        count: 2,
        radius: 3
    },
    /* 刷怪组 史莱姆 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SLIME',
        count: 2,
        radius: 3
    },
    /* 刷怪组 村民 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'VILLAGER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 流浪商人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WANDERING_TRADER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 铁傀儡 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'IRON_GOLEM',
        count: 2,
        radius: 3
    },
    /* 刷怪组 骆驼 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CAMEL',
        count: 1,
        radius: 3
    },
    /* 刷怪组 恶魂 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GHAST',
        count: 1,
        radius: 3
    },
    /* 刷怪组 凋零骷髅 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER_SKELETON',
        count: 3,
        radius: 3
    },
    /* 刷怪组 巨人僵尸 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GIANT',
        count: 1,
        radius: 3
    },
    /* 刷怪组 烈焰人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'BLAZE',
        count: 1,
        radius: 3
    }
];

/* 2. 核心抽奖 ================================================ */
function pickSlimyItem() {
    const total = SlimyGroup.reduce((sum, g) => sum + g.groupWeight, 0);
    let r = Math.random() * total;
    let pickedGroup = null;
    for (const g of SlimyGroup) {
        if (r < g.groupWeight) { pickedGroup = g; break; }
        r -= g.groupWeight;
    }
    if (!pickedGroup) pickedGroup = SlimyGroup[SlimyGroup.length - 1];

    if (pickedGroup.eventType === 'punish') {
        return { eventType: 'punish', punish: pickedGroup };
    }
    if (pickedGroup.eventType === 'spawn') {
        return { eventType: 'spawn', spawn: pickedGroup };
    }

    /* 物品组（单抽） */
    if (!pickedGroup.allDrop) {
        const entry = pickedGroup.items[Math.floor(Math.random() * pickedGroup.items.length)];
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            return { eventType: 'item', stacks: [item] };
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            return { eventType: 'item', stacks: [item] };
        }
    }

    /* 物品组（全掉） */
    const list = [];
    for (const entry of pickedGroup.items) {
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            list.push(item);
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            list.push(item);
        }
    }
    return { eventType: 'item', allDrop: true, stacks: list };
}

/* 3. 负面事件 ================================================ */
function applyPunish(player, group) {
    if (group.strikeLightning) {
        player.getWorld().strikeLightning(player.getLocation());
    }
    const keyMap = {
        'POISON':    'poison',
        'SLOW':      'slowness',
        'SLOWNESS':  'slowness',
        'WEAKNESS':  'weakness',
        'BLINDNESS': 'blindness',
        'WITHER':    'wither',
        'NAUSEA':    'nausea',
        'HUNGER':    'hunger',
        'MINING_FATIGUE': 'mining_fatigue'
    };
    if (group.effects) {
        for (const ef of group.effects) {
            const key = keyMap[ef.type] || ef.type.toLowerCase();
            const type = Registry.EFFECT.get(NamespacedKey.minecraft(key));
            if (type == null) {
                throw new Error('[天命盲盒] 无效药水类型: ' + ef.type + ' (key=' + key + ')');
            }
            player.addPotionEffect(new PotionEffect(type, DurationTicks, ef.amplifier, false, true));
        }
    }
}

/* 4. 刷怪逻辑 ================================================ */
function applySpawn(player, group) {
    const loc = player.getLocation();
    const world = player.getWorld();
    const count = group.count || 1;
    const radius = group.radius || 3;
    const mobType = Java.type('org.bukkit.entity.EntityType').valueOf(group.mobType || 'CREEPER');

    for (let i = 0; i < count; i++) {
        const angle = Math.random() * 2 * Math.PI;
        const r = Math.random() * radius;
        const x = loc.getX() + r * Math.cos(angle);
        const z = loc.getZ() + r * Math.sin(angle);
        const y = loc.getY();
        world.spawnEntity(new org.bukkit.Location(world, x, y, z), mobType);
    }
}

/* 6. 开箱事件 – 强制掉落 + 1 秒不可拾取 ===================== */
function onUse(event) {
    const player = event.getPlayer();
    if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

    const itemInMain = player.getInventory().getItemInMainHand();
    const result = pickSlimyItem();

    if (result.eventType === 'punish') {
        applyPunish(player, result.punish);
    } else if (result.eventType === 'spawn') {
        applySpawn(player, result.spawn);
    } else if (result.eventType === 'item') {
        const stacks = result.stacks;
        for (const item of stacks) {
            const drop = player.getWorld().dropItem(player.getLocation(), item);
            drop.setPickupDelay(PickupDelay);
        }
    }

    // 消耗幸运方块
    if (itemInMain.getAmount() > 1) {
        itemInMain.setAmount(itemInMain.getAmount() - 1);
    } else {
        itemInMain.setAmount(0);
    }
}