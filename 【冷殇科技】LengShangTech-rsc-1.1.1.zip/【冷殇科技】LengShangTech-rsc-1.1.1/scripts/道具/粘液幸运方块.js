/*******************************************************************
 * 触发：右键主手使用
 * 行为：强制掉落 + 20 tick 不可拾取 + 惩罚/刷怪/结构/物品
 *******************************************************************/
const ItemStack   = Java.type('org.bukkit.inventory.ItemStack');
const Material    = Java.type('org.bukkit.Material');
const ChatColor   = Java.type('org.bukkit.ChatColor');

/* 1.21 药水 API */
const Registry        = Java.type('org.bukkit.Registry');
const NamespacedKey   = Java.type('org.bukkit.NamespacedKey');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const DurationTicks   = 20 * 15;

/* 掉落物控制 */
const PickupDelay = 20; // 1 秒不可拾取

/* 随机整数 [min, max] */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* 1. 配置组 ====================================================== */
const SlimyGroup = [
    /* 普通单抽组 40% */
    {
        groupWeight: 50,
        allDrop: false,
        items: [
            { type: 'sf', id: 'IRON_DUST', amount: {min:1, max:64} },//铁粉
            { type: 'sf', id: 'GOLD_DUST', amount: {min:1, max:64} },//金粉
            { type: 'sf', id: 'COPPER_DUST', amount: {min:1, max:64} },//铜粉
            { type: 'sf', id: 'TIN_DUST', amount: {min:1, max:64} },//锡粉
            { type: 'sf', id: 'SILVER_DUST', amount: {min:1, max:64} },//银粉
            { type: 'sf', id: 'LEAD_DUST', amount: {min:1, max:64} },//铅粉
            { type: 'sf', id: 'ALUMINUM_DUST', amount: {min:1, max:64} },//铝粉
            { type: 'sf', id: 'MAGNESIUM_DUST', amount: {min:1, max:64} },//镁粉
            { type: 'sf', id: 'ZINC_DUST', amount: {min:1, max:64} },//锌粉

            { type: 'sf', id: 'COPPER_INGOT', amount: {min:1, max:64} },//铜锭
            { type: 'sf', id: 'TIN_INGOT', amount: {min:1, max:64} },//锡锭
            { type: 'sf', id: 'SILVER_INGOT', amount: {min:1, max:64} },//银锭
            { type: 'sf', id: 'LEAD_INGOT', amount: {min:1, max:64} },//铅锭
            { type: 'sf', id: 'ALUMINUM_INGOT', amount: {min:1, max:64} },//铝锭
            { type: 'sf', id: 'MAGNESIUM_INGOT', amount: {min:1, max:64} },//镁锭
            { type: 'sf', id: 'ZINC_INGOT', amount: {min:1, max:64} },//锌锭

            { type: 'sf', id: 'CARBON', amount: {min:1, max:64} },//碳
            { type: 'sf', id: 'COMPRESSED_CARBON', amount: {min:1, max:64} },//压缩碳
            { type: 'sf', id: 'CARBON_CHUNK', amount: {min:1, max:64} },//碳块
            { type: 'sf', id: 'RAW_CARBONADO', amount: {min:1, max:64} },//黑金刚石原矿
            { type: 'sf', id: 'SYNTHETIC_SAPPHIRE', amount: {min:1, max:64} },//人造蓝宝石
            { type: 'sf', id: 'SYNTHETIC_DIAMOND', amount: {min:1, max:64} },//人造钻石
            { type: 'sf', id: 'SYNTHETIC_EMERALD', amount: {min:1, max:64} },//人造绿宝石
            { type: 'sf', id: 'CARBONADO', amount: {min:1, max:64} },//黑金刚石
            { type: 'sf', id: 'SILICON', amount: {min:1, max:64} },//硅
            { type: 'sf', id: 'MAGNESIUM_SALT', amount: {min:1, max:64} },//镁盐

            { type: 'sf', id: 'OUTPUT_CHEST', amount: {min:1, max:64} },//物品输出箱
            { type: 'sf', id: 'COMPOSTER', amount: {min:1, max:64} },//搅拌机
            { type: 'sf', id: 'CRUCIBLE', amount: {min:1, max:64} },//坩埚
            { type: 'sf', id: 'IGNITION_CHAMBER', amount: {min:1, max:64} },//自动点火机
            { type: 'sf', id: 'BLOCK_PLACER', amount: {min:1, max:64} },//方块放置机
            { type: 'sf', id: 'ENHANCED_FURNACE', amount: {min:1, max:4} },//强化熔炉1
            { type: 'sf', id: 'ENHANCED_FURNACE_2', amount: {min:1, max:4} },//强化熔炉2
            { type: 'sf', id: 'ENHANCED_FURNACE_3', amount: {min:1, max:4} },//强化熔炉3
            { type: 'sf', id: 'ENHANCED_FURNACE_4', amount: {min:1, max:4} },//强化熔炉4
            { type: 'sf', id: 'ENHANCED_FURNACE_5', amount: {min:1, max:4} },//强化熔炉5
            { type: 'sf', id: 'ENHANCED_FURNACE_6', amount: {min:1, max:4} },//强化熔炉6
            { type: 'sf', id: 'ENHANCED_FURNACE_7', amount: {min:1, max:4} },//强化熔炉7
            { type: 'sf', id: 'ENHANCED_FURNACE_8', amount: {min:1, max:4} },//强化熔炉8
            { type: 'sf', id: 'ENHANCED_FURNACE_9', amount: {min:1, max:4} },//强化熔炉9
            { type: 'sf', id: 'ENHANCED_FURNACE_10', amount: {min:1, max:4} },//强化熔炉10
            { type: 'sf', id: 'ENHANCED_FURNACE_11', amount: {min:1, max:4} },//强化熔炉11
            { type: 'sf', id: 'REINFORCED_FURNACE', amount: {min:1, max:2} },//强化合金熔炉
            { type: 'sf', id: 'CARBONADO_EDGED_FURNACE', amount: {min:1, max:1} },//黑金刚石镶边熔炉

            { type: 'sf', id: 'GRANDMAS_WALKING_STICK', amount: {min:1, max:64} },//奶奶的拐杖
            { type: 'sf', id: 'GRANDPAS_WALKING_STICK', amount: {min:1, max:64} },//爷爷的拐杖
            { type: 'sf', id: 'PORTABLE_CRAFTER', amount: {min:1, max:64} },//便携工作台
            { type: 'sf', id: 'PORTABLE_DUSTBIN', amount: {min:1, max:64} },//便携垃圾桶
            { type: 'sf', id: 'RAG', amount: {min:1, max:64} },//破布
            { type: 'sf', id: 'BANDAGE', amount: {min:1, max:64} },//绷带
            { type: 'sf', id: 'SPLINT', amount: {min:1, max:64} },//夹板
            { type: 'sf', id: 'VITAMINS', amount: {min:1, max:64} },//维他命
            { type: 'sf', id: 'TAPE_MEASURE', amount: {min:1, max:64} },//卷尺
            { type: 'sf', id: 'GOLD_PAN', amount: {min:1, max:64} },//淘金盘
            { type: 'sf', id: 'NETHER_GOLD_PAN', amount: {min:1, max:64} },//下界淘金盘
            { type: 'sf', id: 'GRAPPLING_HOOK', amount: {min:1, max:64} },//抓钩
            { type: 'sf', id: 'MAGIC_LUMP_1', amount: {min:1, max:64} },//魔法结晶1
            { type: 'sf', id: 'MAGIC_LUMP_2', amount: {min:1, max:64} },//魔法结晶2
            { type: 'sf', id: 'MAGIC_LUMP_3', amount: {min:1, max:64} },//魔法结晶3
            { type: 'sf', id: 'ENDER_LUMP_1', amount: {min:1, max:64} },//末影结晶1
            { type: 'sf', id: 'ENDER_LUMP_2', amount: {min:1, max:64} },//末影结晶2
            { type: 'sf', id: 'ENDER_LUMP_3', amount: {min:1, max:64} },//末影结晶3
            { type: 'sf', id: 'MAGICAL_BOOK_COVER', amount: {min:1, max:64} },//魔法书皮
            { type: 'sf', id: 'MAGICAL_GLASS', amount: {min:1, max:64} },//魔法玻璃
            { type: 'sf', id: 'LAVA_CRYSTAL', amount: {min:1, max:64} },//岩浆水晶
            { type: 'sf', id: 'COMMON_TALISMAN', amount: {min:1, max:64} },//普通护身符
            { type: 'sf', id: 'NECROTIC_SKULL', amount: {min:1, max:16} },//坏死颅骨
            { type: 'sf', id: 'STRANGE_NETHER_GOO', amount: {min:1, max:64} },//奇怪的下届粘液

            { type: 'sf', id: 'BLANK_RUNE', amount: {min:1, max:64} },//空白符文
            { type: 'sf', id: 'ANCIENT_RUNE_AIR', amount: {min:1, max:32} },//气符文
            { type: 'sf', id: 'ANCIENT_RUNE_EARTH', amount: {min:1, max:32} },//地符文
            { type: 'sf', id: 'ANCIENT_RUNE_FIRE', amount: {min:1, max:32} },//火符文
            { type: 'sf', id: 'ANCIENT_RUNE_WATER', amount: {min:1, max:32} },//水符文
            { type: 'sf', id: 'ANCIENT_RUNE_ENDER', amount: {min:1, max:32} },//末影符文
            { type: 'sf', id: 'ANCIENT_RUNE_LIGHTNING', amount: {min:1, max:8} },//雷符文
            { type: 'sf', id: 'ANCIENT_RUNE_RAINBOW', amount: {min:1, max:8} },//虹符文
            { type: 'sf', id: 'ANCIENT_RUNE_SOULBOUND', amount: {min:1, max:8} },//灵魂绑定符文
            { type: 'sf', id: 'ANCIENT_RUNE_VILLAGERS', amount: {min:1, max:8} },//村民符文
            { type: 'sf', id: 'ANCIENT_RUNE_ENCHANTMENT', amount: {min:1, max:8} },//附魔符文

            { type: 'sf', id: 'BASIC_CIRCUIT_BOARD', amount: {min:1, max:64} },//基础电路板
            { type: 'sf', id: 'ADVANCED_CIRCUIT_BOARD', amount: {min:1, max:64} },//高级电路板
            { type: 'sf', id: 'BATTERY', amount: {min:1, max:64} },//电池
            { type: 'sf', id: 'STEEL_THRUSTER', amount: {min:1, max:64} },//钢推进器
            { type: 'sf', id: 'POWER_CRYSTAL', amount: {min:1, max:64} },//能量水晶
            { type: 'sf', id: 'SOLAR_PANEL', amount: {min:1, max:64} },//光伏电池
            { type: 'sf', id: 'REINFORCED_CLOTH', amount: {min:1, max:64} },//强化布料
            { type: 'sf', id: 'MAGNET', amount: {min:1, max:64} },//磁铁
            { type: 'sf', id: 'COPPER_WIRE', amount: {min:1, max:64} },//铜线
            { type: 'sf', id: 'HARDENED_GLASS', amount: {min:1, max:64} },//钢化玻璃
            { type: 'sf', id: 'WITHER_PROOF_OBSIDIAN', amount: {min:1, max:64} },//防凋零黑曜石
            { type: 'sf', id: 'PLASTIC_SHEET', amount: {min:1, max:64} },//塑料纸
            { type: 'sf', id: 'ANDROID_MEMORY_CORE', amount: {min:1, max:64} },//机器人内存核心
            { type: 'sf', id: 'WITHER_PROOF_GLASS', amount: {min:1, max:64} },//防凋零玻璃

            { type: 'sf', id: 'ELECTRO_MAGNET', amount: {min:1, max:64} },//电磁铁
            { type: 'sf', id: 'ELECTRIC_MOTOR', amount: {min:1, max:64} },//电动马达
            { type: 'sf', id: 'HEATING_COIL', amount: {min:1, max:64} },//加热线圈
            { type: 'sf', id: 'COOLING_UNIT', amount: {min:1, max:64} },//冷却装置
            { type: 'sf', id: 'CARGO_MOTOR', amount: {min:1, max:64} },//货运马达
            { type: 'sf', id: 'CRAFTING_MOTOR', amount: {min:1, max:64} },//合成机马达
            { type: 'sf', id: 'REACTOR_COLLANT_CELL', amount: {min:1, max:64} },//反应堆冷却剂
            { type: 'sf', id: 'NETHER_ICE_COOLANT_CELL', amount: {min:1, max:64} },//下界冰冷却剂
            { type: 'sf', id: 'STEEL_PLATE', amount: {min:1, max:32} },//钢板
            { type: 'sf', id: 'REINFORCED_PLATE', amount: {min:1, max:16} },//钢筋板
            { type: 'sf', id: 'ENDER_BACKPACK', amount: {min:1, max:2} },//末影背包
            { type: 'sf', id: 'MAGIC_EYE_OF_ENDER', amount: {min:1, max:64} },//魔法末影之眼
            { type: 'sf', id: 'STAFF_ELEMENTAL', amount: {min:1, max:16} },//元素法杖
            { type: 'sf', id: 'STAFF_ELEMENTAL_WIND', amount: {min:1, max:8} },//风法杖
            { type: 'sf', id: 'STAFF_ELEMENTAL_WATER', amount: {min:1, max:8} },//水法杖
            { type: 'sf', id: 'STAFF_ELEMENTAL_FIRE', amount: {min:1, max:8} },//火法杖
            { type: 'sf', id: 'STAFF_ELEMENTAL_STORM', amount: {min:1, max:4} },//雷法杖
            { type: 'sf', id: 'MAGICAL_ZOMBIE_PILLS', amount: {min:1, max:4} },//还魂丹
            { type: 'sf', id: 'INFUSED_MAGNET', amount: {min:1, max:8} },//吸入磁铁
            { type: 'sf', id: 'INFERNAL_BONEMEAL', amount: {min:1, max:64} },//地狱骨粉
            { type: 'sf', id: 'TRASH_CAN_BLOCK', amount: {min:1, max:64} },//垃圾箱

            { type: 'sf', id: 'ENERGY_REGULATOR', amount: {min:1, max:16} },//能源调节器
            { type: 'sf', id: 'ENERGY_CONNECTOR', amount: {min:1, max:64} },//能源连接器
            { type: 'sf', id: 'SMALL_CAPACITOR', amount: {min:1, max:64} },//小型电容
            { type: 'sf', id: 'MEDIUM_CAPACITOR', amount: {min:1, max:32} },//中型电容
            { type: 'sf', id: 'BIG_CAPACITOR', amount: {min:1, max:16} },//大型电容
            { type: 'sf', id: 'LARGE_CAPACITOR', amount: {min:1, max:8} },//巨型电容
            { type: 'sf', id: 'GPS_TRANSMITTER', amount: {min:1, max:64} },//GPS发射器
            { type: 'sf', id: 'GPS_TRANSMITTER_2', amount: {min:1, max:64} },//高级发射器
            { type: 'sf', id: 'GPS_TRANSMITTER_3', amount: {min:1, max:64} },//黑金刚石发射器
            { type: 'sf', id: 'OIL_PUMP', amount: {min:1, max:16} },//原油泵
            { type: 'sf', id: 'GEO_MINER', amount: {min:1, max:16} },//自然资源开采机
            { type: 'sf', id: 'ANDROID_INTERFACE_ITEMS', amount: {min:1, max:64} },//机器人物品交互
            { type: 'sf', id: 'ANDROID_INTERFACE_FUEL', amount: {min:1, max:64} },//机器人燃料交互
            { type: 'sf', id: 'PROGRAMMABLE_ANDROID', amount: {min:1, max:8} },//普通机器人
            { type: 'sf', id: 'PROGRAMMABLE_ANDROID_2', amount: {min:1, max:4} },//高级机器人
            { type: 'sf', id: 'CARGO_MANAGER', amount: {min:1, max:2} },//货运管理器
            { type: 'sf', id: 'CARGO_NODE', amount: {min:1, max:32} },//货运连接器
            { type: 'sf', id: 'CARGO_NODE_INPUT', amount: {min:1, max:32} },//货运输入
            { type: 'sf', id: 'CARGO_NODE_OUTPUT', amount: {min:1, max:32} },//货运输出
            { type: 'sf', id: 'CARGO_NODE_OUTPUT_ADVANCED', amount: {min:1, max:16} },//货运高级输出
            { type: 'sf', id: 'REACTOR_ACCESS_PORT', amount: {min:1, max:64} },//反应堆访问接口
            { type: 'sf', id: 'VANILLA_AUTO_CRAFTER', amount: {min:1, max:16} },//原版自动合成机
            { type: 'sf', id: 'ENHANCED_AUTO_CRAFTER', amount: {min:1, max:16} },//高级自动合成机
            { type: 'sf', id: 'ARMOR_AUTO_CRAFTER', amount: {min:1, max:64} },//盔甲自动合成机
            { type: 'sf', id: 'CRAFTER_SMART_PORT', amount: {min:1, max:64} }//合成机智能交互接口
        ]
    },
    /* 幸运套装 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'LENGSHANG_幸运头盔', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运胸甲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运护腿', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运靴子', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运剑', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运镐', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运斧', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运铲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_黄金切尔西', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_万能附魔书', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_击退棒', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_秒人斧', amount: 1 }
        ]
    },
    /* 合成锭 */
    {
        groupWeight: 40,
        allDrop: false,
        items: [
            { type: 'sf', id: 'REINFORCED_ALLOY_INGOT', amount: {min:1, max:64} },//强化合金锭
            { type: 'sf', id: 'HARDENED_METAL_INGOT', amount: {min:1, max:64} },//硬化金属
            { type: 'sf', id: 'DAMASCUS_STEEL_INGOT', amount: {min:1, max:64} },//大马士革钢锭
            { type: 'sf', id: 'STEEL_INGOT', amount: {min:1, max:64} },//钢锭
            { type: 'sf', id: 'BRONZE_INGOT', amount: {min:1, max:64} },//青铜锭
            { type: 'sf', id: 'DURALUMIN_INGOT', amount: {min:1, max:64} },//硬铝锭
            { type: 'sf', id: 'BILLON_INGOT', amount: {min:1, max:64} },//银铜合金锭
            { type: 'sf', id: 'BRASS_INGOT', amount: {min:1, max:64} },//黄铜锭
            { type: 'sf', id: 'ALUMINUM_BRASS_INGOT', amount: {min:1, max:64} },//铝黄铜锭
            { type: 'sf', id: 'ALUMINUM_BRONZE_INGOT', amount: {min:1, max:64} },//铝青铜锭
            { type: 'sf', id: 'CORINTHIAN_BRONZE_INGOT', amount: {min:1, max:64} },//科林斯青铜锭
            { type: 'sf', id: 'SOLDER_INGOT', amount: {min:1, max:64} },//焊锡锭
            { type: 'sf', id: 'NICKEL_INGOT', amount: {min:1, max:64} },//镍锭
            { type: 'sf', id: 'COBALT_INGOT', amount: {min:1, max:64} },//钴锭
            { type: 'sf', id: 'FERROSILICON', amount: {min:1, max:64} },//硅铁
            { type: 'sf', id: 'GILDED_IRON', amount: {min:1, max:64} },//镀金铁锭
            { type: 'sf', id: 'REDSTONE_ALLOY', amount: {min:1, max:64} },//红石合金锭

            { type: 'sf', id: 'GOLD_4K', amount: {min:1, max:64} },//4k
            { type: 'sf', id: 'GOLD_6K', amount: {min:1, max:64} },//6k
            { type: 'sf', id: 'GOLD_8K', amount: {min:1, max:64} },//8k
            { type: 'sf', id: 'GOLD_10K', amount: {min:1, max:64} },//10k
            { type: 'sf', id: 'GOLD_12K', amount: {min:1, max:64} },//12k
            { type: 'sf', id: 'GOLD_14K', amount: {min:1, max:64} },//14k
            { type: 'sf', id: 'GOLD_16K', amount: {min:1, max:64} },//16k
            { type: 'sf', id: 'GOLD_18K', amount: {min:1, max:64} },//18k
            { type: 'sf', id: 'GOLD_20K', amount: {min:1, max:64} },//20k
            { type: 'sf', id: 'GOLD_22K', amount: {min:1, max:64} },//22k
            { type: 'sf', id: 'GOLD_24K', amount: {min:1, max:64} },//24k
            { type: 'sf', id: 'GOLD_24K_BLOCK', amount: {min:1, max:64} },//24k金块

            { type: 'sf', id: 'BUCKET_OF_OIL', amount: {min:1, max:64} },//原油桶
            { type: 'sf', id: 'BUCKET_OF_FUEL', amount: {min:1, max:64} },//燃料桶
            { type: 'sf', id: 'NETHER_ICE', amount: {min:1, max:64} },//下界冰
            { type: 'sf', id: 'ENRICHED_NETHER_ICE', amount: {min:1, max:64} },//浓缩下界冰

            { type: 'sf', id: 'BLISTERING_INGOT', amount: {min:1, max:32} },//33起泡锭
            { type: 'sf', id: 'BLISTERING_INGOT_2', amount: {min:1, max:32} },//66起泡锭
            { type: 'sf', id: 'BLISTERING_INGOT_3', amount: {min:1, max:16} },//起泡锭
            { type: 'sf', id: 'URANIUM', amount: {min:1, max:64} },//铀
            { type: 'sf', id: 'NEPTUNIUM', amount: {min:1, max:16} },//镎
            { type: 'sf', id: 'PLUTONIUM', amount: {min:1, max:16} },//钚
            { type: 'sf', id: 'BOOSTED_URANIUM', amount: {min:1, max:8} }//钚铀混合
        ]
    },
    /* 不可堆叠物 */
    {
        groupWeight: 20,
        allDrop: false,
        items: [
            { type: 'sf', id: 'SWORD_OF_BEHEADING', amount: 1 },//处决之剑
            { type: 'sf', id: 'BLADE_OF_VAMPIRES', amount: 1 },//吸血鬼之刃
            { type: 'sf', id: 'SEISMIC_AXE', amount: 1 },//地震斧
            { type: 'sf', id: 'EXPLOSIVE_BOW', amount: 1 },//爆裂之弓
            { type: 'sf', id: 'ICY_BOW', amount: 1 },//冰封之弓
            { type: 'sf', id: 'MEDICINE', amount: 1 },//药物
            { type: 'sf', id: 'SMELTERS_PICKAXE', amount: 1 },//熔炉稿
            { type: 'sf', id: 'LUMBER_AXE', amount: 1 },//伐木斧
            { type: 'sf', id: 'PICKAXE_OF_CONTAINMENT', amount: 1 },//刷怪笼之稿
            { type: 'sf', id: 'EXPLOSIVE_PICKAXE', amount: 1 },//爆炸稿
            { type: 'sf', id: 'EXPLOSIVE_SHOVEL', amount: 1 },//爆炸铲
            { type: 'sf', id: 'PICKAXE_OF_THE_SEEKER', amount: 1 },//寻矿稿
            { type: 'sf', id: 'COBALT_PICKAXE', amount: 1 },//钴稿
            { type: 'sf', id: 'PICKAXE_OF_VEIN_MINING', amount: 1 },//矿脉稿
            { type: 'sf', id: 'CLIMBING_PICK', amount: 1 }//攀岩稿
        ]
    },
    /* 事件触发组 5% */
    {
        groupWeight: 5,
        eventType: 'punish',
        strikeLightning: true,
        effects: [
            { type: 'POISON',   amplifier: 2 },
            { type: 'SLOWNESS', amplifier: 1 },
            { type: 'WEAKNESS', amplifier: 1 }
        ]
    },
    /* 刷怪组（苦力怕×5）3% */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CREEPER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 羊 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SHEEP',
        count: 3,
        radius: 3
    },
    /* 刷怪组 牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'COW',
        count: 3,
        radius: 3
    },
    /* 刷怪组 猪 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PIG',
        count: 3,
        radius: 3
    },
    /* 刷怪组 蘑菇牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'MOOSHROOM',
        count: 3,
        radius: 3
    },
    /* 刷怪组 鹦鹉 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PARROT',
        count: 2,
        radius: 3
    },
    /* 刷怪组 史莱姆 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SLIME',
        count: 2,
        radius: 3
    },
    /* 刷怪组 村民 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'VILLAGER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 流浪商人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WANDERING_TRADER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 铁傀儡 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'IRON_GOLEM',
        count: 2,
        radius: 3
    },
    /* 刷怪组 骆驼 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CAMEL',
        count: 1,
        radius: 3
    },
    /* 刷怪组 恶魂 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GHAST',
        count: 1,
        radius: 3
    },
    /* 刷怪组 凋零骷髅 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER_SKELETON',
        count: 3,
        radius: 3
    },
    /* 刷怪组 巨人僵尸 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GIANT',
        count: 1,
        radius: 3
    },
    /* 刷怪组 烈焰人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'BLAZE',
        count: 1,
        radius: 3
    }
];

/* 2. 核心抽奖 ================================================ */
function pickSlimyItem() {
    const total = SlimyGroup.reduce((sum, g) => sum + g.groupWeight, 0);
    let r = Math.random() * total;
    let pickedGroup = null;
    for (const g of SlimyGroup) {
        if (r < g.groupWeight) { pickedGroup = g; break; }
        r -= g.groupWeight;
    }
    if (!pickedGroup) pickedGroup = SlimyGroup[SlimyGroup.length - 1];

    if (pickedGroup.eventType === 'punish') {
        return { eventType: 'punish', punish: pickedGroup };
    }
    if (pickedGroup.eventType === 'spawn') {
        return { eventType: 'spawn', spawn: pickedGroup };
    }

    /* 物品组（单抽） */
    if (!pickedGroup.allDrop) {
        const entry = pickedGroup.items[Math.floor(Math.random() * pickedGroup.items.length)];
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            return { eventType: 'item', stacks: [item] };
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            return { eventType: 'item', stacks: [item] };
        }
    }

    /* 物品组（全掉） */
    const list = [];
    for (const entry of pickedGroup.items) {
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            list.push(item);
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            list.push(item);
        }
    }
    return { eventType: 'item', allDrop: true, stacks: list };
}

/* 3. 负面事件 ================================================ */
function applyPunish(player, group) {
    if (group.strikeLightning) {
        player.getWorld().strikeLightning(player.getLocation());
    }
    const keyMap = {
        'POISON':    'poison',
        'SLOW':      'slowness',
        'SLOWNESS':  'slowness',
        'WEAKNESS':  'weakness',
        'BLINDNESS': 'blindness',
        'WITHER':    'wither',
        'NAUSEA':    'nausea',
        'HUNGER':    'hunger',
        'MINING_FATIGUE': 'mining_fatigue'
    };
    if (group.effects) {
        for (const ef of group.effects) {
            const key = keyMap[ef.type] || ef.type.toLowerCase();
            const type = Registry.EFFECT.get(NamespacedKey.minecraft(key));
            if (type == null) {
                throw new Error('[天命盲盒] 无效药水类型: ' + ef.type + ' (key=' + key + ')');
            }
            player.addPotionEffect(new PotionEffect(type, DurationTicks, ef.amplifier, false, true));
        }
    }
}

/* 4. 刷怪逻辑 ================================================ */
function applySpawn(player, group) {
    const loc = player.getLocation();
    const world = player.getWorld();
    const count = group.count || 1;
    const radius = group.radius || 3;
    const mobType = Java.type('org.bukkit.entity.EntityType').valueOf(group.mobType || 'CREEPER');

    for (let i = 0; i < count; i++) {
        const angle = Math.random() * 2 * Math.PI;
        const r = Math.random() * radius;
        const x = loc.getX() + r * Math.cos(angle);
        const z = loc.getZ() + r * Math.sin(angle);
        const y = loc.getY();
        world.spawnEntity(new org.bukkit.Location(world, x, y, z), mobType);
    }
}

/* 6. 开箱事件 – 强制掉落 + 1 秒不可拾取 ===================== */
function onUse(event) {
    const player = event.getPlayer();
    if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

    const itemInMain = player.getInventory().getItemInMainHand();
    const result = pickSlimyItem();

    if (result.eventType === 'punish') {
        applyPunish(player, result.punish);
    } else if (result.eventType === 'spawn') {
        applySpawn(player, result.spawn);
    } else if (result.eventType === 'item') {
        const stacks = result.stacks;
        for (const item of stacks) {
            const drop = player.getWorld().dropItem(player.getLocation(), item);
            drop.setPickupDelay(PickupDelay);
        }
    }

    // 消耗幸运方块
    if (itemInMain.getAmount() > 1) {
        itemInMain.setAmount(itemInMain.getAmount() - 1);
    } else {
        itemInMain.setAmount(0);
    }
}