/*******************************************************************
 * 触发：右键主手使用
 * 行为：强制掉落 + 20 tick 不可拾取 + 惩罚/刷怪/结构/物品
 * 注：sf 条目已移除 name 字段，保留原版物品名称，不写入任何 NBT
 *******************************************************************/
const ItemStack   = Java.type('org.bukkit.inventory.ItemStack');
const Material    = Java.type('org.bukkit.Material');
const ChatColor   = Java.type('org.bukkit.ChatColor');

/* 1.21 药水 API */
const Registry        = Java.type('org.bukkit.Registry');
const NamespacedKey   = Java.type('org.bukkit.NamespacedKey');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const DurationTicks   = 20 * 15;

/* 掉落物控制 */
const PickupDelay = 20; // 1 秒不可拾取

/* 随机整数 [min, max] */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* 1. 配置组 ====================================================== */
const SlimyGroup = [
    /* 普通单抽组 40% */
    {
        groupWeight: 50,
        allDrop: false,
        items: [
            { type: 'sf', id: 'CONCRETE_MOLDING_MACHINE', amount: 1 },//混凝土浇筑机
            { type: 'sf', id: 'VOID_QUARRY', amount: 1 },//虚空矿机
            { type: 'sf', id: 'VOID_CAPACITOR', amount: 1 },//虚空电容
            { type: 'sf', id: 'VOID_PANEL', amount: 1 },//虚空发电机
            { type: 'sf', id: 'GEO_QUARRY', amount: 1 },//地理资源矿机
            { type: 'sf', id: 'VOID_INGOT', amount: {min:1, max:32} },//虚空锭
            { type: 'sf', id: 'INFINITE_INGOT', amount: {min:1, max:16} },//无尽锭
            { type: 'sf', id: 'INFINITY_COBBLE_GEN', amount: 1 }//无尽圆石生成器
        ]
    },
    /* 无尽机器 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'POWERED_BEDROCK', amount: 1 },//充能基岩
            { type: 'sf', id: 'INFINITY_SINGULARITY', amount: 1 },//无尽奇点
            { type: 'sf', id: 'INFINITE_VOID_HARVESTER', amount: 1 },//无尽虚空收集者
            { type: 'sf', id: 'INFINITY_CONSTRUCTOR', amount: 1 },//无尽奇点构造机
            { type: 'sf', id: 'INFINITY_VIRTUAL_FARM', amount: 1 },//无尽自动农场
            { type: 'sf', id: 'INFINITY_TREE_GROWER', amount: 1 },//无尽自动植树机
            { type: 'sf', id: 'INFINITY_DUST_EXTRACTOR', amount: 1 },//无尽磨粉机
            { type: 'sf', id: 'INFINITY_INGOT_FORMER', amount: 1 },//无尽铸锭机
            { type: 'sf', id: 'INFINITY_QUARRY', amount: 1 },//无尽矿机
            { type: 'sf', id: 'INFINITY_CHARGER', amount: 1 },//无尽充电台
            { type: 'sf', id: 'INFINITE_PANEL', amount: 1 },//无尽发电机
            { type: 'sf', id: 'INFINITY_REACTOR', amount: 1 },//无尽反应堆
            { type: 'sf', id: 'INFINITY_ENCHANTER', amount: 1 },//无尽自动附魔机
            { type: 'sf', id: 'INFINITY_DISENCHANTER', amount: 1 },//无尽自动祛魔机
            { type: 'sf', id: 'INFINITY_CAPACITOR', amount: 1 },//无尽电容
            { type: 'sf', id: 'INFINITY_MATRIX', amount: 1 },//无尽飞行器
            { type: 'sf', id: 'INFINITY_BLADE', amount: 1 },//寰宇支配之剑
            { type: 'sf', id: 'INFINITY_AXE', amount: 1 },//自然荒芜之斧
            { type: 'sf', id: 'INFINITY_PICKAXE', amount: 1 },//世界崩解之镐
            { type: 'sf', id: 'INFINITY_SHOVEL', amount: 1 },//星球吞噬之铲
            { type: 'sf', id: 'INFINITY_BOW', amount: 1 },//天堂陨落长弓
            { type: 'sf', id: 'INFINITY_SHIELD', amount: 1 },//宇宙神盾
            { type: 'sf', id: 'INFINITY_CROWN', amount: 1 },//无尽头盔
            { type: 'sf', id: 'INFINITY_CHESTPLATE', amount: 1 },//无尽胸甲
            { type: 'sf', id: 'INFINITY_LEGGINGS', amount: 1 },//无尽护腿
            { type: 'sf', id: 'INFINITY_BOOTS', amount: 1 }//无尽靴子
        ]
    },
    /* 生物芯片 */
    {
        groupWeight: 30,
        allDrop: false,
        items: [
            { type: 'sf', id: 'ZOMBIE_DATA_CARD', amount: 1 },//僵尸
            { type: 'sf', id: 'SLIME_DATA_CARD', amount: 1 },//史莱姆
            { type: 'sf', id: 'MAGMA_CUBE_DATA_CARD', amount: 1 },//岩浆怪
            { type: 'sf', id: 'COW_DATA_CARD', amount: 1 },//牛
            { type: 'sf', id: 'SPIDER_DATA_CARD', amount: 1 },//蜘蛛
            { type: 'sf', id: 'SKELETON_DATA_CARD', amount: 1 },//骷髅
            { type: 'sf', id: 'SHEEP_DATA_CARD', amount: 1 },//绵羊
            { type: 'sf', id: 'WITHER_SKELETON_DATA_CARD', amount: 1 },//凋零骷髅
            { type: 'sf', id: 'ENDERMEN_DATA_CARD', amount: 1 },//末影人
            { type: 'sf', id: 'CREEPER_DATA_CARD', amount: 1 },//苦力怕
            { type: 'sf', id: 'GUARDIAN_DATA_CARD', amount: 1 },//守卫者
            { type: 'sf', id: 'CHICKEN_DATA_CARD', amount: 1 },//鸡
            { type: 'sf', id: 'IRON_GOLEM_DATA_CARD', amount: 1 },//铁傀儡
            { type: 'sf', id: 'BLAZE_DATA_CARD', amount: 1 },//烈焰人
            { type: 'sf', id: 'BEE_DATA_CARD', amount: 1 },//蜜蜂
            { type: 'sf', id: 'VILLAGER_DATA_CARD', amount: 1 },//村民
            { type: 'sf', id: 'WITCH_DATA_CARD', amount: 1 },//女巫
            { type: 'sf', id: 'VEX_DATA_CARD', amount: 1 },//恼鬼
            { type: 'sf', id: 'PHANTOM_DATA_CARD', amount: 1 }//幻翼
        ]
    },
    /* 无尽两件套 */
    {
        groupWeight: 20,
        allDrop: false,
        items: [
            { type: 'sf', id: 'INFINITE_MACHINE_CIRCUIT', amount: 1 },//无尽晶格
            { type: 'sf', id: 'INFINITE_MACHINE_CORE', amount: 1 }//无尽机械核心
        ]
    },
    /* BOSS生物芯片 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'WITHER_DATA_CARD', amount: 1 },//凋零
            { type: 'sf', id: 'ENDER_DRAGON_DATA_CARD', amount: 1 }//末影龙
        ]
    },
    /* 奇点 */
    {
        groupWeight: 10,
        allDrop: true,
        items: [
            { type: 'sf', id: 'COPPER_SINGULARITY', amount: 1 },//铜
            { type: 'sf', id: 'ZINC_SINGULARITY', amount: 1 },//锌
            { type: 'sf', id: 'TIN_SINGULARITY', amount: 1 },//锡
            { type: 'sf', id: 'ALUMINUM_SINGULARITY', amount: 1 },//铝
            { type: 'sf', id: 'SILVER_SINGULARITY', amount: 1 },//银
            { type: 'sf', id: 'MAGNESIUM_SINGULARITY', amount: 1 },//镁
            { type: 'sf', id: 'LEAD_SINGULARITY', amount: 1 },//铅
            { type: 'sf', id: 'GOLD_SINGULARITY', amount: 1 },//金
            { type: 'sf', id: 'QUARTZ_SINGULARITY', amount: 1 },//石英
            { type: 'sf', id: 'IRON_SINGULARITY', amount: 1 },//铁
            { type: 'sf', id: 'LAPIS_SINGULARITY', amount: 1 },//青金石
            { type: 'sf', id: 'REDSTONE_SINGULARITY', amount: 1 },//红石
            { type: 'sf', id: 'COAL_SINGULARITY', amount: 1 },//煤炭
            { type: 'sf', id: 'NETHERITE_SINGULARITY', amount: 1 },//下界合金
            { type: 'sf', id: 'EMERALD_SINGULARITY', amount: 1 },//绿宝石
            { type: 'sf', id: 'DIAMOND_SINGULARITY', amount: 1 }//钻石
        ]
    },
    /* 奇点锭 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'sf', id: 'MAGNONIUM', amount: 1 },//磁金
            { type: 'sf', id: 'ADAMANTITE', amount: 1 },//精金
            { type: 'sf', id: 'MYTHRIL', amount: 1 }//秘银
        ]
    },
    /* 事件触发组 5% */
    {
        groupWeight: 5,
        eventType: 'punish',
        strikeLightning: true,
        effects: [
            { type: 'POISON',   amplifier: 2 },
            { type: 'SLOWNESS', amplifier: 1 },
            { type: 'WEAKNESS', amplifier: 1 }
        ]
    },
    /* 刷怪组（苦力怕×5）3% */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CREEPER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 羊 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SHEEP',
        count: 3,
        radius: 3
    },
    /* 刷怪组 牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'COW',
        count: 3,
        radius: 3
    },
    /* 刷怪组 猪 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PIG',
        count: 3,
        radius: 3
    },
    /* 刷怪组 蘑菇牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'MOOSHROOM',
        count: 3,
        radius: 3
    },
    /* 刷怪组 鹦鹉 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PARROT',
        count: 2,
        radius: 3
    },
    /* 刷怪组 史莱姆 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SLIME',
        count: 2,
        radius: 3
    },
    /* 刷怪组 村民 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'VILLAGER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 流浪商人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WANDERING_TRADER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 铁傀儡 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'IRON_GOLEM',
        count: 2,
        radius: 3
    },
    /* 刷怪组 骆驼 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CAMEL',
        count: 1,
        radius: 3
    },
    /* 刷怪组 恶魂 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GHAST',
        count: 1,
        radius: 3
    },
    /* 刷怪组 凋零骷髅 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER_SKELETON',
        count: 3,
        radius: 3
    },
    /* 刷怪组 巨人僵尸 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GIANT',
        count: 1,
        radius: 3
    },
    /* 刷怪组 烈焰人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'BLAZE',
        count: 3,
        radius: 3
    },
    /* 刷怪组 凋零 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 远古守卫者 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'ELDER_GUARDIAN',
        count: 1,
        radius: 3
    }
];

/* 2. 核心抽奖 ================================================ */
function pickSlimyItem() {
    const total = SlimyGroup.reduce((sum, g) => sum + g.groupWeight, 0);
    let r = Math.random() * total;
    let pickedGroup = null;
    for (const g of SlimyGroup) {
        if (r < g.groupWeight) { pickedGroup = g; break; }
        r -= g.groupWeight;
    }
    if (!pickedGroup) pickedGroup = SlimyGroup[SlimyGroup.length - 1];

    if (pickedGroup.eventType === 'punish') {
        return { eventType: 'punish', punish: pickedGroup };
    }
    if (pickedGroup.eventType === 'spawn') {
        return { eventType: 'spawn', spawn: pickedGroup };
    }

    /* 物品组（单抽） */
    if (!pickedGroup.allDrop) {
        const entry = pickedGroup.items[Math.floor(Math.random() * pickedGroup.items.length)];
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            return { eventType: 'item', stacks: [item] };
        }
        const sfItem = getSfItemById(entry.id);
        if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
        const item = sfItem.getItem().clone();
        item.setAmount(amt);
        return { eventType: 'item', stacks: [item] };
    }

    /* 物品组（全掉） */
    const list = [];
    for (const entry of pickedGroup.items) {
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            list.push(item);
        }
        const sfItem = getSfItemById(entry.id);
        if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
        const item = sfItem.getItem().clone();
        item.setAmount(amt);
        list.push(item);
    }
    return { eventType: 'item', allDrop: true, stacks: list };
}

/* 3. 负面事件 ================================================ */
function applyPunish(player, group) {
    if (group.strikeLightning) {
        player.getWorld().strikeLightning(player.getLocation());
    }
    const keyMap = {
        'POISON':    'poison',
        'SLOW':      'slowness',
        'SLOWNESS':  'slowness',
        'WEAKNESS':  'weakness',
        'BLINDNESS': 'blindness',
        'WITHER':    'wither',
        'NAUSEA':    'nausea',
        'HUNGER':    'hunger',
        'MINING_FATIGUE': 'mining_fatigue'
    };
    if (group.effects) {
        for (const ef of group.effects) {
            const key = keyMap[ef.type] || ef.type.toLowerCase();
            const type = Registry.EFFECT.get(NamespacedKey.minecraft(key));
            if (type == null) {
                throw new Error('[天命盲盒] 无效药水类型: ' + ef.type + ' (key=' + key + ')');
            }
            player.addPotionEffect(new PotionEffect(type, DurationTicks, ef.amplifier, false, true));
        }
    }
}

/* 4. 刷怪逻辑 ================================================ */
function applySpawn(player, group) {
    const loc = player.getLocation();
    const world = player.getWorld();
    const count = group.count || 1;
    const radius = group.radius || 3;
    const mobType = Java.type('org.bukkit.entity.EntityType').valueOf(group.mobType || 'CREEPER');

    for (let i = 0; i < count; i++) {
        const angle = Math.random() * 2 * Math.PI;
        const r = Math.random() * radius;
        const x = loc.getX() + r * Math.cos(angle);
        const z = loc.getZ() + r * Math.sin(angle);
        const y = loc.getY();
        world.spawnEntity(new org.bukkit.Location(world, x, y, z), mobType);
    }
}

/* 6. 开箱事件 – 强制掉落 + 1 秒不可拾取 ===================== */
function onUse(event) {
    const player = event.getPlayer();
    if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

    const itemInMain = player.getInventory().getItemInMainHand();
    const result = pickSlimyItem();

    if (result.eventType === 'punish') {
        applyPunish(player, result.punish);
    } else if (result.eventType === 'spawn') {
        applySpawn(player, result.spawn);
    } else if (result.eventType === 'item') {
        const stacks = result.stacks;
        for (const item of stacks) {
            const drop = player.getWorld().dropItem(player.getLocation(), item);
            drop.setPickupDelay(PickupDelay);
        }
    }

    // 消耗幸运方块
    if (itemInMain.getAmount() > 1) {
        itemInMain.setAmount(itemInMain.getAmount() - 1);
    } else {
        itemInMain.setAmount(0);
    }
}