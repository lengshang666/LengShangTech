/*******************************************************************
 * 触发：右键主手使用
 * 行为：强制掉落 + 20 tick 不可拾取 + 惩罚/刷怪/结构/物品
 *******************************************************************/
const ItemStack   = Java.type('org.bukkit.inventory.ItemStack');
const Material    = Java.type('org.bukkit.Material');
const ChatColor   = Java.type('org.bukkit.ChatColor');

/* 1.21 药水 API */
const Registry        = Java.type('org.bukkit.Registry');
const NamespacedKey   = Java.type('org.bukkit.NamespacedKey');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const DurationTicks   = 20 * 15;

/* 掉落物控制 */
const PickupDelay = 20; // 1 秒不可拾取

/* 随机整数 [min, max] */
function randInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* 1. 配置组 ====================================================== */
const SlimyGroup = [
    /* 普通单抽组 40% */
    {
        groupWeight: 50,
        allDrop: false,
        items: [
            { type: 'vanilla', id: 'COOKIE', amount: {min:1, max:64} },              //曲奇
            { type: 'vanilla', id: 'WHEAT', amount: {min:1, max:64} },               //小麦
            { type: 'vanilla', id: 'POTATO', amount: {min:1, max:64} },               //马铃薯
            { type: 'vanilla', id: 'CARROT', amount: {min:1, max:64} },               //胡萝卜
            { type: 'vanilla', id: 'GLOW_BERRIES', amount: {min:1, max:64} },         //荧光浆果
            { type: 'vanilla', id: 'SLIME_BALL', amount: {min:1, max:64} },           //史莱姆球
            { type: 'vanilla', id: 'TURTLE_EGG', amount: {min:1, max:64} },           //海龟蛋
            { type: 'vanilla', id: 'FEATHER', amount: {min:1, max:64} },              //羽毛
            { type: 'vanilla', id: 'CHARCOAL', amount: {min:1, max:64} },             //木炭
            { type: 'vanilla', id: 'BEACON', amount: {min:1, max:2} },                //信标
            { type: 'vanilla', id: 'ENDER_PEARL', amount: {min:1, max:16} },          //末影珍珠
            { type: 'vanilla', id: 'PUMPKIN_PIE', amount: {min:1, max:64} },          //南瓜派
            { type: 'vanilla', id: 'BEETROOT', amount: {min:1, max:64} },             //甜菜根
            { type: 'vanilla', id: 'LEATHER', amount: {min:1, max:64} },              //皮革
            { type: 'vanilla', id: 'HEAVY_CORE', amount: {min:1, max:8} },            //沉重核心
            { type: 'vanilla', id: 'TURTLE_SCUTE', amount: {min:1, max:64} },         //海龟鳞甲
            { type: 'vanilla', id: 'SWEET_BERRIES', amount: {min:1, max:64} },        //甜浆果
            { type: 'vanilla', id: 'PIGLIN_HEAD', amount: {min:1, max:64} },          //猪灵头颅
            { type: 'vanilla', id: 'EGG', amount: {min:1, max:16} },                  //鸡蛋
            { type: 'vanilla', id: 'NETHER_WART', amount: {min:1, max:64} },          //下界疣
            { type: 'vanilla', id: 'SHULKER_SHELL', amount: {min:1, max:64} },        //潜影壳
            { type: 'vanilla', id: 'GOLDEN_CARROT', amount: {min:1, max:64} },        //金胡萝卜
            { type: 'vanilla', id: 'NAME_TAG', amount: {min:1, max:64} },             //命名牌
            { type: 'vanilla', id: 'EXPERIENCE_BOTTLE', amount: {min:1, max:64} },    //经验瓶
            { type: 'vanilla', id: 'BLAZE_ROD', amount: {min:1, max:64} },            //烈焰棒
            { type: 'vanilla', id: 'COBBLED_DEEPSLATE', amount: {min:1, max:64} },    //圆石深板岩
            { type: 'vanilla', id: 'SEA_LANTERN', amount: {min:1, max:64} },         //海晶灯
            { type: 'vanilla', id: 'LEAD', amount: {min:1, max:64} },                //拴绳
            { type: 'vanilla', id: 'HONEYCOMB', amount: {min:1, max:64} },            //蜂蜜comb
            { type: 'vanilla', id: 'ENCHANTING_TABLE', amount: {min:1, max:8} },      //附魔台
            { type: 'vanilla', id: 'DIAMOND_BLOCK', amount: {min:1, max:8} },         //钻石块
            { type: 'vanilla', id: 'NETHER_STAR', amount: {min:1, max:4} },           //下界之星
            { type: 'vanilla', id: 'END_PORTAL_FRAME', amount: {min:1, max:4} },      //末地传送门框架
            { type: 'vanilla', id: 'TOTEM_OF_UNDYING', amount: 1 },                    //不死图腾
            { type: 'vanilla', id: 'DRAGON_EGG', amount: 1 },                          //龙蛋
            { type: 'vanilla', id: 'DRAGON_HEAD', amount: 1 },                         //龙首
            { type: 'vanilla', id: 'SPAWNER', amount: 1 },                             //刷怪笼
            { type: 'vanilla', id: 'ELYTRA', amount: 1 },                              //鞘翅
            { type: 'vanilla', id: 'CONDUIT', amount: 1 },                             //潮涌核心
            { type: 'vanilla', id: 'EMERALD_BLOCK', amount: {min:1, max:8} }           //绿宝石块
        ]
    },
    /* 幸运套装 */
    {
        groupWeight: 10,
        allDrop: false,
        items: [
            { type: 'sf', id: 'LENGSHANG_幸运头盔', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运胸甲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运护腿', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运靴子', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运剑', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运镐', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运斧', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_幸运铲', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_黄金切尔西', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_万能附魔书', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_击退棒', amount: 1 },
            { type: 'sf', id: 'LENGSHANG_秒人斧', amount: 1 }
        ]
    },
    /* 鱼群 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'COD', amount: {min:1, max:64} },              //鳕鱼
            { type: 'vanilla', id: 'SALMON', amount: {min:1, max:64} },           //鲑鱼
            { type: 'vanilla', id: 'TROPICAL_FISH', amount: {min:1, max:64} },    //热带鱼
            { type: 'vanilla', id: 'PUFFERFISH', amount: {min:1, max:64} }        //河豚
        ]
    },
    /* 金苹果 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'GOLDEN_APPLE', amount: {min:1, max:16} },         //金苹果
            { type: 'vanilla', id: 'ENCHANTED_GOLDEN_APPLE', amount: {min:1, max:8} } //附魔金苹果
        ]
    },
    /* 矿物 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'DIAMOND', amount: {min:1, max:16} },          //钻石
            { type: 'vanilla', id: 'EMERALD', amount: {min:1, max:16} },          //绿宝石
            { type: 'vanilla', id: 'GOLD_INGOT', amount: {min:1, max:32} },       //金锭
            { type: 'vanilla', id: 'IRON_INGOT', amount: {min:1, max:32} },       //铁锭
            { type: 'vanilla', id: 'LAPIS_LAZULI', amount: {min:1, max:64} },     //青金石
            { type: 'vanilla', id: 'REDSTONE', amount: {min:1, max:64} },         //红石粉
            { type: 'vanilla', id: 'COAL', amount: {min:1, max:64} }              //煤炭
        ]
    },
    /* 食物 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'BEEF', amount: {min:1, max:64} },           //生牛肉
            { type: 'vanilla', id: 'PORKCHOP', amount: {min:1, max:64} },       //生猪排
            { type: 'vanilla', id: 'MUTTON', amount: {min:1, max:64} },         //生羊肉
            { type: 'vanilla', id: 'RABBIT', amount: {min:1, max:64} },         //生兔肉
            { type: 'vanilla', id: 'CHICKEN', amount: {min:1, max:64} }         //生鸡肉
        ]
    },
    /* 熟食 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'COOKED_BEEF', amount: {min:1, max:64} },      //牛排
            { type: 'vanilla', id: 'COOKED_PORKCHOP', amount: {min:1, max:64} },  //熟猪排
            { type: 'vanilla', id: 'COOKED_MUTTON', amount: {min:1, max:64} },    //熟羊肉
            { type: 'vanilla', id: 'COOKED_RABBIT', amount: {min:1, max:64} },    //熟兔肉
            { type: 'vanilla', id: 'COOKED_CHICKEN', amount: {min:1, max:64} }    //熟鸡肉
        ]
    },
    /* 五种珊瑚块 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'TUBE_CORAL_BLOCK', amount: {min:1, max:64} },   //管珊瑚块
            { type: 'vanilla', id: 'BRAIN_CORAL_BLOCK', amount: {min:1, max:64} },  //脑珊瑚块
            { type: 'vanilla', id: 'BUBBLE_CORAL_BLOCK', amount: {min:1, max:64} }, //气泡珊瑚块
            { type: 'vanilla', id: 'FIRE_CORAL_BLOCK', amount: {min:1, max:64} },   //火珊瑚块
            { type: 'vanilla', id: 'HORN_CORAL_BLOCK', amount: {min:1, max:64} }    //角珊瑚块
        ]
    },
    /* 五种珊瑚扇 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'TUBE_CORAL_FAN', amount: {min:1, max:64} },   //管珊瑚扇
            { type: 'vanilla', id: 'BRAIN_CORAL_FAN', amount: {min:1, max:64} },  //脑珊瑚扇
            { type: 'vanilla', id: 'BUBBLE_CORAL_FAN', amount: {min:1, max:64} }, //气泡珊瑚扇
            { type: 'vanilla', id: 'FIRE_CORAL_FAN', amount: {min:1, max:64} },   //火珊瑚扇
            { type: 'vanilla', id: 'HORN_CORAL_FAN', amount: {min:1, max:64} }    //角珊瑚扇
        ]
    },
    /* 南瓜三件套 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'CARVED_PUMPKIN', amount: {min:1, max:64} }, //雕刻南瓜
            { type: 'vanilla', id: 'JACK_O_LANTERN', amount: {min:1, max:64} }, //南瓜灯
            { type: 'vanilla', id: 'PUMPKIN', amount: {min:1, max:64} }         //南瓜
        ]
    },
    /* 两种活塞 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'PISTON', amount: {min:1, max:64} },      //活塞
            { type: 'vanilla', id: 'STICKY_PISTON', amount: {min:1, max:64} } //粘性活塞
        ]
    },
    /* 两种海绵 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'SPONGE', amount: {min:1, max:64} },     //海绵
            { type: 'vanilla', id: 'WET_SPONGE', amount: {min:1, max:64} }  //湿海绵
        ]
    },
    /* 两种灵魂 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'SOUL_SAND', amount: {min:1, max:64} }, //灵魂沙
            { type: 'vanilla', id: 'SOUL_SOIL', amount: {min:1, max:64} }  //灵魂土
        ]
    },
    /* 草方块泥土 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'DIRT', amount: {min:1, max:64} },       //泥土
            { type: 'vanilla', id: 'GRASS_BLOCK', amount: {min:1, max:64} } //草方块
        ]
    },
    /* 两种蘑菇 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'BROWN_MUSHROOM', amount: {min:1, max:64} }, //棕色蘑菇
            { type: 'vanilla', id: 'RED_MUSHROOM', amount: {min:1, max:64} }    //红色蘑菇
        ]
    },
    /* 木质工具 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'WOODEN_PICKAXE', amount: {min:1, max:1} }, //木镐
            { type: 'vanilla', id: 'WOODEN_AXE', amount: {min:1, max:1} },     //木斧
            { type: 'vanilla', id: 'WOODEN_SHOVEL', amount: {min:1, max:1} },  //木铲
            { type: 'vanilla', id: 'WOODEN_HOE', amount: {min:1, max:1} },     //木锄
            { type: 'vanilla', id: 'WOODEN_SWORD', amount: {min:1, max:1} }    //木剑
        ]
    },
    /* 石质工具 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'STONE_PICKAXE', amount: {min:1, max:1} }, //石镐
            { type: 'vanilla', id: 'STONE_AXE', amount: {min:1, max:1} },     //石斧
            { type: 'vanilla', id: 'STONE_SHOVEL', amount: {min:1, max:1} },  //石铲
            { type: 'vanilla', id: 'STONE_HOE', amount: {min:1, max:1} },     //石锄
            { type: 'vanilla', id: 'STONE_SWORD', amount: {min:1, max:1} }    //石剑
        ]
    },
    /* 金质工具 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'GOLDEN_PICKAXE', amount: {min:1, max:1} }, //金镐
            { type: 'vanilla', id: 'GOLDEN_AXE', amount: {min:1, max:1} },     //金斧
            { type: 'vanilla', id: 'GOLDEN_SHOVEL', amount: {min:1, max:1} },  //金铲
            { type: 'vanilla', id: 'GOLDEN_HOE', amount: {min:1, max:1} },     //金锄
            { type: 'vanilla', id: 'GOLDEN_SWORD', amount: {min:1, max:1} }    //金剑
        ]
    },
    /* 铁质工具 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'IRON_PICKAXE', amount: {min:1, max:1} }, //铁镐
            { type: 'vanilla', id: 'IRON_AXE', amount: {min:1, max:1} },     //铁斧
            { type: 'vanilla', id: 'IRON_SHOVEL', amount: {min:1, max:1} },  //铁铲
            { type: 'vanilla', id: 'IRON_HOE', amount: {min:1, max:1} },     //铁锄
            { type: 'vanilla', id: 'IRON_SWORD', amount: {min:1, max:1} }    //铁剑
        ]
    },
    /* 钻石工具 */
    {
        groupWeight: 30,
        allDrop: true,
        items: [
            { type: 'vanilla', id: 'DIAMOND_PICKAXE', amount: {min:1, max:1} }, //钻石镐
            { type: 'vanilla', id: 'DIAMOND_AXE', amount: {min:1, max:1} },     //钻石斧
            { type: 'vanilla', id: 'DIAMOND_SHOVEL', amount: {min:1, max:1} },  //钻石铲
            { type: 'vanilla', id: 'DIAMOND_HOE', amount: {min:1, max:1} },     //钻石锄
            { type: 'vanilla', id: 'DIAMOND_SWORD', amount: {min:1, max:1} }    //钻石剑
        ]
    },
    /* 事件触发组 5% */
    {
        groupWeight: 5,
        eventType: 'punish',
        strikeLightning: true,
        effects: [
            { type: 'POISON',   amplifier: 2 },   //中毒
            { type: 'SLOWNESS', amplifier: 1 },  //缓慢
            { type: 'WEAKNESS', amplifier: 1 }   //虚弱
        ]
    },
    /* 刷怪组 苦力怕 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CREEPER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 羊 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SHEEP',
        count: 3,
        radius: 3
    },
    /* 刷怪组 牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'COW',
        count: 3,
        radius: 3
    },
    /* 刷怪组 猪 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PIG',
        count: 3,
        radius: 3
    },
    /* 刷怪组 蘑菇牛 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'MOOSHROOM',
        count: 3,
        radius: 3
    },
    /* 刷怪组 鹦鹉 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'PARROT',
        count: 2,
        radius: 3
    },
    /* 刷怪组 史莱姆 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'SLIME',
        count: 2,
        radius: 3
    },
    /* 刷怪组 村民 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'VILLAGER',
        count: 1,
        radius: 3
    },
    /* 刷怪组 流浪商人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WANDERING_TRADER',
        count: 3,
        radius: 3
    },
    /* 刷怪组 铁傀儡 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'IRON_GOLEM',
        count: 2,
        radius: 3
    },
    /* 刷怪组 骆驼 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'CAMEL',
        count: 1,
        radius: 3
    },
    /* 刷怪组 恶魂 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GHAST',
        count: 1,
        radius: 3
    },
    /* 刷怪组 凋零骷髅 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'WITHER_SKELETON',
        count: 3,
        radius: 3
    },
    /* 刷怪组 巨人僵尸 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'GIANT',
        count: 1,
        radius: 3
    },
    /* 刷怪组 烈焰人 */
    {
        groupWeight: 3,
        eventType: 'spawn',
        mobType: 'BLAZE',
        count: 1,
        radius: 3
    }
];

/* 2. 核心抽奖 ================================================ */
function pickSlimyItem() {
    const total = SlimyGroup.reduce((sum, g) => sum + g.groupWeight, 0);
    let r = Math.random() * total;
    let pickedGroup = null;
    for (const g of SlimyGroup) {
        if (r < g.groupWeight) { pickedGroup = g; break; }
        r -= g.groupWeight;
    }
    if (!pickedGroup) pickedGroup = SlimyGroup[SlimyGroup.length - 1];

    if (pickedGroup.eventType === 'punish') {
        return { eventType: 'punish', punish: pickedGroup };
    }
    if (pickedGroup.eventType === 'spawn') {
        return { eventType: 'spawn', spawn: pickedGroup };
    }

    /* 物品组（单抽） */
    if (!pickedGroup.allDrop) {
        const entry = pickedGroup.items[Math.floor(Math.random() * pickedGroup.items.length)];
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            return { eventType: 'item', stacks: [item] };
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            return { eventType: 'item', stacks: [item] };
        }
    }

    /* 物品组（全掉） */
    const list = [];
    for (const entry of pickedGroup.items) {
        const amt = (typeof entry.amount === 'object')
    ? randInt(entry.amount.min, entry.amount.max)
    : (entry.amount || 1);
        if (entry.type === 'vanilla') {
            const item = new ItemStack(Material.valueOf(entry.id), amt);
            /* 不设置 DisplayName，保持原版名称 */
            list.push(item);
        } else {
            const sfItem = getSfItemById(entry.id);
            if (sfItem == null) throw new Error('[天命盲盒] 错误的Slimefun ID: ' + entry.id);
            const item = sfItem.getItem().clone();
            item.setAmount(amt);
            list.push(item);
        }
    }
    return { eventType: 'item', allDrop: true, stacks: list };
}

/* 3. 负面事件 ================================================ */
function applyPunish(player, group) {
    if (group.strikeLightning) {
        player.getWorld().strikeLightning(player.getLocation());
    }
    const keyMap = {
        'POISON':    'poison',
        'SLOW':      'slowness',
        'SLOWNESS':  'slowness',
        'WEAKNESS':  'weakness',
        'BLINDNESS': 'blindness',
        'WITHER':    'wither',
        'NAUSEA':    'nausea',
        'HUNGER':    'hunger',
        'MINING_FATIGUE': 'mining_fatigue'
    };
    if (group.effects) {
        for (const ef of group.effects) {
            const key = keyMap[ef.type] || ef.type.toLowerCase();
            const type = Registry.EFFECT.get(NamespacedKey.minecraft(key));
            if (type == null) {
                throw new Error('[天命盲盒] 无效药水类型: ' + ef.type + ' (key=' + key + ')');
            }
            player.addPotionEffect(new PotionEffect(type, DurationTicks, ef.amplifier, false, true));
        }
    }
}

/* 4. 刷怪逻辑 ================================================ */
function applySpawn(player, group) {
    const loc = player.getLocation();
    const world = player.getWorld();
    const count = group.count || 1;
    const radius = group.radius || 3;
    const mobType = Java.type('org.bukkit.entity.EntityType').valueOf(group.mobType || 'CREEPER');

    for (let i = 0; i < count; i++) {
        const angle = Math.random() * 2 * Math.PI;
        const r = Math.random() * radius;
        const x = loc.getX() + r * Math.cos(angle);
        const z = loc.getZ() + r * Math.sin(angle);
        const y = loc.getY();
        world.spawnEntity(new org.bukkit.Location(world, x, y, z), mobType);
    }
}

/* 6. 开箱事件 – 强制掉落 + 1 秒不可拾取 ===================== */
function onUse(event) {
    const player = event.getPlayer();
    if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

    const itemInMain = player.getInventory().getItemInMainHand();
    const result = pickSlimyItem();

    if (result.eventType === 'punish') {
        applyPunish(player, result.punish);
    } else if (result.eventType === 'spawn') {
        applySpawn(player, result.spawn);
    } else if (result.eventType === 'item') {
        const stacks = result.stacks;
        for (const item of stacks) {
            const drop = player.getWorld().dropItem(player.getLocation(), item);
            drop.setPickupDelay(PickupDelay);
        }
    }
    // 消耗幸运方块
    if (itemInMain.getAmount() > 1) {
        itemInMain.setAmount(itemInMain.getAmount() - 1);
    } else {
        itemInMain.setAmount(0);
    }
}