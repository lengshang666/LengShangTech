/* 基岩头盔 - 1.21 可用 - 仅 Buff - ID=JYTK */
const HELMET_TYPE = 'NETHERITE_HELMET';
const SLIME_ID    = 'JYTK';
const BUFF_TICKS  = 1200;
const LOOP_TICKS  = 1200;

const helmetTasks = new Map();
let globalTask = null;

function log(msg) {   // 快速看日志
    Packages.org.bukkit.Bukkit.getConsoleSender().sendMessage("[基岩头盔] " + msg);
}

function getType(n) {
    try { return Packages.org.bukkit.potion.PotionEffectType.getByName(n) || Packages.org.bukkit.potion.PotionEffectType[n]; } catch (e) { return null; }
}
function addEffect(p, n, d, a) {
    const t = getType(n);
    if (t) p.addPotionEffect(new Packages.org.bukkit.potion.PotionEffect(t, d, a));
}

function giveBuffs(p) {
    addEffect(p, "NIGHT_VISION",    BUFF_TICKS, 0);
    addEffect(p, "WATER_BREATHING", BUFF_TICKS, 0);
    addEffect(p, "GLOWING",         200,        0);
    addEffect(p, "STRENGTH",        BUFF_TICKS, 1);
    addEffect(p, "RESISTANCE",      BUFF_TICKS, 2);
    addEffect(p, "HEALTH_BOOST",    BUFF_TICKS, 1);
    addEffect(p, "LUCK",            BUFF_TICKS, 2);
    addEffect(p, "HASTE",           BUFF_TICKS, 1);
    addEffect(p, "SATURATION",      100,        0);
    log("给 " + p.getName() + " 发放 Buff");
}

function isWearingHelmet(p) {
    const item = p.getInventory().getHelmet();
    if (!item || item.getType().name() !== HELMET_TYPE) return false;
    const sf = Packages.io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem.getByItem(item);
    return sf && sf.getId() === SLIME_ID;
}

function startLoop(p) {
    const uuid = p.getUniqueId().toString();
    if (helmetTasks.has(uuid)) return;
    log("开始循环 " + p.getName());
    const task = p.getServer().getScheduler().runTaskTimer(null, function() {
        if (!p.isOnline() || !isWearingHelmet(p)) { stopLoop(p); return; }
        giveBuffs(p);
        p.sendActionBar('§e[瑶光祝福] 祝福已刷新！');
    }, 0, LOOP_TICKS);
    helmetTasks.set(uuid, task);
}
function stopLoop(p) {
    const uuid = p.getUniqueId().toString();
    const t = helmetTasks.get(uuid);
    if (t) { t.cancel(); helmetTasks.delete(uuid); log("停止循环 " + p.getName()); }
}

/* 每 1 tick 轮询头盔槽 */
function startGlobalCheck() {
    return Packages.org.bukkit.Bukkit.getScheduler().runTaskTimer(null, function() {
        Packages.org.bukkit.Bukkit.getOnlinePlayers().forEach(function(p) {
            const wearing = isWearingHelmet(p);
            const running = helmetTasks.has(p.getUniqueId().toString());
            if (wearing && !running) { giveBuffs(p); startLoop(p); }
            else if (!wearing && running) { stopLoop(p); }
        });
    }, 1, 1);
}

function onLoad() {
    if (globalTask == null) globalTask = startGlobalCheck();
    log("脚本已加载，1 tick 轮询开始");
    return {
        PlayerInteractEvent: function(evt) {
            const item = evt.getItem();
            if (!item || item.getType().name() !== HELMET_TYPE) return;
            const sf = Packages.io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem.getByItem(item);
            if (!sf || sf.getId() !== SLIME_ID) return;
            giveBuffs(evt.getPlayer());
            evt.getPlayer().sendMessage('§e[瑶光祝福] §a祝福已降临！');
        }
    };
}