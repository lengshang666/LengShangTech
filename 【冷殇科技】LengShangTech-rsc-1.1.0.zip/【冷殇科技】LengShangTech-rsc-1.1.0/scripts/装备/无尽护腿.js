/* =============================================
 *  Infinity Leggings MK2 – 完全继承版  (Fixed)
 * ============================================= */
const Material        = Java.type('org.bukkit.Material');
const Attribute       = Java.type('org.bukkit.attribute.Attribute');
const AttributeModifier = Java.type('org.bukkit.attribute.AttributeModifier');
const Operation       = Java.type('org.bukkit.attribute.AttributeModifier.Operation');
const EquipmentSlot   = Java.type('org.bukkit.inventory.EquipmentSlot');
const Enchantment     = Java.type('org.bukkit.enchantments.Enchantment');
const PotionEffect    = Java.type('org.bukkit.potion.PotionEffect');
const PotionEffectType= Java.type('org.bukkit.potion.PotionEffectType');

/* 1. 拿模板；若找不到就终止后续代码（用 if-else 包住） */
const template = slimefunItemStack('INFINITY_LEGS');
if (!template) {
    logger.warn('未能找到 INFINITY_LEGS，请确认 SlimeCustomizer 已加载该物品！');
} else {
    /* 2. 构建新物品 */
    const mk2 = new ItemStackBuilder(Material.NETHERITE_LEGGINGS)
        .setDisplayName('§b无尽护腿 §7MK2')
        .setLore(template.getItemMeta().getLore())
        .setCustomModelData(666)
        .setUnbreakable(true)
        .addAttributeModifier(Attribute.GENERIC_ARMOR,       6, Operation.ADD_NUMBER, EquipmentSlot.LEGS)
        .addAttributeModifier(Attribute.GENERIC_ARMOR_TOUGHNESS, 3, Operation.ADD_NUMBER, EquipmentSlot.LEGS)
        .addAttributeModifier(Attribute.GENERIC_KNOCKBACK_RESISTANCE, 1, Operation.ADD_NUMBER, EquipmentSlot.LEGS)
        .addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 20)
        .addUnsafeEnchantment(Enchantment.THORNS, 255)
        .addItemTag('slimefun:slimefun_item', 'INFINITY_LEGS_MK2')
        .addItemTag('slimefun:soulbound', true)
        .addItemTag('slimefun:radiation_protection', true)
        .build();

    /* 3. 注册 */
    registerItem('INFINITY_LEGS_MK2', mk2);

    /* 4. 药水效果 */
    const BUFFS = [
        new PotionEffect(PotionEffectType.FAST_DIGGING,  Integer.MAX_VALUE, 2),
        new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0),
        new PotionEffect(PotionEffectType.SATURATION,   Integer.MAX_VALUE, 0)
    ];

    onEvent('armor.EquipEvent', e => {
        if (e.getType() !== EquipmentSlot.LEGS) return;
        const item = e.getItem();
        if (!item || item.getItemTag('slimefun:slimefun_item') !== 'INFINITY_LEGS_MK2') return;
        BUFFS.forEach(buff => e.getPlayer().addPotionEffect(buff));
    });

    onEvent('armor.UnequipEvent', e => {
        if (e.getType() !== EquipmentSlot.LEGS) return;
        const item = e.getItem();
        if (!item || item.getItemTag('slimefun:slimefun_item') !== 'INFINITY_LEGS_MK2') return;
        BUFFS.forEach(buff => e.getPlayer().removePotionEffect(buff.getType()));
    });
}