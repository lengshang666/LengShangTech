/* 瑶光·祝福 —— 全效合一（基岩头盔） */
const DISPLAY_NAME = '§e§l基岩头盔';
const HELMET_TYPE = 'NETHERITE_HELMET';

const COOLDOWN_MS = 1000;
const RANGE = 10;
const BUFF_TICKS = 1200; // 60秒增益

const cdMap = new Map();

function getParticle(name) {
    try { return Packages.org.bukkit.Particle[name]; } catch (e) { return null; }
}

/* ===== 整合所有增益效果 ===== */
function onUse(source) {
    const player = source && source.getPlayer ? source.getPlayer() : source;
    if (!player || !player.getUniqueId) return;

    const uuid = player.getUniqueId().toString();
    const now = Date.now();

    if (cdMap.has(uuid) && now - cdMap.get(uuid) < COOLDOWN_MS) {
        player.sendActionBar('§e祝福之力凝聚中...');
        return;
    }
    cdMap.set(uuid, now);

    // 一次性施加所有效果
    applyCombinedBuffs(player);
    player.sendMessage('§e[瑶光祝福] §a祝福已降临！');
}

/* ===== 光辉+勇气+智慧 三效合一 ===== */
function applyCombinedBuffs(player) {
    const PotionEffect = Packages.org.bukkit.potion.PotionEffect;
    const PotionEffectType = Packages.org.bukkit.potion.PotionEffectType;
    const world = player.getWorld();
    const LivingEntity = Packages.org.bukkit.entity.LivingEntity;

    // 获取所有粒子类型
    const glowParticle = getParticle("GLOW_SQUID_INK") || getParticle("GLOW");
    const endRodParticle = getParticle("END_ROD") || getParticle("CRIT_MAGIC");
    const critParticle = getParticle("CRIT") || getParticle("CRIT_MAGIC");
    const enchantParticle = getParticle("ENCHANT") || getParticle("ENCHANTMENT_TABLE");
    const electricSparkParticle = getParticle("ELECTRIC_SPARK") || getParticle("FIREWORKS_SPARK");

    world.getNearbyEntities(player.getLocation(), RANGE, RANGE, RANGE).forEach(function(ent) {
        if (ent instanceof LivingEntity) {
            // ========== 光辉效果 ==========
            const nightVisionType = PotionEffectType.getByName("NIGHT_VISION") || PotionEffectType.NIGHT_VISION;
            const waterBreathingType = PotionEffectType.getByName("WATER_BREATHING") || PotionEffectType.WATER_BREATHING;
            const glowingType = PotionEffectType.getByName("GLOWING");
            
            if (nightVisionType) ent.addPotionEffect(new PotionEffect(nightVisionType, BUFF_TICKS, 0));
            if (waterBreathingType) ent.addPotionEffect(new PotionEffect(waterBreathingType, BUFF_TICKS, 0));
            if (glowingType) ent.addPotionEffect(new PotionEffect(glowingType, 200, 0));

            // ========== 勇气效果 ==========
            const strengthType = PotionEffectType.getByName("STRENGTH") || PotionEffectType.INCREASE_DAMAGE;
            const resistanceType = PotionEffectType.getByName("RESISTANCE") || PotionEffectType.DAMAGE_RESISTANCE;
            const healthBoostType = PotionEffectType.getByName("HEALTH_BOOST") || PotionEffectType.HEALTH_BOOST;
            
            if (strengthType) ent.addPotionEffect(new PotionEffect(strengthType, BUFF_TICKS, 1));
            if (resistanceType) ent.addPotionEffect(new PotionEffect(resistanceType, BUFF_TICKS, 1));
            if (healthBoostType) ent.addPotionEffect(new PotionEffect(healthBoostType, BUFF_TICKS, 1));

            // ========== 智慧效果 ==========
            const luckType = PotionEffectType.getByName("LUCK") || PotionEffectType.LUCK;
            const hasteType = PotionEffectType.getByName("HASTE") || PotionEffectType.FAST_DIGGING;
            const saturationType = PotionEffectType.getByName("SATURATION") || PotionEffectType.SATURATION;
            
            if (luckType) ent.addPotionEffect(new PotionEffect(luckType, BUFF_TICKS, 1));
            if (hasteType) ent.addPotionEffect(new PotionEffect(hasteType, BUFF_TICKS, 1));
            if (saturationType) ent.addPotionEffect(new PotionEffect(saturationType, 100, 0));

            // ========== 粒子效果 ==========
            if (glowParticle) world.spawnParticle(glowParticle, ent.getLocation(), 6, 1, 2, 1, 0.1);
            if (critParticle) world.spawnParticle(critParticle, ent.getLocation(), 4, 1, 2, 1, 0.1);
            if (enchantParticle) world.spawnParticle(enchantParticle, ent.getLocation(), 8, 1, 2, 1, 0.2);
        }
    });
    
    // ========== 光环粒子效果 ==========
    if (endRodParticle) {
        for (let i = 0; i < 360; i += 20) {
            const rad = i * Math.PI / 180;
            const loc = player.getLocation().clone().add(Math.cos(rad) * RANGE, 0, Math.sin(rad) * RANGE);
            world.spawnParticle(endRodParticle, loc, 2, 0, 0, 0, 0.05);
        }
    }
    
    if (electricSparkParticle) {
        for (let i = 0; i < 360; i += 30) {
            const rad = i * Math.PI / 180;
            const loc = player.getLocation().clone().add(Math.cos(rad) * RANGE, 1, Math.sin(rad) * RANGE);
            world.spawnParticle(electricSparkParticle, loc, 1, 0, 0, 0, 0);
        }
    }
    
    // ========== 音效 ==========
    world.playSound(player.getLocation(), 'block.beacon.activate', 1, 1.5);
    world.playSound(player.getLocation(), 'entity.player.levelup', 1, 1.0);
    world.playSound(player.getLocation(), 'block.enchantment_table.use', 1, 1.0);
}

/* ===== 事件绑定（仅保留穿戴触发）===== */
function onLoad() {
    return {
        InventoryClickEvent: function(evt) {
            if (evt.getRawSlot() !== 39) return; // 39是头盔槽
            
            const human = evt.getWhoClicked();
            if (!(human instanceof Packages.org.bukkit.entity.Player)) return;
            
            const item = evt.getCurrentItem();
            if (!item || item.getType().name() !== HELMET_TYPE) return;
            
            const meta = item.getItemMeta();
            if (!meta || meta.getDisplayName() !== DISPLAY_NAME) return;
            
            // 延迟1tick确保穿戴完成
            human.getServer().getScheduler().runTaskLater(null, function() {
                if (human.getInventory().getHelmet()?.equals(item)) {
                    onUse(human);
                }
            }, 1);
        }
    };
}