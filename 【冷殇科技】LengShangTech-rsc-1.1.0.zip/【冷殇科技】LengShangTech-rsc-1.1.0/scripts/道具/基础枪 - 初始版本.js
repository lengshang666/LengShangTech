function onUse(e) {
    shootStart(e);
}
const shootStart = (e) => {
    let p = e.getPlayer();
    let loc = p.getLocation();
    let sb = p.getWorld().spawn(loc.add(0, p.getEyeHeight(), 0), org.bukkit.entity.Snowball.class);
    sb.setShooter(p);
    let direction = loc.getDirection();
    sb.setFireTicks(100);
    sb.setGlowing(true);
    sb.setVelocity(direction.multiply(8));
}