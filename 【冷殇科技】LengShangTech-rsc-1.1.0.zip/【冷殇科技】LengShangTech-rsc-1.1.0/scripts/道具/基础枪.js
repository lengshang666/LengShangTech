function onUse(e) {
    shootStart(e);
}

const shootStart = (e) => {
    let p = e.getPlayer();
    let loc = p.getLocation();
    let sb = p.getWorld().spawn(loc.add(0, p.getEyeHeight(), 0), org.bukkit.entity.Snowball.class);
    sb.setShooter(p);
    let direction = loc.getDirection();
    sb.setFireTicks(100);
    sb.setGlowing(true);
    sb.setVelocity(direction.multiply(8));
    
    // 使用Bukkit调度器检查雪球是否击中
    let plugin = org.bukkit.Bukkit.getPluginManager().getPlugin("RykenSlimefunCustomizer");
    let taskId = org.bukkit.Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, function() {
        if (sb.isDead() || !sb.isValid()) {
            // 雪球已经消失，取消任务
            org.bukkit.Bukkit.getScheduler().cancelTask(taskId);
            return;
        }
        
        // 检查雪球附近是否有实体
        let location = sb.getLocation();
        let nearbyEntities = location.getWorld().getNearbyEntities(location, 0.5, 0.5, 0.5);
        
        for (let i = 0; i < nearbyEntities.size(); i++) {
            let entity = nearbyEntities.get(i);
            // 排除发射者和雪球本身
            if (entity !== p && entity !== sb && entity instanceof org.bukkit.entity.LivingEntity) {
                // 造成10点伤害
                entity.damage(100000.0, p);
                sb.remove(); // 移除雪球
                org.bukkit.Bukkit.getScheduler().cancelTask(taskId); // 取消任务
                return;
            }
        }
    }, 1, 1); // 每1 tick检查一次
}