function onWeaponHit(event) {
    // 20%概率触发雷击
    if (Math.random() < 0.20) {
        // 获取被攻击的实体
        let target = event.getEntity();
        
        // 在目标位置召唤闪电
        target.getWorld().strikeLightning(target.getLocation());
    }
}