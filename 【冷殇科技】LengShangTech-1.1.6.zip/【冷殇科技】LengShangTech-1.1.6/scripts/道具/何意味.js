var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var SlimefunItem = Java.type("io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem");
var NamespacedKey = Java.type("org.bukkit.NamespacedKey");
var PersistentDataType = Java.type("org.bukkit.persistence.PersistentDataType");
var Long = Java.type("java.lang.Long");
var ByteArrayInputStream = Java.type("java.io.ByteArrayInputStream");
var ObjectInputStream = Java.type("java.io.ObjectInputStream");
var ArrayList = Java.type("java.util.ArrayList");

var STORAGE_SLOT = 10;
var CARD_SLOT = 16;
var WORK_SLOT = 22;
var OUTPUT_SLOT = 13;

var REQUIRED_AMOUNT = 16777216;
var COPY_CARD_IDS = ["_FINALTECH_COPY_CARD", "COPY_CARD"];

function isQuantumStorage(item) {
    if (!item || !item.hasItemMeta()) return false;
    var name = ChatColor.stripColor(item.getItemMeta().getDisplayName() || "");
    return name.includes("网络量子存储");
}

function parseItemBytes(byteArray) {
    try {
        var bis = new ByteArrayInputStream(byteArray);
        var ois = new ObjectInputStream(bis);
        var wrapper = ois.readObject();
        ois.close();
        var mapField = wrapper.getClass().getDeclaredField("map");
        mapField.setAccessible(true);
        var map = mapField.get(wrapper);
        if (!map || !map.containsKey("type")) return null;
        if (map.containsKey("meta")) {
            var metaValue = map.get("meta");
            if (metaValue && metaValue.getClass().getName() === "org.bukkit.util.io.Wrapper") {
                var metaMapField = metaValue.getClass().getDeclaredField("map");
                metaMapField.setAccessible(true);
                var metaMap = metaMapField.get(metaValue);
                if (metaMap && metaMap.containsKey("PublicBukkitValues")) {
                    var pbv = metaMap.get("PublicBukkitValues");
                    if (typeof pbv === "string") {
                        var json = pbv.replace(/\n/g, '').trim();
                        try {
                            var data = JSON.parse(json);
                            if (data["slimefun:slimefun_item"]) return data["slimefun:slimefun_item"];
                        } catch (e) {
                            var match = json.match(/"slimefun:slimefun_item"\s*:\s*"([^"]+)"/);
                            if (match) return match[1];
                        }
                    }
                }
            }
        }
        var typeValue = map.get("type");
        try {
            return Material.valueOf(typeValue).getKey().toString();
        } catch (e) {
            return typeValue;
        }
    } catch (e) {
        return null;
    }
}

function getStoredItemIdFromQuantum(item) {
    try {
        if (!isQuantumStorage(item)) return null;
        var meta = item.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        var quantumKey = new NamespacedKey("networks", "quantum_storage");
        if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return null;
        var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
        var itemKey = new NamespacedKey("networks", "item");
        if (!quantumData.has(itemKey, PersistentDataType.BYTE_ARRAY)) return null;
        var bytes = quantumData.get(itemKey, PersistentDataType.BYTE_ARRAY);
        return parseItemBytes(bytes);
    } catch (e) {
        return null;
    }
}

function getQuantumStorageInfo(item) {
    try {
        if (!isQuantumStorage(item)) return null;
        var meta = item.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        var quantumKey = new NamespacedKey("networks", "quantum_storage");
        if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return null;
        var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
        var amountKey = new NamespacedKey("networks", "amount");
        var maxAmountKey = new NamespacedKey("networks", "max_amount");
        var amount = 0, maxAmount = 2147483647;
        if (quantumData.has(amountKey, PersistentDataType.LONG)) amount = Number(quantumData.get(amountKey, PersistentDataType.LONG));
        else if (quantumData.has(amountKey, PersistentDataType.INTEGER)) amount = Number(quantumData.get(amountKey, PersistentDataType.INTEGER));
        if (quantumData.has(maxAmountKey, PersistentDataType.LONG)) maxAmount = Number(quantumData.get(maxAmountKey, PersistentDataType.LONG));
        else if (quantumData.has(maxAmountKey, PersistentDataType.INTEGER)) maxAmount = Number(quantumData.get(maxAmountKey, PersistentDataType.INTEGER));
        return { amount: amount, maxAmount: maxAmount };
    } catch (e) {
        return null;
    }
}

function removeFromQuantumStorage(item, amountToRemove) {
    if (amountToRemove <= 0) return 0;
    try {
        if (!isQuantumStorage(item)) return 0;
        var meta = item.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        var quantumKey = new NamespacedKey("networks", "quantum_storage");
        if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return 0;
        var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
        var amountKey = new NamespacedKey("networks", "amount");
        var currentAmount = 0;
        if (quantumData.has(amountKey, PersistentDataType.LONG)) currentAmount = Number(quantumData.get(amountKey, PersistentDataType.LONG));
        else if (quantumData.has(amountKey, PersistentDataType.INTEGER)) currentAmount = Number(quantumData.get(amountKey, PersistentDataType.INTEGER));
        if (currentAmount < amountToRemove) return 0;
        var newAmount = currentAmount - amountToRemove;
        if (newAmount >= 2147483647) quantumData.set(amountKey, PersistentDataType.LONG, Long.valueOf(newAmount.toString()));
        else quantumData.set(amountKey, PersistentDataType.INTEGER, Math.floor(newAmount));
        pdc.set(quantumKey, PersistentDataType.TAG_CONTAINER, quantumData);
        item.setItemMeta(meta);
        updateQuantumStorageLore(item, newAmount);
        return amountToRemove;
    } catch (e) {
        return 0;
    }
}

function updateQuantumStorageLore(item, newAmount) {
    try {
        var meta = item.getItemMeta();
        if (!meta || !meta.hasLore()) return;
        var lore = meta.getLore();
        var newLore = new ArrayList();
        var plainNumber = newAmount.toString();
        for (var i = 0; i < lore.size(); i++) {
            var line = lore.get(i);
            if (line.includes("数量:")) {
                if (line.includes('"text":"')) line = line.replace(/("text":")(\d+)(")/, '$1' + plainNumber + '$3');
                else line = line.replace(/(数量:.*?)(\d+)/, '$1' + plainNumber);
            }
            newLore.add(line);
        }
        meta.setLore(newLore);
        item.setItemMeta(meta);
    } catch (e) {}
}

function isCopyCard(item) {
    if (!item) return false;
    var sf = SlimefunItem.getByItem(item);
    if (!sf) return false;
    for (var i = 0; i < COPY_CARD_IDS.length; i++) {
        if (sf.getId() === COPY_CARD_IDS[i]) return true;
    }
    return false;
}

function createCopyCard(originalItem) {
    try {
        var FinalTechItems = Java.type("io.taraxacum.finaltech.setup.FinalTechItems");
        return FinalTechItems.COPY_CARD.getValidItem(originalItem, "1");
    } catch (e) {
        var card = new ItemStack(Material.FLINT);
        var meta = card.getItemMeta();
        var name = originalItem.getItemMeta().hasDisplayName() ? originalItem.getItemMeta().getDisplayName() : originalItem.getType().name();
        meta.setDisplayName("§6复制卡");
        meta.setLore([
            "§7物品复制卡",
            "§7目标物品: " + name,
            "§7物品类型: " + originalItem.getType().name(),
            "",
            "§e使用说明:",
            "§7- 可在序列化构造机中使用",
            "§7- 输入16777216个相同物品",
            "§7- 输出该物品的复制",
            "",
            "§c注意: 需要FinalTECH附属支持完整功能"
        ]);
        card.setItemMeta(meta);
        return card;
    }
}

function getItemPrototype(id) {
    var sf = SlimefunItem.getById(id);
    if (sf) return sf.getItem().clone();
    try {
        var matName = id.includes(':') ? id.split(':')[1] : id;
        return new ItemStack(Material.valueOf(matName.toUpperCase()), 1);
    } catch (e) {
        try {
            return new ItemStack(Material.valueOf(id), 1);
        } catch (e2) {
            return null;
        }
    }
}

function isSameCopyCard(a, b) {
    if (!a || !b || !isCopyCard(a) || !isCopyCard(b)) return false;
    var ma = a.getItemMeta(), mb = b.getItemMeta();
    if (!ma.hasLore() || !mb.hasLore()) return false;
    var la = ma.getLore(), lb = mb.getLore();
    if (la.size() < 3 || lb.size() < 3) return false;
    return String(la.get(1)) === String(lb.get(1)) && String(la.get(2)) === String(lb.get(2));
}

function canPlaceInOutput(inv, newCard) {
    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) return true;
    if (!isCopyCard(out) || out.getAmount() >= 64) return false;
    return isSameCopyCard(out, newCard);
}

function onClick(player, slot, slotItem, clickAction) {
    if (slot !== WORK_SLOT) return false;
    var inv = player.getOpenInventory().getTopInventory();
    if (!inv) return false;

    var storage = inv.getItem(STORAGE_SLOT);
    if (!storage || !isQuantumStorage(storage)) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var card = inv.getItem(CARD_SLOT);
    if (!card || !isCopyCard(card)) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var itemId = getStoredItemIdFromQuantum(storage);
    if (!itemId) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var info = getQuantumStorageInfo(storage);
    if (!info || info.amount < REQUIRED_AMOUNT) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var proto = getItemPrototype(itemId);
    if (!proto) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var newCard = createCopyCard(proto);
    newCard.setAmount(1);

    if (!canPlaceInOutput(inv, newCard)) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    if (removeFromQuantumStorage(storage, REQUIRED_AMOUNT) < REQUIRED_AMOUNT) {
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    if (card.getAmount() > 1) card.setAmount(card.getAmount() - 1);
    else inv.setItem(CARD_SLOT, null);

    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) inv.setItem(OUTPUT_SLOT, newCard);
    else out.setAmount(out.getAmount() + 1);

    player.playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0, 1.0);
    return true;
}

function onOpen(player) {}
function onClose(player) {}