/**
 * 获取皮肤头颅
 * 功能：通过命名牌和玩家头颅合成自定义皮肤头颅
 */

// ==================== Bukkit API 类导入 ====================
var Material = Java.type("org.bukkit.Material");                    // 材料/物品类型枚举
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");        // 物品堆栈类
var ChatColor = Java.type("org.bukkit.ChatColor");                  // 聊天颜色代码
var SkullMeta = Java.type("org.bukkit.inventory.meta.SkullMeta");   // 头颅元数据（1.21前使用）
var ItemMeta = Java.type("org.bukkit.inventory.meta.ItemMeta");     // 物品元数据基类
var NamespacedKey = Java.type("org.bukkit.NamespacedKey");          // 命名空间键（用于NBT数据）
var PersistentDataType = Java.type("org.bukkit.persistence.PersistentDataType"); // 持久化数据类型
var URL = Java.type("java.net.URL");                                // 网络URL类
var Scanner = Java.type("java.util.Scanner");                       // 输入扫描器
var InputStreamReader = Java.type("java.io.InputStreamReader");     // 输入流读取器
var UUID = Java.type("java.util.UUID");                             // 通用唯一标识符
var Base64 = Java.type("java.util.Base64");                         // Base64编码/解码

// ==================== 常量定义 ====================
// GUI槽位索引（Minecraft箱子界面，0-53，每行9个槽位）
var STORAGE_SLOT = 10;   // 左侧输入槽 - 放置命名牌（第2行第2列）
var CARD_SLOT = 16;      // 右侧输入槽 - 放置玩家头颅（第2行第8列）
var WORK_SLOT = 22;      // 工作槽 - 点击此处开始合成（第3行第5列）
var OUTPUT_SLOT = 13;    // 输出槽 - 生成结果（第2行第6列）

// 皮肤API地址（备用，当前使用Mojang官方API）
var API_URL = "https://o.xbottle.top/bottleskin/";

// ==================== 工具函数 ====================

/**
 * 检查物品是否为有效的命名牌
 * 有效条件：是命名牌类型，且有自定义显示名称（非空）
 * @param {ItemStack} item - 要检查的物品
 * @returns {boolean} 是否为有效命名牌
 */
function isValidNameTag(item) {
    if (!item || item.getType() !== Material.NAME_TAG) return false;  // 空或非命名牌
    if (!item.hasItemMeta()) return false;                            // 无元数据
    var meta = item.getItemMeta();
    // 检查是否有显示名称，且去除颜色代码后不为空
    return meta.hasDisplayName() && ChatColor.stripColor(meta.getDisplayName()).trim().length > 0;
}

/**
 * 从命名牌中提取玩家ID
 * @param {ItemStack} item - 命名牌物品
 * @returns {string|null} 玩家ID或null
 */
function getPlayerIdFromNameTag(item) {
    if (!isValidNameTag(item)) return null;
    var meta = item.getItemMeta();
    // 去除颜色代码并清理空格
    return ChatColor.stripColor(meta.getDisplayName()).trim();
}

/**
 * 检查物品是否为玩家头颅
 * @param {ItemStack} item - 要检查的物品
 * @returns {boolean} 是否为玩家头颅
 */
function isPlayerHead(item) {
    if (!item) return false;
    // 兼容新旧版本：1.13+使用PLAYER_HEAD，旧版使用SKULL_ITEM
    return item.getType() === Material.PLAYER_HEAD || item.getType().name() === "SKULL_ITEM";
}

/**
 * 通过Mojang API获取玩家皮肤URL
 * 流程：1.通过玩家名获取UUID -> 2.通过UUID获取皮肤数据
 * @param {string} playerName - 玩家名称
 * @returns {string|null} 皮肤URL或null
 */
function fetchSkinUrl(playerName) {
    try {
        // ===== 第一步：获取玩家UUID =====
        var uuidUrl = new URL("https://api.mojang.com/users/profiles/minecraft/" + encodeURIComponent(playerName));
        var uuidConn = uuidUrl.openConnection();
        uuidConn.setRequestMethod("GET");
        uuidConn.setConnectTimeout(5000);    // 连接超时5秒
        uuidConn.setReadTimeout(5000);       // 读取超时5秒
        uuidConn.setRequestProperty("User-Agent", "Mozilla/5.0");  // 设置UA避免被拒绝
        
        // 读取API响应
        var uuidScanner = new Scanner(uuidConn.getInputStream(), "UTF-8").useDelimiter("\\A");
        var uuidResponse = uuidScanner.hasNext() ? uuidScanner.next() : "";
        uuidScanner.close();
        
        // 解析JSON获取UUID
        var uuidJson = JSON.parse(uuidResponse);
        if (!uuidJson || !uuidJson.id) {
            print("UUID not found for " + playerName);
            return null;
        }
        var uuid = uuidJson.id;  // Mojang返回无连字符的UUID字符串
        
        // ===== 第二步：获取玩家属性（包含皮肤数据） =====
        var profileUrl = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid);
        var profileConn = profileUrl.openConnection();
        profileConn.setRequestMethod("GET");
        profileConn.setConnectTimeout(5000);
        profileConn.setReadTimeout(5000);
        profileConn.setRequestProperty("User-Agent", "Mozilla/5.0");
        
        var profileScanner = new Scanner(profileConn.getInputStream(), "UTF-8").useDelimiter("\\A");
        var profileResponse = profileScanner.hasNext() ? profileScanner.next() : "";
        profileScanner.close();
        
        // 解析皮肤数据
        var profileJson = JSON.parse(profileResponse);
        var properties = profileJson.properties;
        for (var i in properties) {
            var prop = properties[i];
            if (prop.name === "textures") {
                // textures值是Base64编码的JSON字符串
                var decodedBytes = Base64.getDecoder().decode(prop.value);
                var decodedStr = new java.lang.String(decodedBytes, "UTF-8");
                var textureJson = JSON.parse(decodedStr);
                var skinUrl = textureJson.textures.SKIN.url;  // 提取皮肤URL
                return skinUrl;
            }
        }
        return null;
    } catch (e) {
        print("Mojang API Error: " + e);
        return null;
    }
}

/**
 * 从皮肤URL中提取纹理值（texture hash）
 * @param {string} skinUrl - 完整皮肤URL，如 http://textures.minecraft.net/texture/xxx
 * @returns {string|null} 纹理哈希值或null
 */
function extractTextureValue(skinUrl) {
    if (!skinUrl) return null;
    // 使用正则表达式匹配标准格式的URL
    var match = skinUrl.match(/textures\.minecraft\.net\/texture\/([a-f0-9]+)/i);
    if (match && match[1]) {
        return match[1];
    }
    // 备用方案：直接取URL最后一部分
    var parts = skinUrl.split('/');
    var lastPart = parts[parts.length - 1];
    if (lastPart && lastPart.match(/^[a-f0-9]+$/i)) {
        return lastPart;
    }
    return null;
}

/**
 * 将字符串进行Base64编码（UTF-8）
 * @param {string} str - 要编码的字符串
 * @returns {string|null} Base64编码结果或null
 */
function base64Encode(str) {
    try {
        // 手动将JS字符串转换为UTF-8字节数组
        var bytes = [];
        for (var i = 0; i < str.length; i++) {
            var charCode = str.charCodeAt(i);
            if (charCode < 0x80) {
                bytes.push(charCode);
            } else if (charCode < 0x800) {
                bytes.push(0xC0 | (charCode >> 6));
                bytes.push(0x80 | (charCode & 0x3F));
            } else {
                bytes.push(0xE0 | (charCode >> 12));
                bytes.push(0x80 | ((charCode >> 6) & 0x3F));
                bytes.push(0x80 | (charCode & 0x3F));
            }
        }
        // 转换为Java字节数组
        var javaBytes = Java.type("byte[]")(bytes.length);
        for (var i = 0; i < bytes.length; i++) {
            javaBytes[i] = bytes[i];
        }
        return Base64.getEncoder().encodeToString(javaBytes);
    } catch (e) {
        print("Base64 encode error: " + e);
        return null;
    }
}

/**
 * 创建自定义皮肤头颅
 * 使用1.21+的PlayerProfile API设置皮肤
 * @param {string} textureValue - 纹理哈希值
 * @param {string} playerName - 玩家名称（用于显示）
 * @returns {ItemStack} 生成的头颅物品
 */
function createCustomSkull(textureValue, playerName) {
    try {
        // 创建基础头颅物品
        var head = new ItemStack(Material.PLAYER_HEAD, 1);
        var meta = head.getItemMeta();
        
        // 1.21+新API：创建玩家档案
        var profile = org.bukkit.Bukkit.createPlayerProfile(UUID.randomUUID(), playerName || "Unknown");
        
        // 构造完整皮肤URL
        var skinUrl = "http://textures.minecraft.net/texture/" + textureValue;
        var url = new URL(skinUrl);
        
        // 设置皮肤到档案
        var textures = profile.getTextures();
        textures.setSkin(url);
        profile.setTextures(textures);
        
        // 将档案应用到物品元数据
        meta.setOwnerProfile(profile);
        
        // 设置物品显示信息
        meta.setDisplayName("§6" + (playerName || "自定义皮肤") + "的头");
        meta.setLore([
            "§7自定义皮肤头颅",
            "§7玩家: §f" + (playerName || "Unknown"),
        ]);
        
        head.setItemMeta(meta);
        return head;
        
    } catch (e) {
        // 错误处理：返回带有错误信息的默认头颅
        print("Skull creation error: " + e);
        var head = new ItemStack(Material.PLAYER_HEAD, 1);
        var meta = head.getItemMeta();
        meta.setDisplayName("§6" + (playerName || "自定义皮肤") + "的头");
        meta.setLore([
            "§7自定义皮肤头颅",
            "§7玩家: §f" + (playerName || "Unknown"),
            "§c注意: 设置失败，使用默认头颅",
            "§c错误: " + e.toString().substring(0, 50)
        ]);
        head.setItemMeta(meta);
        return head;
    }
}

/**
 * 检查是否可以放置物品到输出槽
 * @param {Inventory} inv - 容器界面
 * @param {ItemStack} newItem - 要放置的新物品
 * @returns {boolean} 是否可以放置
 */
function canPlaceInOutput(inv, newItem) {
    var out = inv.getItem(OUTPUT_SLOT);
    // 输出槽为空
    if (out == null || out.getType().isAir()) return true;
    // 检查物品是否相同且未达到堆叠上限（64）
    if (!out.isSimilar(newItem) || out.getAmount() >= 64) return false;
    return true;
}

// ==================== 事件处理函数 ====================

/**
 * 点击事件处理（核心逻辑）
 * 当玩家点击工作槽时执行合成逻辑
 * @param {Player} player - 点击的玩家
 * @param {number} slot - 点击的槽位
 * @param {ItemStack} slotItem - 槽位中的物品
 * @param {Object} clickAction - 点击动作信息
 * @returns {boolean} 是否取消默认行为
 */
function onClick(player, slot, slotItem, clickAction) {
    // 只处理工作槽的点击
    if (slot !== WORK_SLOT) return false;
    
    var inv = player.getOpenInventory().getTopInventory();
    if (!inv) return false;

    // ===== 检查左侧输入槽（命名牌） =====
    var nameTag = inv.getItem(STORAGE_SLOT);
    if (!isValidNameTag(nameTag)) {
        player.sendMessage("§c左侧输入槽必须放置已重命名的命名牌（包含玩家ID）！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;  // 取消点击
    }

    // 获取玩家ID
    var playerId = getPlayerIdFromNameTag(nameTag);
    if (!playerId) {
        player.sendMessage("§c无法从命名牌读取玩家ID！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 检查右侧输入槽（玩家头颅） =====
    var headItem = inv.getItem(CARD_SLOT);
    if (!isPlayerHead(headItem)) {
        player.sendMessage("§c右侧输入槽必须放置玩家的头！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 查询皮肤数据 =====
    player.sendMessage("§7正在查询玩家 §f" + playerId + " §7的皮肤...");
    
    var skinUrl = fetchSkinUrl(playerId);
    if (!skinUrl) {
        player.sendMessage("§c无法获取皮肤信息，请检查玩家ID是否正确！是否是正版账号！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    var textureValue = extractTextureValue(skinUrl);
    if (!textureValue) {
        player.sendMessage("§c无法解析皮肤URL格式！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 生成自定义头颅 =====
    var customSkull = createCustomSkull(textureValue, playerId);
    customSkull.setAmount(1);

    // 检查输出槽
    if (!canPlaceInOutput(inv, customSkull)) {
        player.sendMessage("§c输出槽被其他物品占用或已满！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 消耗材料 =====
    // 消耗命名牌
    if (nameTag.getAmount() > 1) {
        nameTag.setAmount(nameTag.getAmount() - 1);
    } else {
        inv.setItem(STORAGE_SLOT, null);
    }

    // 消耗头颅
    if (headItem.getAmount() > 1) {
        headItem.setAmount(headItem.getAmount() - 1);
    } else {
        inv.setItem(CARD_SLOT, null);
    }

    // ===== 输出结果 =====
    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) {
        inv.setItem(OUTPUT_SLOT, customSkull);
    } else {
        out.setAmount(out.getAmount() + 1);
    }

    // 成功提示
    player.sendMessage("§a成功生成 §f" + playerId + " §a的自定义皮肤头颅！");
    player.sendMessage("§7皮肤URL: §f" + skinUrl);
    player.playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0, 1.0);
    return true;
}

/**
 * 打开界面事件（当前无特殊处理）
 * @param {Player} player - 打开界面的玩家
 */
function onOpen(player) {}

/**
 * 关闭界面事件（当前无特殊处理）
 * @param {Player} player - 关闭界面的玩家
 */
function onClose(player) {}