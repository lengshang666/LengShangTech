// ============================================
// 重箭王功能实现
// ============================================

/**
 * 重箭王 - 同时射出10支箭
 * @param {Player} player - 射箭的玩家
 * @param {EntityShootBowEvent} event - 射箭事件
 */
function sanshegong(player, event) {
  // 获取拉弓力度（0.0-1.0），乘以4作为箭矢速度倍率
  let force = event.getForce() * 4;
  let world = player.getWorld();
  // 获取玩家眼睛位置（箭矢发射起点）
  let eyeLocation = player.getEyeLocation();
  // 获取玩家视线方向向量
  let direction = eyeLocation.getDirection();

  // 循环生成10支箭
  // 参数说明：spawnArrow(发射位置, 方向向量, 速度, 散布精度)
  // 散布精度10表示箭矢会有一定随机偏移，形成散射效果
  for (let i = 0; i < 10; i++) {
    world.spawnArrow(eyeLocation, direction, force, 10);
  }
}

// ============================================
// 修罗·灭世神弓 - 冷却时间
// ============================================

// 存储每个玩家上次触发灭世神弓效果的时间（毫秒）
// 使用Java的HashMap，key为玩家UUID，value为时间戳
const lightningBowCooldowns = new java.util.HashMap();

// 冷却时间配置（毫秒）
// 3000 = 3秒，如需修改冷却时间，改这个数值即可
// 例如：5000=5秒，2000=2秒，1500=1.5秒
const LIGHTNING_BOW_COOLDOWN_MS = 3000;

/**
 * 检查玩家是否处于冷却中
 * @param {Player} player - 要检查的玩家
 * @returns {boolean} - true表示可以触发效果（冷却已结束），false表示在冷却中
 */
function checkLightningBowCooldown(player) {
  let playerUUID = player.getUniqueId();
  // Date.now() 获取当前时间戳（毫秒）
  let currentTime = Date.now();
  // 从HashMap中获取该玩家上次触发的时间
  let lastTriggerTime = lightningBowCooldowns.get(playerUUID);

  // 如果从未触发过（null或undefined），或冷却时间已过，返回true
  if (lastTriggerTime === null || lastTriggerTime === undefined) {
    return true;
  }

  // 计算时间差（当前时间 - 上次触发时间）
  let timeDiff = currentTime - lastTriggerTime;
  // 如果时间差大于等于冷却时间，返回true（冷却结束）
  return timeDiff >= LIGHTNING_BOW_COOLDOWN_MS;
}

/**
 * 设置玩家触发时间（开始冷却）
 * @param {Player} player - 触发效果的玩家
 */
function setLightningBowCooldown(player) {
  // 将当前时间存入HashMap，标记该玩家已进入冷却
  lightningBowCooldowns.put(player.getUniqueId(), Date.now());
}

/**
 * 获取剩余冷却时间（秒）- 用于提示信息
 * @param {Player} player - 要查询的玩家
 * @returns {number} - 剩余秒数（向上取整）
 */
function getRemainingCooldownSeconds(player) {
  let playerUUID = player.getUniqueId();
  let lastTriggerTime = lightningBowCooldowns.get(playerUUID);

  // 如果没有记录，返回0
  if (lastTriggerTime === null || lastTriggerTime === undefined) {
    return 0;
  }

  let currentTime = Date.now();
  // 计算剩余毫秒数 = 冷却总时长 - (当前时间 - 上次触发时间)
  let remainingMs = LIGHTNING_BOW_COOLDOWN_MS - (currentTime - lastTriggerTime);

  // 如果已过期，返回0
  if (remainingMs <= 0) {
    return 0;
  }

  // 转换为秒并向上取整（例如2.1秒显示为3秒）
  return Math.ceil(remainingMs / 1000);
}

// ============================================
// 修罗·灭世神弓
// ============================================

/**
 * 灭世神弓主函数 - 箭矢落地后召唤连锁闪电
 * @param {Player} player - 使用弓的玩家
 * @param {EntityShootBowEvent} event - 射箭事件
 */
function lightningBow(player, event) {
  // ========== 冷却检查 ==========
  if (!checkLightningBowCooldown(player)) {
    // 处于冷却中，发送提示并取消效果
    let remainingSeconds = getRemainingCooldownSeconds(player);
    // §c=红色, §e=黄色，发送冷却提示
    player.sendMessage("§c[修罗·灭世神弓] §7技能冷却中，还需 §c" + remainingSeconds + " §7秒");
    return; // 直接返回，不执行后续效果
  }

  // 设置冷却时间（立即设置，防止玩家快速连射时重复触发）
  setLightningBowCooldown(player);

  // ========== 效果实现 ==========
  let arrow = event.getProjectile(); // 获取射出的箭矢实体
  let hasStruck = false;  // 标记是否已经触发第一次雷击
  let strikeCount = 0;    // 当前雷击次数计数器
  let maxStrikes = 5;     // 最大雷击次数，可修改此数值改变闪电数量

  // runRepeating(回调函数, 延迟tick, 周期tick)
  // 10tick=0.5秒延迟后开始检测，每1tick(0.05秒)检测一次
  runRepeating((t) => {
    // 如果已达到最大雷击次数，清理并停止
    if (strikeCount >= maxStrikes) {
      hasStruck = true;
      arrow.remove(); // 移除箭矢实体
      t.cancel();     // 停止循环任务
      return;
    }

    // 第一次触发条件：箭矢命中方块或已死亡，且尚未触发过
    if ((arrow.isInBlock() || arrow.isDead()) && !hasStruck) {
      hasStruck = true;
      let location = arrow.getLocation(); // 获取箭矢位置
      let world = location.getWorld();
      // 执行第一次雷击（索引0）
      performLightningStrike(world, location, player, strikeCount);
      strikeCount++;
      if (arrow.isDead()) {
        arrow.remove();
      }
      return;
    }

    // 后续雷击：已触发过第一次，且未达到最大次数
    if (hasStruck && strikeCount < maxStrikes) {
      let location = arrow.getLocation();
      let world = location.getWorld();
      // 在落点周围随机6格范围内生成偏移坐标
      // (Math.random() - 0.5) * 6 生成 -3 到 +3 的随机数
      let offsetX = (Math.random() - 0.5) * 6;
      let offsetZ = (Math.random() - 0.5) * 6;
      let strikeLoc = location.clone().add(offsetX, 0, offsetZ);
      performLightningStrike(world, strikeLoc, player, strikeCount);
      strikeCount++;
    }

    // 达到最大次数后停止
    if (strikeCount >= maxStrikes) {
      t.cancel();
    }
  }, 10, 1);
}

/**
 * 执行单次雷击效果
 * @param {World} world - 世界对象
 * @param {Location} location - 雷击位置
 * @param {Player} player - 攻击者（用于伤害统计）
 * @param {number} strikeIndex - 当前雷击索引（0-4），影响伤害和范围
 */
function performLightningStrike(world, location, player, strikeIndex) {
  // 在指定位置召唤闪电（会造成伤害和燃烧）
  world.strikeLightning(location);

  // 爆炸威力计算：基础2.0 + 每次增加0.5
  // 第1次=2.0, 第2次=2.5, 第3次=3.0, 第4次=3.5, 第5次=4.0
  let explosionPower = 2.0 + (strikeIndex * 0.5);
  // createExplosion(位置, 威力, 是否引发火灾, 是否破坏方块)
  world.createExplosion(location, explosionPower, true, false);

  // 伤害范围计算：基础4格 + 每次增加1格
  // 第1次=4格, 第5次=8格
  let radius = 4 + strikeIndex;
  // 获取范围内的所有实体
  let nearbyEntities = world.getNearbyEntities(location, radius, radius, radius);

  // 遍历所有受影响实体
  for (let i = 0; i < nearbyEntities.size(); i++) {
    let entity = nearbyEntities.get(i);
    // 跳过玩家自己（避免自伤）
    if (entity === player) continue;

    // 只影响生物实体（玩家、怪物、动物等）
    if (entity instanceof org.bukkit.entity.LivingEntity) {
      // 伤害计算：基础6点（3心）+ 每次增加2点（1心）
      // 第1次=6点, 第5次=14点
      let damage = 6.0 + (strikeIndex * 2.0);
      entity.damage(damage, player); // 对实体造成伤害，记录攻击者为player

      // 设置燃烧时间：基础100tick(5秒) + 每次增加20tick(1秒)
      // 第1次=5秒, 第5次=9秒
      entity.setFireTicks(100 + (strikeIndex * 20));

      // 计算击退向量（从爆炸中心指向实体）
      let knockback = entity.getLocation().toVector()
        .subtract(location.toVector())
        .normalize() // 单位向量（长度为1）
        .multiply(1.5 + strikeIndex * 0.3) // 水平击退力度，每次增加0.3
        .setY(0.5); // 垂直向上击飞
      entity.setVelocity(knockback); // 应用击退

      // 添加缓慢效果（Slowness）
      // 持续时间：60tick(3秒) + 每次增加20tick(1秒)
      // 等级：2（即III级，因为0=I, 1=II, 2=III）
      entity.addPotionEffect(new org.bukkit.potion.PotionEffect(
        org.bukkit.potion.PotionEffectType.SLOWNESS,
        60 + strikeIndex * 20,
        2
      ));

      // 添加失明效果（Blindness）
      // 持续时间：40tick(2秒) + 每次增加10tick(0.5秒)
      // 等级：0（即I级）
      entity.addPotionEffect(new org.bukkit.potion.PotionEffect(
        org.bukkit.potion.PotionEffectType.BLINDNESS,
        40 + strikeIndex * 10,
        0
      ));
    }
  }

  // ========== 特效部分 ==========

  // 电火花粒子（位置，数量20，扩散范围XYZ各2格，速度1）
  world.spawnParticle(org.bukkit.Particle.ELECTRIC_SPARK, location, 20, 2, 2, 2, 1);
  // 火焰粒子（数量10，扩散范围1格，速度0.1）
  world.spawnParticle(org.bukkit.Particle.FLAME, location, 10, 1, 1, 1, 0.1);

  // 播放雷声音效（位置，音效名，音量1.0，音调1.0）
  // 音量范围0.0-1.0，音调0.5=低音，1.0=正常，2.0=高音
  world.playSound(location, "entity.lightning_bolt.thunder", 1.0, 1.0);
}

// ============================================
// 弓箭事件 - 主入口
// ============================================

/**
 * 实体射箭事件处理函数
 * @param {EntityShootBowEvent} e - 射箭事件
 */
function onEntityShootBow(e) {
  let entity = e.getEntity();
  // 只处理玩家射出的箭（排除骷髅等生物）
  if (!(entity instanceof org.bukkit.entity.Player)) {
    return;
  }
  let player = entity;

  // 判断玩家手持物品并执行对应功能
  // handleItemInMainHand 检查主手是否持有指定Slimefun物品
  if (handleItemInMainHand(player, "LENGSHANG_重箭王")) {
    sanshegong(player, e); // 执行重箭王
  } else if (handleItemInMainHand(player, "LENGSHANG_修罗·灭世神弓")) {
    lightningBow(player, e); // 执行灭世神弓
  }
}

/**
 * 检查玩家主手是否持有指定Slimefun物品
 * @param {Player} player - 玩家
 * @param {string} slimefunItemId - Slimefun物品ID
 * @returns {boolean} - 是否匹配
 */
function handleItemInMainHand(player, slimefunItemId) {
  let itemInMainHand = player.getInventory().getItemInMainHand();
  // getSfItemByItem 是RSC提供的函数，获取Slimefun物品对象
  let sfItem = getSfItemByItem(itemInMainHand);
  if (sfItem !== null) {
    return slimefunItemId === sfItem.getId();
  } else {
    return false;
  }
}


// ============================================
// 修罗·不灭神铠
// ============================================

// 存储每个玩家的生命值历史记录，用于检测生命值变化
// key: 玩家UUID, value: 上次记录的生命值（浮点数）
const healthHistory = new java.util.HashMap();

/**
 * 检查玩家是否装备修罗·不灭神铠（胸甲位置）
 * @param {Player} player - 要检查的玩家
 * @returns {boolean} - 是否装备
 */
function isWearingBusiArmor(player) {
  let chestplate = player.getInventory().getChestplate();
  // 检查胸甲是否为空（null 或空气）
  if (chestplate === null || chestplate.getType() === org.bukkit.Material.AIR) {
    return false;
  }
  // 获取Slimefun物品并检查ID是否为 "LENGSHANG_修罗·不灭神铠"
  let sfItem = getSfItemByItem(chestplate);
  if (sfItem === null) return false;
  let itemId = sfItem.getId();
  
  // 只要ID以这个前缀开头就匹配
  if (itemId.startsWith("LENGSHANG_修罗·不灭神铠")) {
    return true;
  }
  return false;
}

/**
 * 执行不灭守护效果：回血、清除负面效果、添加增益效果、播放特效
 * @param {Player} player - 触发效果的玩家
 */
function performRevivalEffect(player) {
  // 安全检查：如果玩家已死亡或生命值为0，不触发效果（防止异常）
  if (player.isDead() || player.getHealth() <= 0) {
    return;
  }

  let world = player.getWorld();
  let location = player.getLocation();
  // 获取玩家最大生命值（考虑生命提升等属性）
  let maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
  let currentHealth = player.getHealth();

  // 回血到最大生命值的50%（0.5倍）
  // 如需修改回血比例，更改 0.5 即可，例如 0.3=30%, 0.8=80%
  let newHealth = maxHealth * 0.5;
  player.setHealth(newHealth);

  // ========== 清除负面效果 ==========
  // 定义要清除的效果列表
  let negativeEffects = [
    org.bukkit.potion.PotionEffectType.POISON,      // 中毒
    org.bukkit.potion.PotionEffectType.SLOWNESS,    // 缓慢
    org.bukkit.potion.PotionEffectType.WEAKNESS,    // 虚弱
    org.bukkit.potion.PotionEffectType.BLINDNESS,   // 失明
    org.bukkit.potion.PotionEffectType.WITHER,      // 凋零
    org.bukkit.potion.PotionEffectType.HUNGER,      // 饥饿
    org.bukkit.potion.PotionEffectType.LEVITATION,  // 飘浮
    org.bukkit.potion.PotionEffectType.UNLUCK       // 霉运
  ];

  // 遍历并移除所有负面效果
  for (let i = 0; i < negativeEffects.length; i++) {
    player.removePotionEffect(negativeEffects[i]);
  }

  // ========== 添加增益效果 ==========
  // 格式：new PotionEffect(效果类型, 持续时间tick, 等级)
  // 注意：等级从0开始，0=I级, 1=II级, 2=III级，以此类推

  // 抗性提升（Resistance）- 5秒(100tick)，等级4（V级，80%伤害减免）
  player.addPotionEffect(new org.bukkit.potion.PotionEffect(
    org.bukkit.potion.PotionEffectType.RESISTANCE, 100, 4
  ));

  // 生命恢复（Regeneration）- 10秒(200tick)，等级2（III级）
  player.addPotionEffect(new org.bukkit.potion.PotionEffect(
    org.bukkit.potion.PotionEffectType.REGENERATION, 200, 2
  ));

  // 力量（Strength）- 8秒(160tick)，等级1（II级，+3攻击力）
  player.addPotionEffect(new org.bukkit.potion.PotionEffect(
    org.bukkit.potion.PotionEffectType.STRENGTH, 160, 1
  ));

  // 速度（Speed）- 8秒(160tick)，等级1（II级，+40%移速）
  player.addPotionEffect(new org.bukkit.potion.PotionEffect(
    org.bukkit.potion.PotionEffectType.SPEED, 160, 1
  ));

  // ========== 播放特效 ==========

  // 不死图腾粒子（中心点向上1格，数量100，扩散0.5/1/0.5，速度0.5）
  world.spawnParticle(org.bukkit.Particle.TOTEM_OF_UNDYING, location.add(0, 1, 0), 100, 0.5, 1, 0.5, 0.5);
  // 爱心粒子（中心点向上2格，数量20）
  world.spawnParticle(org.bukkit.Particle.HEART, location.add(0, 2, 0), 20, 0.5, 0.5, 0.5, 0);
  // 末地烛粒子（数量50，扩散1格，速度0.1）
  world.spawnParticle(org.bukkit.Particle.END_ROD, location, 50, 1, 1, 1, 0.1);

  // 播放音效
  world.playSound(location, "item.totem.use", 1.0, 1.0);        // 不死图腾使用音效
  world.playSound(location, "entity.player.levelup", 0.5, 1.5);  // 升级音效（音量0.5）

  // ========== 发送提示 ==========
  // sendTitle(主标题, 副标题, 淡入tick, 持续tick, 淡出tick)
  // §c=红色, §l=粗体, §e=黄色, §a=绿色
  player.sendTitle("§c§l不灭守护", "§e修罗·不灭神铠已激活", 10, 70, 20);
  player.sendMessage("§6[修罗·不灭神铠] §a不灭守护已触发！生命值恢复至 " + Math.round(newHealth) + " 点！");
}

// ============================================
// 事件监听函数 - 需要在RSC配置中注册
// ============================================

/**
 * 玩家加入服务器事件
 * RSC注册: PlayerJoinEvent: onPlayerJoin
 * 功能：延迟1秒后启动该玩家的生命值监测
 */
function onPlayerJoin(e) {
  let player = e.getPlayer();
  // runLater(回调函数, 延迟tick) - 20tick = 1秒
  runLater((t) => {
    startHealthMonitor(player);
  }, 20);
}

/**
 * 玩家退出服务器事件
 * RSC注册: PlayerQuitEvent: onPlayerQuit
 * 功能：清理该玩家的所有数据，防止内存泄漏
 */
function onPlayerQuit(e) {
  let player = e.getPlayer();
  // 清理不灭神铠监测数据
  healthHistory.remove(player.getUniqueId());
  // 清理灭世神弓冷却数据
  lightningBowCooldowns.remove(player.getUniqueId());
}

/**
 * 玩家复活事件
 * RSC注册: PlayerRespawnEvent: onPlayerRespawn
 * 功能：重置生命值记录，确保复活后能正常检测
 */
function onPlayerRespawn(e) {
  let player = e.getPlayer();
  // 延迟0.25秒（5tick）重置，确保复活完成
  runLater((t) => {
    healthHistory.put(player.getUniqueId(), player.getHealth());
  }, 5);
}

// ============================================
// 核心监测功能
// ============================================

/**
 * 持续监测玩家生命值变化
 * 每2tick（0.1秒）检查一次，精确捕捉生命值减少
 * @param {Player} player - 要监测的玩家
 */
function startHealthMonitor(player) {
  // 检查玩家是否有效（非null且在线）
  if (!player || !player.isOnline()) {
    return;
  }

  // 初始化玩家的生命值记录为当前生命值
  healthHistory.put(player.getUniqueId(), player.getHealth());

  // 启动循环任务（延迟0tick立即开始，每2tick执行一次）
  runRepeating((t) => {
    // 玩家离线时停止监测并清理数据
    if (!player.isOnline()) {
      healthHistory.remove(player.getUniqueId());
      t.cancel(); // 停止循环
      return;
    }

    // 玩家死亡时清理记录，等待复活事件重新初始化
    if (player.isDead()) {
      healthHistory.remove(player.getUniqueId());
      return;
    }

    // 获取上次记录的生命值
    let lastHealth = healthHistory.get(player.getUniqueId());
    // 获取当前生命值
    let currentHealth = player.getHealth();
    // 获取最大生命值
    let maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();

    // 异常检测：历史记录异常，或玩家刚复活（当前血量是上次记录的2倍以上）
    // 则重置记录，避免误判（例如玩家通过其他方式大幅回血）
    if (lastHealth === null || lastHealth === undefined || lastHealth <= 0 || currentHealth > lastHealth * 2) {
      healthHistory.put(player.getUniqueId(), currentHealth);
      return;
    }

    // 如果玩家未装备铠甲，只更新记录不触发效果
    if (!isWearingBusiArmor(player)) {
      healthHistory.put(player.getUniqueId(), currentHealth);
      return;
    }

    // 如果当前生命值<=0（已死亡），不触发效果
    if (currentHealth <= 0) {
      healthHistory.put(player.getUniqueId(), currentHealth);
      return;
    }

    // ========== 触发条件判断 ==========
    // 条件1：生命值减少（currentHealth < lastHealth - 0.001，0.001防止浮点误差）
    // 条件2：当前生命值 <= 最大生命值的25%（0.25倍）
    // 如需修改触发阈值，更改 0.25 即可，例如 0.3=30%, 0.2=20%
    if (currentHealth < lastHealth - 0.001 && currentHealth / maxHealth <= 0.25) {
      // 触发不灭守护效果
      performRevivalEffect(player);

      // 效果触发后，更新记录为效果应用后的生命值（防止立即重复触发）
      let newHealth = player.getHealth();
      healthHistory.put(player.getUniqueId(), newHealth);
    } else {
      // 未触发条件，正常更新记录为当前生命值
      healthHistory.put(player.getUniqueId(), currentHealth);
    }
  }, 0, 2); // 延迟0tick，周期2tick
}

/**
 * 实体受到伤害事件
 * RSC注册: EntityDamageEvent: onEntityDamage （注意：需要设置为MONITOR优先级或适当调整）
 * 功能：致命伤害时拦截并触发不灭守护
 * @param {EntityDamageEvent} e - 伤害事件
 */
function onEntityDamage(e) {
  let entity = e.getEntity();
  // 只处理玩家
  if (!(entity instanceof org.bukkit.entity.Player)) {
    return;
  }
  let player = entity;

  // 未装备铠甲不处理
  if (!isWearingBusiArmor(player)) {
    return;
  }

  // 玩家已死亡不处理
  if (player.isDead() || player.getHealth() <= 0) {
    return;
  }

  // 获取实际造成的伤害（考虑护甲、附魔、抗性等后的最终伤害）
  let finalDamage = e.getFinalDamage();
  let currentHealth = player.getHealth();
  let maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();

  // 计算受伤后的生命值
  let healthAfterDamage = currentHealth - finalDamage;

  // ========== 拦截条件 ==========
  // 条件1：致命伤害（伤害 >= 当前生命值，即这一击会致死）
  // 条件2：受伤后生命值 <= 最大生命值的25%
  // 满足任一条件即触发
  if (finalDamage >= currentHealth || healthAfterDamage / maxHealth <= 0.25) {
    // 取消伤害事件，防止玩家死亡
    e.setCancelled(true);
    // 触发不灭守护效果
    performRevivalEffect(player);
  }
  // 非致命伤害不拦截，让玩家正常扣血
}

// ============================================
// 初始化
// ============================================

/**
 * 为所有在线玩家启动监测
 * 在脚本加载时执行（服务器启动或重载时）
 */
function initAllPlayers() {
  // Bukkit.getOnlinePlayers() 获取所有在线玩家
  let onlinePlayers = org.bukkit.Bukkit.getOnlinePlayers();
  for (let i = 0; i < onlinePlayers.size(); i++) {
    let player = onlinePlayers.get(i);
    startHealthMonitor(player);
  }
}

// 脚本加载时立即执行初始化
initAllPlayers();