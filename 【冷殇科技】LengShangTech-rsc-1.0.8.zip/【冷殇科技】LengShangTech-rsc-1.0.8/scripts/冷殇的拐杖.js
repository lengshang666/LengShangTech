function onUse(event) {
  let player = event.getPlayer();
  let requiredSlimefunId = "LENGSHANG_LENGSHANG";
  let copyCount = 1;   
  let inventory = player.getInventory();
  let hasItem = false;

  for (let i = 0; i < inventory.getSize(); i++) {
    let item = inventory.getItem(i);
    if (item !== null) {
      let sfItem = SlimefunItem.getByItem(item);
      if (sfItem !== null && sfItem.getId() === requiredSlimefunId) {
        hasItem = true;
        break;
      }
    }
  }

  if (!hasItem) {
    player.sendMessage;
    return;
  }

  let world = player.getWorld();
  let eyeLocation = player.getEyeLocation();
  let direction = eyeLocation.getDirection();
  let notplayer = eyeLocation.add(0, -0.7, 0).add(direction);
  let maxDistance = 100;
  let rayTraceResults = world.rayTrace(notplayer, direction, maxDistance,
      org.bukkit.FluidCollisionMode.ALWAYS, true, 0, null);

  let entity = rayTraceResults.getHitEntity();

  if (entity instanceof org.bukkit.entity.Item) {
    let item = entity.getItemStack();
    let newAmount = item.clone();
    newAmount.setAmount(64);
    let location = entity.getLocation();
    for (let i = 0; i < copyCount; i++) {
      world.dropItemNaturally(location, newAmount);
    }
  }
}