// ============================================
// 冷殇商店系统
// 基于 RykenSlimefunCustomizer (RSC) + GraalJS 开发
// ============================================

// ============================================
// 【配置区域 1】分类配置 - 修改这里可以添加/删除分类
// ============================================
const CATEGORIES = [
    {
        id: '树苗',      // 分类唯一标识符，用于关联 ITEMS 中的物品列表
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0树§x§F§F§D§7§0§0苗 §x§3§C§A§F§F§F⚡',     // 分类显示名称（带颜色代码 §6=金色）
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1全部树苗 §x§C§D§5§B§9§9❀',       // 分类图标的描述文本
        icon: 'OAK_SAPLING',         // 分类图标材质（原版物品ID）
        slot: 10                 // 分类在主菜单中的槽位（10=第2行第2个）
    },
    {
        id: '花',
        name: '§x§F§F§0§0§0§0⚡ §x§A§D§F§F§2§F花 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1各类花 §x§C§D§5§B§9§9❀',
        icon: 'PINK_TULIP',
        slot: 11
    },
    {
        id: '矿物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0矿§x§F§F§D§7§0§0物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1各种矿物 §x§C§D§5§B§9§9❀',
        icon: 'DIAMOND',
        slot: 12
    },
    {
        id: '掉落物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0掉§x§F§F§D§7§0§0落§x§A§D§F§F§2§F物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1生物掉落物 §x§C§D§5§B§9§9❀',
        icon: 'BLAZE_ROD',
        slot: 13
    },
    {
        id: '杂物',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0杂§x§F§F§D§7§0§0物 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1杂物与农作物 §x§C§D§5§B§9§9❀',
        icon: 'POTATO',
        slot: 14
    },
    {
        id: '方块',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0方§x§F§F§D§7§0§0块 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9各种方块 §x§C§D§5§B§9§9❀',
        icon: 'STONE',
        slot: 15
    },
    {
        id: '粘液科技',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0粘§x§F§F§D§7§0§0液 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9粘液基础物资 §x§C§D§5§B§9§9❀',
        icon: 'SLIME_BALL',
        slot: 16
    },
    {
        id: '合成锭',
        name: '§x§F§F§0§0§0§0⚡ §x§F§F§A§5§0§0合§x§F§F§D§7§0§0成§x§A§D§F§F§2§F锭 §x§3§C§A§F§F§F⚡',
        lore: '§x§F§F§B§6§C§1❀ §x§F§F§B§6§C§1一键加工 §x§C§D§5§B§9§9❀',
        icon: 'IRON_INGOT',
        slot: 19
    }
];

// ============================================
// 【配置区域 2】界面装饰配置
// ============================================
const INFO_ITEM = {
    material: 'PAINTING',      // 信息图标材质
    name: '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9聚§x§E§B§9§1§B§1宝§x§E§1§7§F§A§9阁 §x§C§D§5§B§9§9❀',         // 标题（§l=粗体）
    lore: ['§f点击下方分类查看可购买物品', '§f每个物品标有售价']  // 说明文字
};

const MAIN_TITLE = '§x§8§0§0§0§F§F造§x§9§0§2§0§D§0物§x§A§0§4§0§B§0主§x§B§0§6§0§9§0编§x§C§0§8§0§7§0码§x§D§0§A§0§5§0器';  // 主菜单窗口标题
// const MAIN_TITLE = '§x§F§F§B§6§C§1❀ §x§F§5§A§3§B§9聚§x§E§B§9§1§B§1宝§x§E§1§7§F§A§9阁 §x§C§D§5§B§9§9❀';  // 主菜单窗口标题
const SUB_PRE = '§x§F§F§B§6§C§1❀ ';              // 子菜单标题前缀
const SUB_SUF = ' §x§C§D§5§B§9§9❀';                  // 子菜单标题后缀  聚宝阁

// 边框槽位（54格箱子中哪些位置显示边框玻璃）
// 第1行:0-8, 第2行:9,17, 第3行:18,26, 第4行:27,35, 第5行:36,44, 第6行:45-53
const BORDER_SLOTS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 46, 47, 48, 50, 51, 52, 53];

// ============================================
// 【配置区域 3】商品配置 ★★★ 重点修改区域 ★★★
// ============================================
// 结构说明：
// - 外层键名必须对应 CATEGORIES 中的 id
// - 每个商品是一个对象，包含：
//   - id: Slimefun 物品ID（必须准确）
//   - lines: 显示在物品Lore底部的价格和购买信息
//     - 第1行: 购买提示
//     - 第2行: 价格说明（玩家看到）
//     - 第3行起: 实际扣除逻辑（§0数量×物品ID）
const ITEMS = {
    // 【分类1】树苗
    树苗: [
        {
            type: 'vanilla',
            id: 'OAK_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个小麦种子',
                '§08×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'SPRUCE_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'BIRCH_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'JUNGLE_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'ACACIA_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'DARK_OAK_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'CHERRY_SAPLING',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'MANGROVE_PROPAGULE',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'AZALEA',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'FLOWERING_AZALEA',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'CRIMSON_FUNGUS',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        },
        {
            type: 'vanilla',
            id: 'WARPED_FUNGUS',
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个橡树树苗',
                '§01×OAK_SAPLING'
            ]
        }
    ],

    // 【分类2】花
    花: [
        {
            type: 'vanilla',
            id: 'POPPY',  // 虞美人
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个泥土',
                '§01×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'DANDELION',  // 蒲公英
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'BLUE_ORCHID',  // 兰花
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'ALLIUM',  // 绒球葱
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'AZURE_BLUET',  // 蓝花美耳草
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'OXEYE_DAISY',  // 滨菊
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'CORNFLOWER',  // 矢车菊
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'RED_TULIP',  // 红色郁金香
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'ORANGE_TULIP',  // 橙色郁金香
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'WHITE_TULIP',  // 白色郁金香
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'PINK_TULIP',  // 粉色郁金香
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'LILY_OF_THE_VALLEY',  // 铃兰
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'SUNFLOWER',  // 向日葵
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'LILAC',  // 丁香
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'ROSE_BUSH',  // 玫瑰丛
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'PEONY',  // 牡丹
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'PITCHER_PLANT',  // 瓶子草
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个瓶子草夹果',
                '§01×PITCHER_POD'
            ]
        },
        {
            type: 'vanilla',
            id: 'TORCHFLOWER',  // 火把花
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个火把花种子',
                '§01×TORCHFLOWER_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'PINK_PETALS',  // 粉红色花簇
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'ALLIUM',  // 绒球葱
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'CHORUS_FLOWER',  // 紫颂花
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个紫颂果',
                '§08×CHORUS_FRUIT'
            ]
        },
        {
            type: 'vanilla',
            id: 'SPORE_BLOSSOM',  // 孢子花
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'WITHER_ROSE',  // 凋零玫瑰
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'BROWN_MUSHROOM',  // 棕色蘑菇
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        },
        {
            type: 'vanilla',
            id: 'RED_MUSHROOM',  // 红色蘑菇
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个虞美人',
                '§01×POPPY'
            ]
        }
    ],

    // 【分类3】矿物
    矿物: [
        {
            type: 'vanilla',
            id: 'COAL',  // 煤炭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个圆石',
                '§08×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'REDSTONE',  //红石粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个煤炭',
                '§08×COAL'
            ]
        },
        {
            type: 'vanilla',
            id: 'LAPIS_LAZULI',  // 青金石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个煤炭',
                '§08×COAL'
            ]
        },
        {
            type: 'vanilla',
            id: 'QUARTZ',  // 下界石英
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个灵魂沙',
                '§01×SOUL_SAND'
            ]
        },
        {
            type: 'vanilla',
            id: 'COPPER_INGOT',  // 铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个煤炭',
                '§04×COAL'
            ]
        },
        {
            type: 'vanilla',
            id: 'IRON_INGOT',  // 铁锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个煤炭',
                '§08×COAL'
            ]
        },
        {
            type: 'vanilla',
            id: 'GOLD_INGOT',  // 金锭 
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个铁锭',
                '§04×IRON_INGOT'
            ]
        },
        {
            type: 'vanilla',
            id: 'AMETHYST_SHARD',  // 紫水晶碎片
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个铁锭',
                '§08×IRON_INGOT'
            ]
        },
        {
            type: 'vanilla',
            id: 'DIAMOND',  // 钻石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个金锭',
                '§08×GOLD_INGOT'
            ]
        },
        {
            type: 'vanilla',
            id: 'EMERALD',  // 绿宝石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个钻石',
                '§08×DIAMOND'
            ]
        },
        {
            type: 'vanilla',
            id: 'NETHERITE_SCRAP',  // 下界合金碎片
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个绿宝石',
                '§016×EMERALD'
            ]
        },
        {
            type: 'vanilla',
            id: 'NETHERITE_INGOT',  //下界合金锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个下界合金碎片',
                '§04×NETHERITE_SCRAP'
            ]
        }
    ],
    // 【分类4】掉落物
    掉落物: [
        {
            type: 'vanilla',
            id: 'ROTTEN_FLESH',  // 腐肉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个泥土',
                '§01×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'STRING',  // 线
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个圆石',
                '§01×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'BONE',   // 骨头
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个石头',
                '§01×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'GUNPOWDER', //火药
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个沙子',
                '§01×SAND'
            ]
        },
        {
            type: 'vanilla',
            id: 'SPIDER_EYE',  // 蜘蛛眼
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个线',
                '§04×STRING'
            ]
        },
        {
            type: 'vanilla',
            id: 'LEATHER',  // 皮革
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个腐肉',
                '§04×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'FEATHER',  // 羽毛
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个腐肉',
                '§04×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'BEEF', // 生牛肉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'PORKCHOP',  // 生猪排
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'MUTTON',  // 生羊肉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'CHICKEN',  // 生鸡肉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'RABBIT',  // 生兔肉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'COD',  // 生鳕鱼
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'SALMON',  // 生鲑鱼
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'INK_SAC',  // 墨囊
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个腐肉',
                '§08×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'GLOW_INK_SAC',  // 荧光墨囊
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个墨囊',
                '§01×INK_SAC'
            ]
        },
        {
            type: 'vanilla',
            id: 'ENDER_PEARL',  // 末影珍珠
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个腐肉',
                '§016×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'BLAZE_ROD',  // 烈焰棒
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：32个腐肉',
                '§032×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'BREEZE_ROD',  // 旋风棒
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个烈焰棒',
                '§04×BLAZE_ROD'
            ]
        },
        {
            type: 'vanilla',
            id: 'RABBIT_HIDE',  // 兔子皮
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个生兔肉',
                '§02×RABBIT'
            ]
        },
        {
            type: 'vanilla',
            id: 'RABBIT_FOOT',  // 兔子脚
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个兔子皮',
                '§04×RABBIT_HIDE'
            ]
        },
        {
            type: 'vanilla',
            id: 'WITHER_SKELETON_SKULL',  // 凋零骷髅头颅
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：64个骨头',
                '§064×BONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'NETHER_STAR',  // 下界之星
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个灵魂沙 + 3个凋零骷髅头颅',
                '§04×SOUL_SAND',
                '§03×WITHER_SKELETON_SKULL'
            ]
        },
        {
            type: 'vanilla',
            id: 'SHULKER_SHELL',  // 潜影壳
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个末影珍珠',
                '§016×ENDER_PEARL'
            ]
        },
        {
            type: 'vanilla',
            id: 'HONEYCOMB',  //蜜牌
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个线',
                '§016×STRING'
            ]
        },
        {
            type: 'vanilla',
            id: 'PHANTOM_MEMBRANE',  // 幻翼膜
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个线',
                '§016×STRING'
            ]
        },
        {
            type: 'vanilla',
            id: 'GHAST_TEAR',  // 恶魂之泪
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个灵魂沙',
                '§04×SOUL_SAND'
            ]
        },
        {
            type: 'vanilla',
            id: 'SLIME_BALL',  // 粘液球
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个甘蔗',
                '§04×SUGAR_CANE'
            ]
        }
    ],
    // 【分类5】杂物/农作物
    杂物: [
        {
            type: 'vanilla',
            id: 'POTATO',  // 马铃薯
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：64个腐肉',
                '§064×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'CARROT',  //胡萝卜
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：64个腐肉',
                '§064×ROTTEN_FLESH'
            ]
        },
        {
            type: 'vanilla',
            id: 'APPLE',  // 苹果
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个橡树原木',
                '§04×OAK_LOG'
            ]
        },
        {
            type: 'vanilla',
            id: 'MELON_SLICE',  // 西瓜片
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个苹果',
                '§02×APPLE'
            ]
        },
        {
            type: 'vanilla',
            id: 'SWEET_BERRIES',  // 甜浆果
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'CHORUS_FRUIT',  // 紫颂果
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个末地石',
                '§08×END_STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'BAMBOO',  // 竹子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个甘蔗',
                '§04×SUGAR_CANE'
            ]
        },
        {
            type: 'vanilla',
            id: 'WHEAT_SEEDS',  // 小麦种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个泥土',
                '§01×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'PUMPKIN_SEEDS',  // 南瓜种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'MELON_SEEDS',  // 西瓜种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'BEETROOT_SEEDS',  // 甜菜种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'TORCHFLOWER_SEEDS',  // 火把花种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'PITCHER_POD',  // 瓶子草种子
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'NETHER_WART',  // 下界疣
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'WHEAT',  // 小麦
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个小麦种子',
                '§08×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'PUMPKIN',  // 南瓜
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个南瓜种子',
                '§08×PUMPKIN_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'MELON',  // 西瓜
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个西瓜种子',
                '§08×MELON_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'BEETROOT',  // 甜菜根
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个甜菜种子',
                '§08×BEETROOT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'LILY_PAD',  // 睡莲
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个泥土',
                '§01×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'SUGAR_CANE',  // 甘蔗
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个泥土',
                '§01×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'POISONOUS_POTATO',  // 毒马铃薯
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个马铃薯',
                '§08×POTATO'
            ]
        },
        {
            type: 'vanilla',
            id: 'CACTUS',  // 仙人掌
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个沙子',
                '§04×SAND'
            ]
        },
        {
            type: 'vanilla',
            id: 'POINTED_DRIPSTONE',  // 滴水石锥
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个石头',
                '§016×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'COCOA_BEANS',  // 可可豆
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个小麦种子',
                '§01×WHEAT_SEEDS'
            ]
        },
        {
            type: 'vanilla',
            id: 'TURTLE_SCUTE',  // 海龟鳞甲
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个甘蔗',
                '§08×SUGAR_CANE'
            ]
        },
        {
            type: 'vanilla',
            id: 'NAME_TAG',  // 命名牌
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个纸',
                '§08×PAPER'
            ]
        },
        {
            type: 'vanilla',
            id: 'LAVA_BUCKET',  // 岩浆桶
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个黑曜石 + 1个桶',
                '§01×OBSIDIAN',
                '§01×BUCKET'
            ]
        },
        {
            type: 'vanilla',
            id: 'WATER_BUCKET',  // 水桶
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个桶',
                '§01×BUCKET'
            ]
        }
    ],
    // 【分类6】方块
    方块: [
        {
            type: 'vanilla',
            id: 'STONE',  // 石头
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个圆石',
                '§01×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'GRASS_BLOCK',  // 草方块
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个泥土',
                '§08×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'PODZOL',  // 灰化土
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个泥土',
                '§08×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'MYCELIUM',  // 菌丝体
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个泥土',
                '§08×DIRT'
            ]
        },
        {
            type: 'vanilla',
            id: 'GRAVEL',  // 沙砾
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个圆石',
                '§02×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'COBBLED_DEEPSLATE',  // 深板岩圆石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个圆石',
                '§01×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'ICE',  // 冰
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个水桶',
                '§01×WATER_BUCKET'
            ]
        },
        {
            type: 'vanilla',
            id: 'CALCITE',  // 方解石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：32个圆石',
                '§032×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'TUFF',  // 凝灰岩
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：32个圆石',
                '§032×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'OBSIDIAN',  // 黑曜石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：64个圆石',
                '§064×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'CRYING_OBSIDIAN',  // 哭泣的黑曜石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个黑曜石',
                '§01×OBSIDIAN'
            ]
        },
        {
            type: 'vanilla',
            id: 'CRIMSON_NYLIUM',  // 绯红菌岩
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个下界岩',
                '§016×NETHERRACK'
            ]
        },
        {
            type: 'vanilla',
            id: 'WARPED_NYLIUM',  // 诡异菌岩
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个下界岩',
                '§016×NETHERRACK'
            ]
        },
        {
            type: 'vanilla',
            id: 'SOUL_SAND',  // 灵魂沙
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个沙子',
                '§02×SAND'
            ]
        },
        {
            type: 'vanilla',
            id: 'BLACKSTONE',  // 黑石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个石头',
                '§04×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'BASALT',  // 玄武岩
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个石头',
                '§04×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'END_STONE',  // 末地石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个石头',
                '§04×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'GLOWSTONE',  // 荧石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个石头',
                '§04×STONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'SEA_LANTERN',  // 海晶灯
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个圆石',
                '§08×COBBLESTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'BUDDING_AMETHYST',  // 紫水晶母岩
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个紫水晶碎片',
                '§08×AMETHYST_SHARD'
            ]
        },
        {
            type: 'vanilla',
            id: 'SHROOMLIGHT',  // 菌光体
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个下界岩',
                '§016×NETHERRACK'
            ]
        },
        {
            type: 'vanilla',
            id: 'COAL_ORE',  // 煤炭矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个煤炭',
                '§08×COAL'
            ]
        },
        {
            type: 'vanilla',
            id: 'LAPIS_ORE',  // 青金石矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个青金石',
                '§08×LAPIS_LAZULI'
            ]
        },
        {
            type: 'vanilla',
            id: 'REDSTONE_ORE',  // 红石矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个红石粉',
                '§08×REDSTONE'
            ]
        },
        {
            type: 'vanilla',
            id: 'IRON_ORE',  // 铁矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个铁锭',
                '§08×IRON_INGOT'
            ]
        },
        {
            type: 'vanilla',
            id: 'GOLD_ORE',  // 金矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个金锭',
                '§08×GOLD_INGOT'
            ]
        },
        {
            type: 'vanilla',
            id: 'DIAMOND_ORE',  // 钻石矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个钻石',
                '§08×DIAMOND'
            ]
        },
        {
            type: 'vanilla',
            id: 'EMERALD_ORE',  // 绿宝石矿石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个绿宝石',
                '§08×EMERALD'
            ]
        }
    ],
    // 【分类7】粘液科技
    粘液科技: [
        {
            type: 'slimefun',
            id: 'SIFTED_ORE',  // 筛矿
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个沙砾',
                '§04×GRAVEL'
            ]
        },
        {
            type: 'slimefun',
            id: 'STONE_CHUNK',  // 石块
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个石头',
                '§01×STONE'
            ]
        },
        {
            type: 'slimefun',
            id: 'COMPRESSED_CARBON',  // 压缩碳
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个钻石',
                '§01×DIAMOND'
            ]
        },
        {
            type: 'slimefun',
            id: 'SILICON',  // 硅
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个下界石英',
                '§04×NETHER_QUARTZ'
            ]
        },
        {
            type: 'slimefun',
            id: 'COPPER_DUST',  // 铜粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'IRON_DUST',  // 铁粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'GOLD_DUST',  // 金粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'ALUMINUM_DUST',  // 铝粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'SILVER_DUST',  // 银粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'TIN_DUST',  // 锡粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'LEAD_DUST',  // 铅粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'ZINC_DUST',  // 锌粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'MAGNESIUM_DUST',  // 镁粉
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个筛矿',
                '§01×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'SULFATE',  // 硫酸盐
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：1个岩浆块',
                '§01×MAGMA_BLOCK'
            ]
        },
        {
            type: 'slimefun',
            id: 'ELECTRO_MAGNET',  // 电磁铁
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：11个铁粉 + 8个铜粉 + 1个铝粉',
                '§a售价：2个锌粉 + 2个硫酸盐 + 1个红石粉',
                '§011×IRON_DUST',
                '§08×COPPER_DUST',
                '§01×ALUMINUM_DUST',
                '§02×ZINC_DUST',
                '§02×SULFATE',
                '§01×REDSTONE'
            ]
        },
        {
            type: 'slimefun',
            id: 'ELECTRIC_MOTOR',  // 电动马达
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：11个铁粉 + 11个铜粉 + 1个铝粉',
                '§a售价：2个锌粉 + 2个硫酸盐 + 1个红石粉',
                '§011×IRON_DUST',
                '§011×COPPER_DUST',
                '§01×ALUMINUM_DUST',
                '§02×ZINC_DUST',
                '§02×SULFATE',
                '§01×REDSTONE'
            ]
        },
        {
            type: 'slimefun',
            id: 'HEATING_COIL',  // 加热线圈
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：11个铁粉 + 14个铜粉 + 1个铝粉',
                '§a售价：2个锌粉 + 2个硫酸盐 + 1个红石粉',
                '§011×IRON_DUST',
                '§08×COPPER_DUST',
                '§01×ALUMINUM_DUST',
                '§02×ZINC_DUST',
                '§02×SULFATE',
                '§01×REDSTONE'
            ]
        },
        {
            type: 'slimefun',
            id: 'BASIC_CIRCUIT_BOARD',  // 基础电路板
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：36个铁锭 + 8个泥土',
                '§036×IRON_INGOT',
                '§08×DIRT'
            ]
        },
        {
            type: 'slimefun',
            id: 'MAGIC_LUMP_3',  // 魔法结晶3
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个下界疣',
                '§08×NETHER_WART'
            ]
        },
        {
            type: 'slimefun',
            id: 'ENDER_LUMP_3',  // 末影结晶3
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个末影之眼',
                '§08×ENDER_EYE'
            ]
        },
        {
            type: 'slimefun',
            id: 'LENGSHANG_MTXJ',  // 莓糖星酱
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个强化合金锭 + 8个电磁铁',
                '§08×REINFORCED_ALLOY_INGOT',
                '§08×ELECTRO_MAGNET'
            ]
        }
    ],
    // 【分类8】合成锭
    合成锭: [
        {
            type: 'slimefun',
            id: 'STEEL_INGOT',  // 钢锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个煤炭 + 2个铁粉',
                '§08×COAL',
                '§02×IRON_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'DAMASCUS_STEEL_INGOT',  // 大马士革钢锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个煤炭 + 4个铁粉',
                '§016×COAL',
                '§04×IRON_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'BRONZE_INGOT',  // 青铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铜粉 + 1个锡粉',
                '§02×COPPER_DUST',
                '§01×TIN_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'BRASS_INGOT',  // 黄铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铜粉 + 1个锌粉',
                '§02×COPPER_DUST',
                '§01×ZINC_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'DURALUMIN_INGOT',  // 硬铝锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铝粉 + 1个铜粉',
                '§02×ALUMINUM_DUST',
                '§01×COPPER_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'BILLON_INGOT',  // 银铜合金锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个银粉 + 1个铜粉',
                '§02×SILVER_DUST',
                '§01×COPPER_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'SOLDER_INGOT',  // 焊锡锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铅粉 + 1个锡粉',
                '§02×LEAD_DUST',
                '§01×TIN_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'NICKEL_INGOT',  // 镍锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铁粉 + 1个铜粉',
                '§02×IRON_DUST',
                '§01×COPPER_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'COBALT_INGOT',  // 钴锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：3个铁粉 + 2个铜粉',
                '§03×IRON_DUST',
                '§02×COPPER_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'FERROSILICON',  // 硅铁
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铁粉 + 4个下界石英',
                '§02×IRON_DUST',
                '§04×QUARTZ'
            ]
        },
        {
            type: 'slimefun',
            id: 'ALUMINUM_BRASS_INGOT',  // 铝黄铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铝粉 + 2个铜粉 + 1个锌粉',
                '§02×ALUMINUM_DUST',
                '§02×COPPER_DUST',
                '§01×ZINC_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'ALUMINUM_BRONZE_INGOT',  // 铝青铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铝粉 + 2个铜粉 + 1个锡粉',
                '§02×ALUMINUM_DUST',
                '§02×COPPER_DUST',
                '§01×TIN_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'CORINTHIAN_BRONZE_INGOT',  // 科林斯青铜锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：3个铜粉 + 1个锡粉 + 1个金粉 + 1个银粉',
                '§03×COPPER_DUST',
                '§01×TIN_DUST',
                '§01×GOLD_DUST',
                '§01×SILVER_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'GOLD_24K',  // 24克拉金锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：11个金粉',
                '§011×GOLD_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'GILDED_IRON',  // 镀金铁锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：11个金粉 + 1个铁粉',
                '§011×GOLD_DUST',
                '§01×IRON_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'MAGSTEEL',  // 磁钢
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个镁粉 + 2个铁粉 + 8个煤炭',
                '§02×MAGNESIUM_DUST',
                '§02×IRON_DUST',
                '§08×COAL'
            ]
        },
        {
            type: 'slimefun',
            id: 'HARDENED_METAL_INGOT',  // 硬化金属
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个铁粉 + 4个铝粉 + 3个铜粉 + 1个锡粉',
                '§a售价：+ 48个煤炭',
                '§048×COAL',
                '§04×IRON_DUST',
                '§04×ALUMINUM_DUST',
                '§03×COPPER_DUST',
                '§01×TIN_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'REDSTONE_ALLOY',  // 红石合金锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：6个铁粉 + 4个铝粉 + 3个铜粉 + 1个锡粉',
                '§a售价：+ 48个煤炭 + 10个红石粉 + 4个下界石英',
                '§048×COAL',
                '§04×IRON_DUST',
                '§04×ALUMINUM_DUST',
                '§03×COPPER_DUST',
                '§01×TIN_DUST',
                '§010×REDSTONE_DUST',
                '§04×QUARTZ'
            ]
        },
        {
            type: 'slimefun',
            id: 'REINFORCED_ALLOY_INGOT',  // 强化合金锭
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：64个煤炭 + 12个金粉 + 8个铁粉 + 7个铜粉',
                '§a售价：+ 4个铝粉 + 3个银粉 + 3个锡粉 + 2个铅粉',
                '§064×COAL',
                '§012×GOLD_DUST',
                '§08×IRON_DUST',
                '§07×COPPER_DUST',
                '§04×ALUMINUM_DUST',
                '§03×SILVER_DUST',
                '§03×TIN_DUST',
                '§02×LEAD_DUST'
            ]
        },
        {
            type: 'slimefun',
            id: 'URANIUM',  // 铀
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：36个筛矿',
                '§036×SIFTED_ORE'
            ]
        },
        {
            type: 'slimefun',
            id: 'SYNTHETIC_SAPPHIRE',  // 人造蓝宝石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：2个铝粉 + 2个玻璃 + 1个青金石',
                '§02×ALUMINUM_DUST',
                '§02×GLASS',
                '§01×LAPIS_LAZULI'
            ]
        },
        {
            type: 'slimefun',
            id: 'SYNTHETIC_EMERALD',  // 人造绿宝石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：4个铝粉 + 3个玻璃 + 1个青金石',
                '§04×ALUMINUM_DUST',
                '§03×GLASS',
                '§01×LAPIS_LAZULI'
            ]
        },
        {
            type: 'slimefun',
            id: 'SYNTHETIC_DIAMOND',  // 人造钻石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：8个钻石',
                '§08×DIAMOND'
            ]
        },
        {
            type: 'slimefun',
            id: 'CARBONADO',  // 黑金刚石
            lines: [
                '§f------§a§l点击购买§f------',
                '§a售价：16个钻石 + 1个玻璃',
                '§08×DIAMOND',
                '§01×GLASS'
            ]
        }
    ]
};

// ============================================
// 以下为核心逻辑代码，一般不需要修改
// ============================================

// 导入Bukkit/Slimefun相关类
const Bukkit = Java.type('org.bukkit.Bukkit');
const Material = Java.type('org.bukkit.Material');
const ItemStack = Java.type('org.bukkit.inventory.ItemStack');
const ClickEvent = Java.type('org.bukkit.event.inventory.InventoryClickEvent');
const CloseEvent = Java.type('org.bukkit.event.inventory.InventoryCloseEvent');
const EventPriority = Java.type('org.bukkit.event.EventPriority');
const plugin = Java.type('org.lins.mmmjjkx.rykenslimefuncustomizer.RykenSlimefunCustomizer').INSTANCE;
const SlimefunItem = Java.type('io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem');
const Listener = Java.type('org.bukkit.event.Listener');

/**
 * 创建基础物品
 * @param {string} mat - 材质名称
 * @param {string} name - 显示名称（支持颜色代码）
 * @param {string|string[]} lore - 描述文本（可选）
 * @returns {ItemStack} Bukkit物品对象
 */
function item(mat, name, lore) {
    const it = new ItemStack(Material.getMaterial(mat));
    const meta = it.getItemMeta();
    meta.setDisplayName(name);
    if (lore) meta.setLore(Array.isArray(lore) ? lore : [lore]);
    it.setItemMeta(meta);
    return it;
}

/** 创建边框玻璃（粉红色染色玻璃板） */
function borderItem() { return item('PINK_STAINED_GLASS_PANE', '§6 '); }

/** 应用边框到指定库存 */
function applyBorder(inv) {
    const b = borderItem();
    BORDER_SLOTS.forEach(s => inv.setItem(s, b.clone()));
}

/**
 * 解析物品Lore中的价格信息
 * 识别格式：§0数量×物品ID
 * @param {List} lore - 物品的Lore列表
 * @returns {Array} 价格对象数组 [{id: '物品ID', amount: 数量}, ...]
 */
function parsePrices(lore) {
    const prices = [];
    for (let i = 0; i < lore.size(); i++) {
        const line = lore.get(i);
        // 匹配 §0-数字×物品ID 格式
        if (line.startsWith('§0') && line.includes('×')) {
            const p = line.split('×');
            if (p.length === 2) {
                const amt = parseInt(p[0].substring(2));  // 去掉 '§0'
                const id = p[1].trim();
                if (!isNaN(amt) && amt > 0 && id) prices.push({ id, amount: amt });
            }
        }
    }
    return prices;
}

/**
 * 检查玩家是否拥有足够的支付物品（支持原版 + Slimefun）
 * @param {Player} player - 玩家对象
 * @param {Array} priceList - 价格列表 [{id, amount}, ...]
 * @returns {boolean} 是否足够
 */
function hasEnough(player, priceList) {
    const inventory = player.getInventory();
    for (let price of priceList) {
        let total = 0;
        const targetMat = Material.getMaterial(price.id);

        for (let i = 0; i < inventory.getSize(); i++) {
            const stack = inventory.getItem(i);
            if (!stack || stack.getType() === Material.AIR) continue;

            // 先尝试匹配 Slimefun 物品
            const sf = SlimefunItem.getByItem(stack);
            if (sf && sf.getId() === price.id) {
                total += stack.getAmount();
            }
            // 再尝试匹配原版物品（材质名）
            else if (targetMat && stack.getType() === targetMat) {
                total += stack.getAmount();
            }
        }
        if (total < price.amount) return false;
    }
    return true;
}

/**
 * 从玩家背包扣除指定物品（支持原版 + Slimefun）
 * @param {Player} player - 玩家对象
 * @param {Array} priceList - 价格列表
 */
function removeItems(player, priceList) {
    for (let price of priceList) {
        let remain = price.amount;
        const inv = player.getInventory();
        const targetMat = Material.getMaterial(price.id);

        for (let i = 0; i < inv.getSize() && remain > 0; i++) {
            const stack = inv.getItem(i);
            if (!stack || stack.getType() === Material.AIR) continue;

            let match = false;

            // 先尝试匹配 Slimefun 物品
            const sf = SlimefunItem.getByItem(stack);
            if (sf && sf.getId() === price.id) {
                match = true;
            }
            // 再尝试匹配原版物品
            else if (targetMat && stack.getType() === targetMat) {
                match = true;
            }

            if (!match) continue;

            const amt = stack.getAmount();
            if (amt <= remain) {
                inv.setItem(i, null);
                remain -= amt;
            } else {
                stack.setAmount(amt - remain);
                remain = 0;
            }
        }
    }
}

/** 构建主菜单界面 */
function buildMain() {
    const inv = Bukkit.createInventory(null, 54, MAIN_TITLE);  // 6行箱子
    applyBorder(inv);
    // 放置分类图标
    CATEGORIES.forEach(c => inv.setItem(c.slot, item(c.icon, c.name, [c.lore, '', '§a点击查看'])));
    inv.setItem(4, item(INFO_ITEM.material, INFO_ITEM.name, INFO_ITEM.lore));  // 顶部信息
    inv.setItem(49, item('BARRIER', '§c关闭', '§7关闭菜单'));  // 底部关闭按钮
    return inv;
}

/**
 * 构建分类子菜单
 * @param {string} cid - 分类ID
 * @returns {Inventory|null} 子菜单界面
 */
function catMenu(cid) {
    const cat = CATEGORIES.find(c => c.id === cid);
    if (!cat) return null;
    const list = ITEMS[cid];
    if (!list || !list.length) return null;

    const inv = Bukkit.createInventory(null, 54, SUB_PRE + cat.name + SUB_SUF);
    applyBorder(inv);
    inv.setItem(4, item('PAPER', '§6' + cat.name + '说明', ['§7点击物品购买', '§e共' + list.length + '种']));

    // 填充商品（从槽位10开始，跳过边框）
    let slot = 10;
    list.forEach(e => {
        if (slot > 43) return;  // 超出有效区域

        // ★★★ 新增：如果当前槽位是边框，跳到下一行有效位置
        if (BORDER_SLOTS.includes(slot)) {
            // 找到当前行的下一个非边框槽位
            const currentRow = Math.floor(slot / 9);
            slot = currentRow * 9 + 10; // 跳到下一行第2列（10,19,28,37）
            if (slot > 43) return;
        }
        let displayItem = null;

        // ★★★ 根据类型创建不同的展示物品 ★★★
        if (e.type === 'vanilla') {
            // 原版物品：直接用 Material 创建
            const mat = Material.getMaterial(e.id);
            if (mat) {
                displayItem = new ItemStack(mat, e.amount || 1);
                const meta = displayItem.getItemMeta();
                // 追加价格Lore
                let lore = meta.getLore() || [];
                e.lines.forEach(l => lore.push(l));
                meta.setLore(lore);
                displayItem.setItemMeta(meta);
            }
        } else {
            // Slimefun 物品：原有逻辑
            const sf = SlimefunItem.getById(e.id);
            if (sf) {
                // 获取Slimefun物品并添加价格Lore
                displayItem = sf.getItem().clone();
                const meta = displayItem.getItemMeta();
                let lore = meta.getLore() || [];
                if (!Array.isArray(lore)) lore = [lore];
                e.lines.forEach(l => lore.push(l));
                meta.setLore(lore);
                displayItem.setItemMeta(meta);
            }
        }
        if (displayItem) {
            inv.setItem(slot, displayItem);
        } else {
            inv.setItem(slot, item('BARRIER', '§c无效物品', ['§7ID: ' + e.id]));
        }
        slot++;
        // 跳过边框列（每行第1列和第9列）
        if ((slot - 9) % 9 === 0) slot += 2;
    });

    inv.setItem(49, item('ARROW', '§a返回', '§7返回主菜单'));
    return inv;
}

// 记录当前打开菜单的玩家集合（用于监听管理）
const openPlayers = new java.util.HashSet();
let registered = false;  // 监听器是否已注册

/** 确保事件监听器已注册（防止重复注册） */
function ensureListener() {
    if (registered) return;
    // 清理旧监听器（热重载时）
    if (plugin.komutech_gj_qhgui) {
        ClickEvent.getHandlerList().unregister(plugin.komutech_gj_qhgui);
        CloseEvent.getHandlerList().unregister(plugin.komutech_gj_qhgui);
        plugin.komutech_gj_qhgui = null;
    }

    const L = Java.extend(Listener, {});
    const listener = new L();

    // 注册点击事件监听
    Bukkit.getPluginManager().registerEvent(ClickEvent, listener, EventPriority.NORMAL, (l, e) => {
        try {
            const p = e.getWhoClicked();
            if (!openPlayers.contains(p)) return;  // 只处理打开本菜单的玩家

            const t = e.getInventory().getTitle();
            if (t !== MAIN_TITLE && !t.startsWith(SUB_PRE)) return;  // 只处理本插件的菜单

            e.setCancelled(true);  // 防止物品被拿走
            const inv = e.getInventory();
            const slot = e.getSlot();
            const it = e.getCurrentItem();
            if (!it || it.getType() === Material.AIR) return;

            // ===== 主菜单逻辑 =====
            if (t === MAIN_TITLE) {
                // 点击分类
                const cat = CATEGORIES.find(c => c.slot === slot && it.getItemMeta().getDisplayName() === c.name);
                if (cat) {
                    const sub = catMenu(cat.id);
                    if (sub) openMenu(p, sub);
                    return;
                }
                // 点击关闭
                if (slot === 49 && it.getItemMeta().getDisplayName() === '§c关闭') {
                    p.closeInventory();
                    return;
                }
            }
            // ===== 子菜单逻辑 =====
            else {
                // 点击说明或边框不处理
                if (slot === 4 || BORDER_SLOTS.includes(slot)) return;
                // 点击返回
                if (slot === 49 && it.getItemMeta().getDisplayName() === '§a返回') {
                    openMain(p);
                    return;
                }
                // 获取该槽位对应的配置项
                const cat = CATEGORIES.find(c => t.startsWith(SUB_PRE + c.name));
                if (!cat) return;
                const list = ITEMS[cat.id];
                // 计算槽位对应的索引（考虑边框跳过）
                let itemIndex = 0;
                let currentSlot = 10;
                for (let i = 0; i < list.length; i++) {
                    // 跳过边框槽位（与 catMenu 一致）
                    if (BORDER_SLOTS.includes(currentSlot)) {
                        const currentRow = Math.floor(currentSlot / 9);
                        currentSlot = currentRow * 9 + 10;
                    }

                    if (currentSlot === slot) {
                        itemIndex = i;
                        break;
                    }
                    currentSlot++;
                    if ((currentSlot - 9) % 9 === 0) currentSlot += 2;
                }
                const config = list[itemIndex];
                if (!config) return;
                // 解析价格
                const prices = parsePrices(it.getItemMeta().getLore());
                if (!prices.length) {
                    p.sendMessage('§c价格信息错误');
                    return;
                }

                // 检查并扣除货币
                if (!hasEnough(p, prices)) {
                    p.sendMessage('§c材料不足，无法购买');
                    return;
                }
                // 执行交易
                removeItems(p, prices);
                // ★★★ 根据类型发放物品 ★★★
                if (config.type === 'vanilla') {
                    // 发放原版物品
                    const mat = Material.getMaterial(config.id);
                    if (mat) {
                        const giveItem = new ItemStack(mat, config.amount || 1);
                        p.getInventory().addItem(giveItem);
                        p.sendMessage('§a购买成功！');
                    } else {
                        p.sendMessage('§c物品发放失败');
                    }
                } else {
                    // 发放 Slimefun 物品
                    const target = SlimefunItem.getById(config.id);
                    if (target) {
                        p.getInventory().addItem(target.getItem().clone());
                        p.sendMessage('§a购买成功！');
                    } else {
                        p.sendMessage('§c物品获取失败');
                    }
                }
            }
        } catch (err) { }
    }, plugin);

    // 注册关闭事件监听（清理玩家记录）
    Bukkit.getPluginManager().registerEvent(CloseEvent, listener, EventPriority.NORMAL, (l, e) => {
        try {
            const p = e.getPlayer();
            openPlayers.remove(p);
            // 无人使用时注销监听器节省资源
            if (openPlayers.isEmpty()) {
                ClickEvent.getHandlerList().unregister(listener);
                CloseEvent.getHandlerList().unregister(listener);
                plugin.komutech_gj_qhgui = null;
                registered = false;
            }
        } catch (err) { }
    }, plugin);

    plugin.komutech_gj_qhgui = listener;
    registered = true;
}

/** 打开指定菜单并记录玩家 */
function openMenu(p, inv) {
    p.openInventory(inv);
    openPlayers.add(p);
    ensureListener();
}

/** 打开主菜单 */
function openMain(p) { openMenu(p, buildMain()); }

// ============================================
// RSC 脚本入口函数
// ============================================

/** 按钮组点击回调（机器界面中的按钮） */
function onButtonGroupClick(player, slot, clickedItem, clickAction, guideMode) {
    try {
        openMain(player);
        return true;
    } catch (err) {
        player.sendMessage('§c无法打开商店菜单');
        return false;
    }
}

/** 物品使用回调（右键点击物品打开菜单） */
function onUse(e) {
    const p = e.getPlayer();
    try {
        openMain(p);
    } catch (err) {
        p.sendMessage('§c无法打开商店菜单');
    }
    return false;
}