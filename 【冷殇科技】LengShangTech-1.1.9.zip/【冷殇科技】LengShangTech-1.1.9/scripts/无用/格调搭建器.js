/**
 * 一键建筑投影工具 - 十字柱形结构版
 * 结构：中心 + 上×2 + 左 + 右（共5格？）或 中心 + 上×2 + 左 + 右（4格不含中心？）
 * 
 * 从图二分析：中心柱高3格，左右各延伸1格在同一层
 * 实际结构：
 *   [上2]
 *   [上1]
 * [左]   [右]
 */

// ==================== Bukkit API 类导入 ====================
var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var BlockFace = Java.type("org.bukkit.block.BlockFace");
var Particle = Java.type("org.bukkit.Particle");
var Bukkit = Java.type("org.bukkit.Bukkit");

// ==================== 配置区域 ====================
var MAX_PLACE_DISTANCE = 6;

// 结构定义：相对于中心点的偏移 [dx, dy, dz]
// 十字柱形：中心 + 上×2 + 左 + 右
var STRUCTURE_OFFSETS = [
    [0, 1, 0],    // 上1
    [0, 2, 0],    // 上2
    [-1, 0, 0],   // 左
    [1, 0, 0]     // 右
];

// 存储每个玩家的投影状态
var previewMap = new java.util.HashMap();

// ==================== 核心函数 ====================

function getOffhandItem(player) {
    return player.getInventory().getItemInOffHand();
}

function isPlaceableBlock(item) {
    if (!item || item.getType().isAir()) return false;
    var material = item.getType();
    return material.isBlock() && material !== Material.AIR;
}

/**
 * 获取玩家视线指向的基准位置（中心点）
 */
function getTargetBaseLocation(player) {
    var eyeLoc = player.getEyeLocation();
    var direction = eyeLoc.getDirection();
    var world = player.getWorld();
    
    for (var i = 1; i <= MAX_PLACE_DISTANCE * 5; i++) {
        var checkLoc = eyeLoc.clone().add(direction.clone().multiply(i / 5.0));
        var block = world.getBlockAt(checkLoc);
        
        if (!block.getType().isAir()) {
            // 找到碰撞方块，返回其前方位置
            var blockCenter = block.getLocation().add(0.5, 0.5, 0.5);
            var diff = checkLoc.clone().subtract(blockCenter);
            
            var face = BlockFace.UP;
            var absX = Math.abs(diff.getX());
            var absY = Math.abs(diff.getY());
            var absZ = Math.abs(diff.getZ());
            
            if (absX > absY && absX > absZ) {
                face = diff.getX() > 0 ? BlockFace.EAST : BlockFace.WEST;
            } else if (absZ > absX && absZ > absY) {
                face = diff.getZ() > 0 ? BlockFace.SOUTH : BlockFace.NORTH;
            } else {
                face = diff.getY() > 0 ? BlockFace.UP : BlockFace.DOWN;
            }
            
            return block.getRelative(face).getLocation();
        }
    }
    
    // 无碰撞，最大距离处
    var finalLoc = eyeLoc.clone().add(direction.clone().multiply(MAX_PLACE_DISTANCE));
    return world.getBlockAt(finalLoc).getLocation();
}

/**
 * 根据基准位置和偏移计算结构所有位置
 */
function getStructureLocations(baseLoc) {
    var locations = [];
    for (var i = 0; i < STRUCTURE_OFFSETS.length; i++) {
        var offset = STRUCTURE_OFFSETS[i];
        var loc = baseLoc.clone().add(offset[0], offset[1], offset[2]);
        locations.push(loc);
    }
    return locations;
}

/**
 * 发送结构投影
 */
function sendStructurePreview(player, locations, material) {
    try {
        var blockData = material.createBlockData();
        for (var i = 0; i < locations.length; i++) {
            player.sendBlockChange(locations[i], blockData);
            // 每个位置显示粒子
            var centerLoc = locations[i].clone().add(0.5, 0.5, 0.5);
            player.spawnParticle(Particle.HAPPY_VILLAGER, centerLoc, 2, 0.2, 0.2, 0.2, 0);
        }
        return true;
    } catch (e) {
        print("[投影工具] Preview error: " + e);
        return false;
    }
}

/**
 * 清除结构投影
 */
function clearStructurePreview(player, locations) {
    var world = player.getWorld();
    for (var i = 0; i < locations.length; i++) {
        var realBlock = world.getBlockAt(locations[i]);
        player.sendBlockChange(locations[i], realBlock.getBlockData());
    }
}

/**
 * 清除玩家所有投影
 */
function clearPlayerPreview(player) {
    var uuid = player.getUniqueId().toString();
    var preview = previewMap.get(uuid);
    if (preview && preview.locations) {
        clearStructurePreview(player, preview.locations);
        previewMap.remove(uuid);
    }
}

/**
 * 检查结构是否可以放置（所有位置都是空气）
 */
function canPlaceStructure(player, locations) {
    var world = player.getWorld();
    for (var i = 0; i < locations.length; i++) {
        var block = world.getBlockAt(locations[i]);
        if (!block.getType().isAir()) {
            player.sendMessage("§c位置 " + i + " 已有方块阻挡！");
            return false;
        }
    }
    return true;
}

/**
 * 确认放置结构
 */
function confirmPlaceStructure(player, locations, material) {
    try {
        // 检查空间
        if (!canPlaceStructure(player, locations)) {
            return false;
        }
        
        // 检查物品数量
        var offhand = getOffhandItem(player);
        if (!offhand || offhand.getType() !== material) {
            player.sendMessage("§c副手物品已变更！");
            return false;
        }
        
        var needAmount = locations.length;
        if (offhand.getAmount() < needAmount) {
            player.sendMessage("§c副手方块不足！需要 " + needAmount + " 个，只有 " + offhand.getAmount() + " 个");
            return false;
        }
        
        // 消耗物品
        if (offhand.getAmount() > needAmount) {
            offhand.setAmount(offhand.getAmount() - needAmount);
        } else {
            player.getInventory().setItemInOffHand(null);
        }
        
        // 放置所有方块
        var world = player.getWorld();
        for (var i = 0; i < locations.length; i++) {
            var block = world.getBlockAt(locations[i]);
            block.setType(material, false);
        }
        
        // 播放效果
        try {
            var center = locations[0].clone().add(0.5, 1, 0.5);
            player.getWorld().playSound(center, "block.stone.place", 1.0, 0.8);
        } catch (soundErr) {}
        
        return true;
    } catch (e) {
        print("[投影工具] Place error: " + e);
        return false;
    }
}

// ==================== RSC 事件入口 ====================

function onUse(event) {
    var player = event.getPlayer();
    var item = event.getItem();
    
    // 检查副手
    var offhandItem = getOffhandItem(player);
    if (!isPlaceableBlock(offhandItem)) {
        player.sendMessage("§c副手必须持有可放置的方块！");
        player.sendActionBar("§7副手: §c无有效方块");
        return;
    }
    
    var material = offhandItem.getType();
    var uuid = player.getUniqueId().toString();
    
    // 获取基准位置
    var baseLoc = getTargetBaseLocation(player);
    
    // 计算结构所有位置
    var locations = getStructureLocations(baseLoc);
    
    // 获取当前投影状态
    var currentPreview = previewMap.get(uuid);
    
    // 如果已有投影且基准位置相同，确认放置
    if (currentPreview && currentPreview.baseLoc) {
        var prevBase = currentPreview.baseLoc;
        if (prevBase.getBlockX() === baseLoc.getBlockX() && 
            prevBase.getBlockY() === baseLoc.getBlockY() && 
            prevBase.getBlockZ() === baseLoc.getBlockZ()) {
            
            if (confirmPlaceStructure(player, locations, material)) {
                player.sendMessage("§a结构已放置！共 " + locations.length + " 个方块");
                player.sendActionBar("§a已放置 " + material.name() + " ×" + locations.length);
                clearPlayerPreview(player);
            }
            return;
        } else {
            // 位置变更，清除旧投影
            clearPlayerPreview(player);
        }
    }
    
    // 检查新位置是否可以放置
    if (!canPlaceStructure(player, locations)) {
        player.sendMessage("§c目标区域有方块阻挡，无法建立投影！");
        return;
    }
    
    // 建立新投影
    if (sendStructurePreview(player, locations, material)) {
        previewMap.put(uuid, {
            baseLoc: baseLoc,
            locations: locations,
            material: material
        });
        
        player.sendMessage("§6投影已建立！再次右键确认放置");
        player.sendMessage("§7结构: §f十字柱形 §7(§e" + locations.length + "§7个方块)");
        player.sendActionBar("§7方块: §f" + material.name() + " §7| §e右键确认放置");
    }
}

function onQuit(player) {
    clearPlayerPreview(player);
}

function onOpen(player) {
    clearPlayerPreview(player);
}

function onClose(player) {
    clearPlayerPreview(player);
}