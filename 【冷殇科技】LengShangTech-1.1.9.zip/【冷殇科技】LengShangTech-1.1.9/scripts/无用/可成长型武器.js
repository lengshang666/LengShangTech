// ========== 引入Java类 ==========
let Bukkit = Java.type('org.bukkit.Bukkit');

// ========== 品质等级配置 ==========
const QUALITY_LEVELS = [
    { min: 1,  max: 9,  name: "§7普通",    color: "§7" },
    { min: 10, max: 20, name: "§a良好",    color: "§a" },
    { min: 21, max: 30, name: "§d史诗",    color: "§d" },
    { min: 31, max: 50, name: "§6传说",    color: "§6" },
    { min: 51, max: 99, name: "§c神话",    color: "§c" },
    { min: 100, max: Infinity, name: "§b§l神级", color: "§b" }
];

const KILL_PREFIX = "§e击杀计数: §c";
const QUALITY_PREFIX = "§7品质等级: ";

function onWeaponHit(event, player) {
    let finalDamage = event.getFinalDamage();
    let target = event.getEntity();

    // 击杀判定与计数
    if (target instanceof Java.type('org.bukkit.entity.LivingEntity')) {
        let targetHealth = target.getHealth();
        
        // 如果这次攻击会导致目标死亡
        if (targetHealth <= finalDamage && !target.isDead()) {
            let item = player.getInventory().getItemInMainHand();
            if (item && !item.getType().isAir()) {
                let newKills = addKillCount(item, 1);
                updateQualityByKills(item, newKills, player);
            }
        }
    }
}

// 增加击杀计数，返回新的击杀数
function addKillCount(item, amount) {
    if (!item || !item.hasItemMeta()) return 0;
    
    let meta = item.getItemMeta();
    let lore = meta.hasLore() ? meta.getLore() : new (Java.type('java.util.ArrayList'))();
    
    let found = false;
    let currentKills = 0;
    
    for (let i = 0; i < lore.size(); i++) {
        let line = lore.get(i);
        if (line.startsWith(KILL_PREFIX)) {
            let numStr = line.substring(KILL_PREFIX.length).replace(/,/g, '');
            currentKills = parseInt(numStr) || 0;
            currentKills += amount;
            lore.set(i, KILL_PREFIX + formatNumber(currentKills));
            found = true;
            break;
        }
    }
    
    if (!found) {
        currentKills = amount;
        lore.add(KILL_PREFIX + formatNumber(currentKills));
    }
    
    meta.setLore(lore);
    item.setItemMeta(meta);
    return currentKills;
}

// 根据击杀数更新品质等级
function updateQualityByKills(item, kills, player) {
    if (!item || !item.hasItemMeta()) return;
    
    let meta = item.getItemMeta();
    let lore = meta.hasLore() ? meta.getLore() : new (Java.type('java.util.ArrayList'))();
    
    let currentQuality = getCurrentQuality(lore);
    let newQuality = calculateQuality(kills);
    
    if (currentQuality !== newQuality.name) {
        updateQualityLore(lore, newQuality.name);
        meta.setLore(lore);
        item.setItemMeta(meta);
        
        // 品质升级提示
        let itemName = meta.getDisplayName() || "§c灵魂收割者";
        player.sendMessage("§6§l✦ §r" + itemName + " §6§l品质升级！");
        player.sendMessage("§7当前击杀: §c" + kills + " §7品质: " + newQuality.name);
    } else {
        ensureQualityLoreExists(lore, newQuality.name);
        meta.setLore(lore);
        item.setItemMeta(meta);
    }
}

// 获取当前品质
function getCurrentQuality(lore) {
    for (let i = 0; i < lore.size(); i++) {
        let line = lore.get(i);
        if (line.startsWith(QUALITY_PREFIX)) {
            return line.substring(QUALITY_PREFIX.length);
        }
    }
    return null;
}

// 计算品质等级
function calculateQuality(kills) {
    for (let i = 0; i < QUALITY_LEVELS.length; i++) {
        let level = QUALITY_LEVELS[i];
        if (kills >= level.min && kills <= level.max) {
            return level;
        }
    }
    return QUALITY_LEVELS[0];
}

// 更新品质Lore
function updateQualityLore(lore, qualityName) {
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(QUALITY_PREFIX)) {
            lore.set(i, QUALITY_PREFIX + qualityName);
            return;
        }
    }
    let insertIndex = findKillCountIndex(lore);
    if (insertIndex >= 0) {
        lore.add(insertIndex + 1, QUALITY_PREFIX + qualityName);
    } else {
        lore.add(0, QUALITY_PREFIX + qualityName);
    }
}

// 确保品质Lore存在
function ensureQualityLoreExists(lore, qualityName) {
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(QUALITY_PREFIX)) {
            return;
        }
    }
    let insertIndex = findKillCountIndex(lore);
    if (insertIndex >= 0) {
        lore.add(insertIndex + 1, QUALITY_PREFIX + qualityName);
    } else {
        lore.add(0, QUALITY_PREFIX + qualityName);
    }
}

// 查找击杀计数索引
function findKillCountIndex(lore) {
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(KILL_PREFIX)) {
            return i;
        }
    }
    return -1;
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}