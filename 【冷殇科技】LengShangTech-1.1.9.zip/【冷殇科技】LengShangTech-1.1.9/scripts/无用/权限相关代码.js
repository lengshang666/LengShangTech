// ==================== 权限相关导入 ====================
// 导入 Slimefun 的 ProtectionManager，用于检测领地/保护插件权限
var Slimefun = Java.type('io.github.thebusybiscuit.slimefun4.implementation.Slimefun');
// 导入 Interaction 枚举，定义了各种交互类型（破坏、放置、交互等）
var Interaction = Java.type('io.github.thebusybiscuit.slimefun4.libraries.dough.protection.Interaction');


// ==================== 权限检查函数 ====================
/**
 * 检查玩家是否拥有指定位置的权限
 * 兼容 Residence、WorldGuard、GriefPrevention、Towny 等保护插件
 * 
 * @param {Player} player   - 要检查的玩家对象
 * @param {Location} loc    - 要检查的目标位置（世界+坐标）
 * @returns {boolean} 返回 true 表示有权限，false 表示无权限
 */
function hasPermission(player, loc) {
    // 【绕过权限检查】如果玩家是 OP 或拥有 Slimefun 的绕过权限，直接放行
    // slimefun.inventory.bypass 是 Slimefun 内置的管理员绕过权限节点
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) {
        return true;
    }
    
    // 获取 Slimefun 的保护管理器实例
    // 它会自动检测服务器已安装的保护插件（Residence、WG、GP 等）
    var pm = Slimefun.getProtectionManager();
    
    // 同时检查两种权限：
    // BREAK_BLOCK    - 破坏方块权限（吸入水源 = 破坏方块）
    // INTERACT_BLOCK - 交互方块权限（倒出流体 = 放置/交互方块）
    // 两个都必须通过才算有权限
    return pm.hasPermission(player, loc, Interaction.BREAK_BLOCK) && 
           pm.hasPermission(player, loc, Interaction.INTERACT_BLOCK);
}


// ==================== 使用示例 ====================
// 在吸入水源前检查权限：
if (!hasPermission(player, block.getLocation())) {
    player.sendMessage("§c你没有权限在此区域吞噬流体！");
    player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
    return; // 阻止操作
}

// 在倒出流体前检查权限：
if (!hasPermission(player, target.getLocation())) {
    player.sendMessage("§c你没有权限在此区域倒出流体！");
    player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
    return; // 阻止操作
}