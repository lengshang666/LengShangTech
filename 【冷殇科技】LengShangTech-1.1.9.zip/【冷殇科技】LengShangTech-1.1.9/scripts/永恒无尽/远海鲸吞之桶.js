// ==================== 远海鲸吞之桶 ====================
// 右键水源/岩浆源头 → 吸入流体存入桶内
// 右键空地/方块 → 倒出当前选中的流体（原版水桶放置逻辑）
// 蹲下右键 → 循环切换桶内已存储的流体
// 存储量实时显示在物品 Lore 中

const MAX_CAPACITY = 100000; // 每种流体最大容量 (mB)
const UNIT = 1000;          // 单次吸入/倒出量 (mB)

// 流体配置表：键 → {显示名, 方块材质名}
const FLUIDS = {
    'water': { name: '水', material: 'WATER' },
    'lava':  { name: '熔岩', material: 'LAVA' }
};

// ==================== 权限相关导入 ====================
var Slimefun = Java.type('io.github.thebusybiscuit.slimefun4.implementation.Slimefun');
var Interaction = Java.type('io.github.thebusybiscuit.slimefun4.libraries.dough.protection.Interaction');

/**
 * 检查玩家是否拥有指定位置的权限
 * 兼容 Residence、WorldGuard、GriefPrevention 等保护插件
 * 
 * @param {Player} player   - 玩家
 * @param {Location} loc    - 要检查的位置
 * @returns {boolean} 是否有权限
 */
function hasPermission(player, loc) {
    // OP 或拥有 Slimefun 绕过权限则直接放行
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) {
        return true;
    }
    var pm = Slimefun.getProtectionManager();
    // 同时需要破坏和交互权限（吸入=破坏源头，倒出=放置方块）
    return pm.hasPermission(player, loc, Interaction.BREAK_BLOCK) && 
           pm.hasPermission(player, loc, Interaction.INTERACT_BLOCK);
}


// 根据方块材质名反查流体键
function getFluidKeyByMaterial(matName) {
    for (var key in FLUIDS) {
        if (FLUIDS[key].material === matName) return key;
    }
    return null;
}


// ==================== RSC 右键事件入口 ====================
/**
 * @param {PlayerRightClickEvent} event - Slimefun 右键事件
 */
function onUse(event) {
    var player = event.getPlayer();
    var item = event.getItem();
    if (!item) return;

    var meta = item.getItemMeta();
    if (!meta) return;

    // ----- PDC 数据读写准备 -----
    var pdc = meta.getPersistentDataContainer();
    var NamespacedKey = Packages.org.bukkit.NamespacedKey;
    var PersistentDataType = Packages.org.bukkit.persistence.PersistentDataType;

    var keyCurrent = new NamespacedKey("rykenslimefuncustomizer", "bucket_current");
    var keyData = new NamespacedKey("rykenslimefuncustomizer", "bucket_data");

    // 读取当前选中的流体
    var current = "";
    try { current = pdc.get(keyCurrent, PersistentDataType.STRING) || ""; } catch (e) {}

    // 读取所有流体存储数据
    var dataStr = "{}";
    try { dataStr = pdc.get(keyData, PersistentDataType.STRING) || "{}"; } catch (e) {}

    var fluids = {};
    try { fluids = JSON.parse(dataStr); } catch (e) { fluids = {}; }

    // ----- 蹲下 = 切换当前流体 -----
    if (player.isSneaking()) {
        cycleFluid(player, item, meta, pdc, keyCurrent, keyData, PersistentDataType, fluids, current);
        return;
    }

    // ----- 不蹲下 = 吸入或倒出 -----
    handleInteract(event, player, item, meta, pdc, keyCurrent, keyData, PersistentDataType, fluids, current);
}


// ==================== 蹲下切换流体 ====================
function cycleFluid(player, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current) {
    var available = [];
    for (var key in fluids) {
        if (fluids[key] > 0) available.push(key);
    }

    if (available.length === 0) {
        player.sendActionBar("§7桶内空空如也...");
        return;
    }

    var idx = available.indexOf(current);
    if (idx < 0) idx = 0;
    else idx = (idx + 1) % available.length;

    var next = available[idx];
    var amount = fluids[next] || 0;

    pdc.set(keyCurrent, pdt.STRING, next);
    pdc.set(keyData, pdt.STRING, JSON.stringify(fluids));
    updateLore(meta, fluids, next);
    item.setItemMeta(meta);

    var cfg = FLUIDS[next];
    player.sendActionBar("§7当前流体：§e" + cfg.name + " §7| 剩余量：§a" + fmt(amount) + " §7毫升");
}


// ==================== 右键交互：吸入或倒出 ====================
function handleInteract(event, player, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current) {
    // 通过玩家视线获取准星指向的方块（最大 5 格）
    var targetBlock = player.getTargetBlock(null, 5);
    var clicked = targetBlock || null;

    // 如果准星指向的是可吸入的流体方块
    if (clicked) {
        var matName = clicked.getType().name();
        var fluidKey = getFluidKeyByMaterial(matName);

        if (fluidKey) {
            // 必须先确认是源头（Level 0），拒绝流动水/岩浆（Level 1~15）
            if (!isSource(clicked)) {
                player.sendActionBar("§7只能吞噬源头流体！");
                return;
            }

            absorb(player, clicked, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current, fluidKey);
            return;
        }
    }

    // 准星未指向流体方块，尝试倒出
    pour(player, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current);
}


// ==================== 吸入流体 ====================
function absorb(player, block, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current, fluidKey) {
    // 【权限检查】吸入 = 破坏水源/岩浆源，需要该位置的破坏权限
    if (!hasPermission(player, block.getLocation())) {
        player.sendMessage("§c你没有权限在此区域吞噬流体！");
        player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
        return;
    }

    var have = fluids[fluidKey] || 0;

    if (have >= MAX_CAPACITY) {
        player.sendActionBar("§7" + FLUIDS[fluidKey].name + " §7存储已满");
        return;
    }

    // 移除世界中的流体方块
    block.setType(Packages.org.bukkit.Material.AIR);

    // 写入存储
    fluids[fluidKey] = have + UNIT;
    if (!current) current = fluidKey;

    // 保存 PDC 数据
    pdc.set(keyCurrent, pdt.STRING, current);
    pdc.set(keyData, pdt.STRING, JSON.stringify(fluids));

    // 更新 Lore
    updateLore(meta, fluids, current);
    item.setItemMeta(meta);

    player.sendActionBar("§7已吞噬 §e" + FLUIDS[fluidKey].name + " §7x §a" + UNIT + " §7毫升");
}


// ==================== 倒出流体 ====================
function pour(player, item, meta, pdc, keyCurrent, keyData, pdt, fluids, current) {
    if (!current || !fluids[current] || fluids[current] <= 0) {
        player.sendActionBar("§7没有可倒出的流体");
        return;
    }

    // 使用射线追踪模拟原版水桶放置逻辑
    var FluidCollisionMode = Packages.org.bukkit.FluidCollisionMode;
    var ray = player.rayTraceBlocks(5, FluidCollisionMode.NEVER);

    var target = null;

    if (ray) {
        var hitBlock = ray.getHitBlock();
        var hitFace = ray.getHitBlockFace();

        if (hitBlock && hitFace) {
            target = hitBlock.getRelative(hitFace);
        }
    }

    if (!target) {
        player.sendActionBar("§7无法在此处倒出");
        return;
    }

    // 【权限检查】倒出 = 放置流体方块，需要目标位置的放置权限
    if (!hasPermission(player, target.getLocation())) {
        player.sendMessage("§c你没有权限在此区域倒出流体！");
        player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
        return;
    }

    var tName = target.getType().name();
    if (tName !== 'AIR' && tName !== 'CAVE_AIR' && tName !== 'VOID_AIR') {
        player.sendActionBar("§7目标位置被阻挡");
        return;
    }

    // 放置流体
    var cfg = FLUIDS[current];
    var mat = Packages.org.bukkit.Material[cfg.material];
    target.setType(mat);

    // 确保是源头并触发更新
    try {
        var blockData = target.getBlockData();
        if (typeof blockData.getLevel === 'function' && typeof blockData.setLevel === 'function') {
            blockData.setLevel(0);
            target.setBlockData(blockData);
        }
        target.getState().update(true, true);
    } catch (e) {}

    // 扣除存量
    fluids[current] -= UNIT;
    if (fluids[current] <= 0) {
        delete fluids[current];
        var remain = [];
        for (var k in fluids) { if (fluids[k] > 0) remain.push(k); }
        current = remain.length > 0 ? remain[0] : "";
    }

    pdc.set(keyCurrent, pdt.STRING, current);
    pdc.set(keyData, pdt.STRING, JSON.stringify(fluids));
    updateLore(meta, fluids, current);
    item.setItemMeta(meta);

    player.sendActionBar("§7已倒出 §e" + cfg.name + " §7x §a" + UNIT + " §7毫升");
}


// ==================== 工具函数 ====================

/**
 * 检查方块是否为流体源头（Level 0）
 */
function isSource(block) {
    try {
        var data = block.getBlockData();
        if (typeof data.getLevel === 'function') {
            return data.getLevel() === 0;
        }
    } catch (e) {}
    return false;
}

/**
 * 千分位格式化：6000 → "6,000"
 */
function fmt(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * 根据存储数据更新物品 Lore
 */
function updateLore(meta, fluids, current) {
    var lore = [];
    lore.push("§7吞噬一切流体...");

    for (var key in FLUIDS) {
        var amt = fluids[key];
        if (amt && amt > 0) {
            var cfg = FLUIDS[key];
            var color = (key === current) ? "§9" : "§c";
            lore.push(color + cfg.name + ": §f" + fmt(amt) + " mB");
        }
    }

    meta.setLore(lore);
}