// ==================== 导入依赖类 ====================
// Bukkit 主 API，用于调度任务、获取插件等
var Bukkit = Java.type("org.bukkit.Bukkit"); 

// 粒子效果枚举，用于生成视觉特效
var Particle = Java.type("org.bukkit.Particle"); 

// Slimefun 物品 API，用于识别当前物品是否为指定的 Slimefun 物品
var SlimefunItem = Java.type("io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem");

// 通过 Java.extend 动态创建 Runnable 接口的实现类，用于定时任务
var MyRunnable = Java.extend(Java.type("java.lang.Runnable")); 

// 获取 RykenSlimefunCustomizer 插件实例，用于注册 Bukkit 定时任务
var instance = Bukkit.getPluginManager().getPlugin("RykenSlimefunCustomizer");

// ==================== 冷却配置 ====================
// 使用冷却时间：30 秒（30000 毫秒）
var COOLDOWN_MS = 30000;
// 冷却记录表：键=玩家UUID字符串，值=上次成功使用的时间戳
var cooldownMap = new java.util.HashMap();

// ==================== 右键使用事件 ====================
function onUse(event) {
    // 获取触发事件的玩家、所在世界、眼睛位置（头部位置）、视线方向向量
    var p = event.getPlayer(), w = p.getWorld(), loc = p.getEyeLocation(), dir = loc.getDirection();
    
    // 获取玩家右键使用的物品
    var item = event.getItem();
    if (item == null) return; // 如果物品为空，直接返回
    
    // 获取该物品对应的 Slimefun 物品对象
    var sfItem = SlimefunItem.getByItem(item);
    
    // 【安全检查】如果不是 Slimefun 物品，或 ID 不是 "LENGSHANG_终望珍珠"，则终止
    if (!sfItem || sfItem.getId() !== "LENGSHANG_终望珍珠") {
        return;
    }

    // ==================== 冷却检查 ====================
    var uuid = p.getUniqueId().toString();
    var now = Date.now();
    
    if (cooldownMap.containsKey(uuid)) {
        var lastUsed = cooldownMap.get(uuid);
        var remaining = COOLDOWN_MS - (now - lastUsed);
        if (remaining > 0) {
            // 仍在冷却中，提示剩余时间并取消使用
            var seconds = Math.ceil(remaining / 1000);
            p.sendActionBar("§c终望珍珠冷却中，剩余 §e" + seconds + " §c秒");
            p.playSound(p.getLocation(), "block.note_block.bass", 1.0, 0.5);
            return;
        }
    }

    // 【消耗物品】如果物品数量大于 0，扣除 1 个
    if (item.getAmount() > 0) {
        item.setAmount(item.getAmount() - 1);
    } else {
        return; // 数量为 0 则无法使用
    }

    // 【记录冷却】消耗成功后记录使用时间戳
    cooldownMap.put(uuid, now);

    // ==================== 计算黑洞生成位置 ====================
    // 获取玩家视线方向 10 格内的目标方块（准星指向的方块）
    var targetBlock = p.getTargetBlock(null, 10);
    
    // 如果有目标方块，黑洞生成在该方块正上方 1 格；否则生成在玩家前方 5 格处
    var holeLoc = targetBlock ? targetBlock.getLocation().add(0, 1, 0) : p.getLocation().add(dir.multiply(5));
    
    // 播放监守者（Warden）心跳音效，营造压迫感
    // 参数：位置、音效名、音量(2)、音调(0.5，低沉)
    w.playSound(holeLoc, "entity.warden.heartbeat", 2, 0.5);
    
    // 计时器，记录已经经过的 tick 数
    var timer = 0;
    // 定时任务引用，用于后续取消任务
    var holeTask;
    
    // ==================== 创建定时任务（每 1 tick 执行一次）====================
    // runTaskTimer(插件实例, Runnable, 延迟tick, 间隔tick)
    // 延迟 0 tick 立即开始，每 1 tick（0.05秒）执行一次
    holeTask = Bukkit.getScheduler().runTaskTimer(instance, new MyRunnable({
        run: function() {
            // 【阶段2：5秒后爆炸】timer 达到 100（即 5 秒）时触发
            if (timer++ >= 100) {
                // 生成大型爆炸粒子效果（EXPLOSION_EMITTER）
                w.spawnParticle(Particle.EXPLOSION_EMITTER, holeLoc, 10, 2, 2, 2, 1);
                
                // 播放爆炸音效
                w.playSound(holeLoc, "entity.generic.explode", 5, 0.5);
                
                // 遍历黑洞周围 10x10x10 范围内的所有实体
                w.getNearbyEntities(holeLoc, 10, 10, 10).forEach(function(e) {
                    // 排除玩家自身、已死亡实体，且实体需要有 damage 方法
                    if (e != p && e.damage && !e.isDead()) {
                        // 造成 100 点伤害（足以秒杀绝大多数生物），伤害来源设为使用该物品的玩家
                        e.damage(100, p);
                    }
                });
                
                // 取消定时任务，结束黑洞
                return holeTask.cancel();
            }

            // 【阶段1：黑洞持续期间】每 tick 生成粒子特效
            // 生成传送门粒子（紫色漩涡效果），数量 10，扩散范围 1x1x1，速度 0.5
            w.spawnParticle(Particle.PORTAL, holeLoc, 10, 1, 1, 1, 0.5);
            
            // 生成反向传送门粒子（黑色粒子，增强黑洞视觉效果）
            w.spawnParticle(Particle.REVERSE_PORTAL, holeLoc, 10, 0.5, 0.5, 0.5, 0.2);
            
            // 【吸引效果】将周围实体向黑洞中心拉扯
            w.getNearbyEntities(holeLoc, 10, 10, 10).forEach(function(e) {
                // 排除玩家自身和已死亡实体
                if (e != p && !e.isDead()) {
                    // 计算从实体位置指向黑洞中心的单位向量，乘以 0.4 作为速度
                    // normalize() 归一化，multiply(0.4) 控制拉扯力度
                    var vec = holeLoc.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.4);
                    
                    // 设置实体速度，使其向黑洞中心移动
                    e.setVelocity(vec);
                }
            });

            // 每 20 tick（即每 1 秒）播放一次信标环境音效，持续营造氛围
            if (timer % 20 == 0) w.playSound(holeLoc, "block.beacon.ambient", 1, 0.5);
        }
    }), 0, 1);
}