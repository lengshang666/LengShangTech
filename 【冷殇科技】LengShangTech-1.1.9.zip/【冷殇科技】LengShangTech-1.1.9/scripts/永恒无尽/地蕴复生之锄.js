// ==================== 地蕴复生之锄 - 右键骨粉催熟 ====================



/* ==================== 权限检查函数 ==================== */
function hasPermission(player, loc) {
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) {
        return true;
    }
    const pm = Slimefun.getProtectionManager();
    return pm.hasPermission(player, loc, Interaction.BREAK_BLOCK) &&
        pm.hasPermission(player, loc, Interaction.INTERACT_BLOCK);
}

/**
 * 【RSC 强制入口】Slimefun 物品右键事件
 * @param {PlayerRightClickEvent} event - Slimefun 右键事件
 */
function onUse(event) {
    const player = event.getPlayer();

    // getClickedBlock() 返回 Optional<Block>
    // 【修复】用 orElse(null) 安全解包，空 Optional 时返回 null 而不会抛异常
    const clickedBlock = event.getClickedBlock();
    const block = clickedBlock ? clickedBlock.orElse(null) : null;

    // 右键空气时 clickedBlock 为空，直接返回
    if (!block) {
        return;
    }

    /* ========== 权限检查 ========== */
    if (!hasPermission(player, player.getLocation())) {
        player.sendMessage('§c你没有权限在此区域催熟方块！');
        return; // 阻止操作
    }

    const world = block.getWorld();
    const location = block.getLocation();

    // getClickedFace() 直接返回 BlockFace
    const face = event.getClickedFace();

    // ==================== 骨粉催熟逻辑 ====================
    let success = false;
    try {
        success = block.applyBoneMeal(face);
    } catch (e) {
        success = manualBoneMeal(block);
    }

    if (success) {
        playBoneMealEffects(world, location);

        // 取消事件，防止触发方块其他右键行为
        try {
            event.cancel();
        } catch (e) {
            // 若 cancel() 不存在则静默忽略
        }
    }
}


/**
 * 播放骨粉使用的视觉和听觉特效
 */
function playBoneMealEffects(world, loc) {
    const Particle = Packages.org.bukkit.Particle;
    const center = loc.clone().add(0.5, 0.5, 0.5);

    world.playSound(loc, 'item.bone_meal.use', 1.0, 1.0);

    world.spawnParticle(
        Particle.HAPPY_VILLAGER,
        center,
        15,
        0.3, 0.3, 0.3,
        0
    );

    world.spawnParticle(
        Particle.COMPOSTER,
        loc.clone().add(0.5, 0.2, 0.5),
        8,
        0.2, 0.2, 0.2,
        0.05
    );
}


/**
 * 手动骨粉降级处理（1.16以下版本备用）
 */
function manualBoneMeal(block) {
    try {
        const blockData = block.getBlockData();

        if (typeof blockData.getAge === 'function' && typeof blockData.setAge === 'function') {
            const currentAge = blockData.getAge();
            const maxAge = blockData.getMaximumAge();

            if (currentAge < maxAge) {
                const growth = Math.floor(Math.random() * 4) + 2;
                blockData.setAge(Math.min(currentAge + growth, maxAge));
                block.setBlockData(blockData);
                return true;
            }
        }
    } catch (e) {
        // 静默失败
    }
    return false;
}