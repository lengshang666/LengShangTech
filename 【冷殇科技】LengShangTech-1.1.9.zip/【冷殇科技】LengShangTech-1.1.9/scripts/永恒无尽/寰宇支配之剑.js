// ==================== 基础配置区 ====================
// 【物品显示名称】用于识别手持物品是否为本插件对应的特殊武器
// 修改此值时，需同步修改对应物品的 ItemMeta.displayName
const DISPLAY_NAME = '帝烬·寰宇支配之剑';

// 【作用范围】以玩家为中心，X/Y/Z 三个方向各延伸的格数（半径）
// 例如 20 表示以玩家为中心 20×20×20 的立方体范围
const RANGE = 20;

// 【单次右键造成的伤害值】20 点 = 10 颗心（Minecraft 中 1 心 = 2 点伤害）
const DAMAGE = 20;


// ==================== 核心功能函数 ====================
/**
 * 右键触发时的主逻辑：对范围内符合条件的实体造成伤害
 * @param {PlayerInteractEvent} evt - Bukkit 的交互事件对象
 */
function onUse(evt) {
    // --- 获取基础对象 ---
    const player = evt.getPlayer();           // 触发事件的玩家
    const world = player.getWorld();          // 玩家当前所在世界
    const location = player.getLocation();    // 玩家当前坐标（中心点）

    // --- 播放全局音效 ---
    // 参数说明: (坐标, 音效名, 音量, 音调)
    // 音量 1 = 正常，音调 <1 低沉，>1 尖锐
    world.playSound(location, 'entity.wither.death', 1, 0.7);
    world.playSound(location, 'entity.ender_dragon.death', 1, 1.2);

    // --- 引用 Bukkit 实体类（用于类型判断）---
    const LivingEntity = Packages.org.bukkit.entity.LivingEntity;  // 所有活着的生物（含玩家）
    const ArmorStand   = Packages.org.bukkit.entity.ArmorStand;    // 盔甲架
    const Player       = Packages.org.bukkit.entity.Player;        // 玩家
    const GameMode     = Packages.org.bukkit.GameMode;             // 游戏模式枚举

    let hitCount = 0;  // 计数器：记录实际受到伤害的目标数量

    // --- 遍历范围内所有实体 ---
    // getNearbyEntities(x, y, z): 获取以 location 为中心，指定半径内的所有实体
    world.getNearbyEntities(location, RANGE, RANGE, RANGE).forEach(function(ent) {
        
        // 【排除1】隐身盔甲架：部分插件用隐形盔甲架做特效/标记，不应被攻击
        if (ent instanceof ArmorStand) return;

        // 【排除2】观察模式玩家：处于旁观模式(SPECTATOR)的玩家不应受到伤害
        if (ent instanceof Player) {
            if (ent.getGameMode().name() === 'SPECTATOR') return;
        }

        // 【执行伤害】目标必须是 LivingEntity（活物），且不能是自己
        if (ent instanceof LivingEntity && ent !== player) {
            // damage(伤害值, 伤害来源): 对实体造成伤害，并记录伤害来源（用于仇恨、死亡提示等）
            ent.damage(DAMAGE, player);
            hitCount++;  // 命中数 +1

            // 在每个被击中的目标位置播放爆炸音效
            world.playSound(ent.getLocation(), 'entity.generic.explode', 0.8, 1.5);
        }
    });
    // 如需添加命中后的反馈信息（如聊天栏提示、屏幕标题），可在此 hitCount 判断后添加
}


// ==================== 事件监听与绑定 ====================
/**
 * 插件加载时执行的初始化函数
 * 返回一个对象，键为事件名，值为对应的监听函数
 */
function onLoad() {
    return {
        // 监听玩家交互事件（右键空气/方块）
        PlayerInteractEvent: function (evt) {
            const action = evt.getAction().name();  // 获取交互动作名称

            // 【过滤1】只响应右键空气 或 右键方块，忽略左键和其他动作
            if (action !== 'RIGHT_CLICK_AIR' && action !== 'RIGHT_CLICK_BLOCK') return;

            // 【过滤2】只响应主手（右手）操作，避免副手触发双次
            if (evt.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) return;

            // 【过滤3】检查主手物品是否存在、是否有元数据、名称是否匹配
            const item = evt.getPlayer().getInventory().getItemInMainHand();
            if (!item || !item.hasItemMeta()) return;                    // 物品为空或无元数据
            if (item.getItemMeta().getDisplayName() !== DISPLAY_NAME) return;  // 名称不匹配

            // --- 触发核心功能 ---
            onUse(evt);

            // 取消原事件，防止右键触发其他默认行为（如放置方块、使用物品等）
            evt.setCancelled(true);
        }
    };
}

// 执行加载，注册事件监听
onLoad();