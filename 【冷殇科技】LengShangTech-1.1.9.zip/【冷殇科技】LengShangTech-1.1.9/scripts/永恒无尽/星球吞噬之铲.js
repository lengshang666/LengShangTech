// ==================== 导入依赖类 ====================
var Bukkit = Java.type("org.bukkit.Bukkit");
var Particle = Java.type("org.bukkit.Particle");
var SlimefunItem = Java.type("io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem");
var MyRunnable = Java.extend(Java.type("java.lang.Runnable"));
var instance = Bukkit.getPluginManager().getPlugin("RykenSlimefunCustomizer");

// ==================== 冷却配置 ====================
var COOLDOWN_MS = 30000;          // 冷却时间 30 秒
var cooldownMap = new Map();     // 玩家UUID -> 上次使用时间戳


// ==================== 右键使用事件 ====================
function onUse(event) {
    // 获取玩家
    var p = event.getPlayer();

    // 【检查1】必须蹲下（潜行）才能触发
    if (!p.isSneaking()) {
        return;
    }

    // 【检查2】获取主手物品（蹲下时 event.getItem() 可能返回 null，改用主手获取更稳定）
    var item = p.getInventory().getItemInMainHand();
    if (!item || item.getType().name() === 'AIR') {
        return;
    }

    // 【检查3】验证是否为正确的 Slimefun 物品
    // 注意：如果 RSC 已经确保只有该物品会调用此脚本，可删除此检查
    var sfItem = SlimefunItem.getByItem(item);
    if (!sfItem || sfItem.getId() !== "LENGSHANG_星球吞噬之铲") {
        return;
    }

    // 【检查4】冷却时间（必须在所有前置验证通过后再检查，避免无效操作也进冷却）
    var uuid = p.getUniqueId().toString();
    var now = Date.now();

    if (cooldownMap.has(uuid) && (now - cooldownMap.get(uuid)) < COOLDOWN_MS) {
        var remainSec = Math.ceil((COOLDOWN_MS - (now - cooldownMap.get(uuid))) / 1000);
        p.sendActionBar("§7技能冷却中... §c" + remainSec + " §7秒");
        return;
    }

    // 【关键】所有验证通过后，才记录冷却时间
    cooldownMap.set(uuid, now);

    // ==================== 以下为黑洞核心逻辑 ====================
    var w = p.getWorld();
    var loc = p.getEyeLocation();
    var dir = loc.getDirection();

    // 计算黑洞生成位置：准星指向方块上方1格，或玩家前方5格
    var targetBlock = p.getTargetBlock(null, 10);
    var holeLoc = targetBlock
        ? targetBlock.getLocation().add(0, 1, 0)
        : p.getLocation().add(dir.multiply(5));

    // 播放监守者心跳音效
    w.playSound(holeLoc, "entity.warden.heartbeat", 2, 0.5);

    var timer = 0;
    var holeTask;

    // 创建定时任务（每 1 tick 执行一次，持续 5 秒后爆炸）
    holeTask = Bukkit.getScheduler().runTaskTimer(instance, new MyRunnable({
        run: function() {
            // 5秒后爆炸（100 tick = 5秒）
            if (timer++ >= 100) {
                w.spawnParticle(Particle.EXPLOSION_EMITTER, holeLoc, 10, 2, 2, 2, 1);
                w.playSound(holeLoc, "entity.generic.explode", 5, 0.5);

                w.getNearbyEntities(holeLoc, 10, 10, 10).forEach(function(e) {
                    if (e != p && e.damage && !e.isDead()) {
                        e.damage(100, p);
                    }
                });

                return holeTask.cancel();
            }

            // 黑洞粒子效果
            w.spawnParticle(Particle.PORTAL, holeLoc, 10, 1, 1, 1, 0.5);
            w.spawnParticle(Particle.REVERSE_PORTAL, holeLoc, 10, 0.5, 0.5, 0.5, 0.2);

            // 吸引周围实体
            w.getNearbyEntities(holeLoc, 10, 10, 10).forEach(function(e) {
                if (e != p && !e.isDead()) {
                    var vec = holeLoc.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.4);
                    e.setVelocity(vec);
                }
            });

            // 每秒播放一次环境音效
            if (timer % 20 == 0) {
                w.playSound(holeLoc, "block.beacon.ambient", 1, 0.5);
            }
        }
    }), 0, 1);
}