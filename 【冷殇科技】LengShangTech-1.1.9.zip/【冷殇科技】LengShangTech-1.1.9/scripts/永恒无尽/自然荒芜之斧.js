// ==================== 自然荒芜之斧 - 生命收割 ====================
// 左键：正常砍伐
// 右键：释放荒芜波，范围内树木瞬间砍伐，吸收生命回复自身

const ITEM_ID = 'LENGSHANG_自然荒芜之斧';
const RANGE = 6;           // 荒芜波范围
const COOLDOWN_MS = 5000;  // 冷却 5 秒
var cooldownMap = new java.util.HashMap();


function onToolBreak(event, item, fortune, drops) {
    // 左键正常砍伐
}


function onUse(event) {
    var player = event.getPlayer();
    var item = event.getItem();
    if (!item) return;

    var sfItem = getSfItemByItem(item);
    if (!sfItem || sfItem.getId() !== ITEM_ID) return;

    var uuid = player.getUniqueId().toString();
    var now = Date.now();

    if (cooldownMap.containsKey(uuid)) {
        var last = cooldownMap.get(uuid);
        if (now - last < COOLDOWN_MS) {
            var remainSec = Math.ceil((COOLDOWN_MS - (now - last)) / 1000);
            player.sendActionBar("§7生命之力恢复中... §c" + remainSec + " §7秒");
            return;
        }
    }

    var targetBlock = player.getTargetBlock(null, 6);
    if (!targetBlock) {
        player.sendActionBar("§7未指向有效目标");
        return;
    }

    var centerLoc = targetBlock.getLocation();
    var world = centerLoc.getWorld();

    if (!hasPermission(player, centerLoc)) {
        player.sendMessage("§c你没有权限在此区域释放荒芜之力！");
        return;
    }

    cooldownMap.put(uuid, now);

    // 范围砍伐 + 生命收割
    var treeCount = harvestTrees(world, centerLoc, player);
    var healAmount = treeCount * 2; // 每棵树回复 2 点生命

    if (treeCount > 0) {
        // 回复生命
        var currentHealth = player.getHealth();
        var maxHealth = player.getMaxHealth();
        player.setHealth(Math.min(currentHealth + healAmount, maxHealth));

        // 特效
        world.playSound(centerLoc, "entity.warden.sonic_boom", 0.5, 0.8);
        world.spawnParticle(Packages.org.bukkit.Particle.HAPPY_VILLAGER, 
            player.getLocation().add(0, 1, 0), 10, 0.3, 0.5, 0.3, 0);

        player.sendMessage("§7收割了 §a" + treeCount + " §7棵树木，回复 §c" + healAmount + " §7点生命");
    } else {
        player.sendActionBar("§7范围内没有可收割的树木");
    }
}


// 范围砍伐树木
function harvestTrees(world, center, player) {
    var Material = Packages.org.bukkit.Material;
    var count = 0;
    var logs = [];

    // 收集范围内所有原木
    for (var x = -RANGE; x <= RANGE; x++) {
        for (var y = -RANGE; y <= RANGE; y++) {
            for (var z = -RANGE; z <= RANGE; z++) {
                var loc = center.clone().add(x, y, z);
                var block = world.getBlockAt(loc);
                var mat = block.getType().name();

                if (mat.endsWith('_LOG') || mat.endsWith('_WOOD')) {
                    logs.push(block);
                }
            }
        }
    }

    // 从底部向上砍伐（防止悬浮）
    logs.sort(function(a, b) {
        return a.getY() - b.getY();
    });

    for (var i = 0; i < logs.length; i++) {
        var block = logs[i];
        // 掉落原木
        var drops = block.getDrops();
        for (var j = 0; j < drops.size(); j++) {
            world.dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), drops.get(j));
        }
        block.setType(Material.AIR);
        count++;
    }

    return count;
}


function hasPermission(player, location) {
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) return true;
    var Slimefun = Java.type('io.github.thebusybiscuit.slimefun4.implementation.Slimefun');
    var Interaction = Java.type('io.github.thebusybiscuit.slimefun4.libraries.dough.protection.Interaction');
    var pm = Slimefun.getProtectionManager();
    return pm.hasPermission(player, location, Interaction.BREAK_BLOCK) &&
           pm.hasPermission(player, location, Interaction.INTERACT_BLOCK);
}