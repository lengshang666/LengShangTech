// ==================== 九霄惊雷之锤 ====================
// 效果：下落攻击命中实体时，召唤真雷电劈击目标位置
//       若世界处于雨天或雷暴天气，此次伤害额外提升 50%
// 右键：发射一枚风弹，冷却 3 秒

// 【冷却配置】右键风弹冷却时间（毫秒）
const COOLDOWN_MS = 1000;
// 冷却记录表：键=玩家UUID，值=上次成功发射的时间戳
var cooldownMap = new java.util.HashMap();


// ==================== 武器攻击事件（下落惊雷）====================
function onWeaponHit(event, player) {

    // 获取被击中的实体
    let target = event.getEntity();
    if (!target) return;

    // 【下落攻击判断】
    // 重锤基础伤害为 6，只要伤害大于 6 就说明触发了密度/下落加成
    // 同时保留 fallDistance 检测以兼容空中连击的情况
    let isFallingAttack = player.getFallDistance() > 0.5 || event.getDamage() > 6.5;
    if (!isFallingAttack) return;

    let world = player.getWorld();
    let loc = target.getLocation();

    // ==================== 核心效果：召唤真雷电 ====================
    // strikeLightningEffect 为纯视觉雷电，无真实伤害
    world.strikeLightningEffect(loc);

    // ==================== 天气增伤 ====================
    // hasStorm() = 下雨/雷暴；isThundering() = 雷暴
    if (world.hasStorm() || world.isThundering()) {
        
        // 在原始伤害基础上提升 50%（会与重锤密度伤害叠加）
        let baseDamage = event.getDamage();
        event.setDamage(baseDamage * 1.5);

        // 雷暴天气特效：大量电火花 + 雷声
        try {
            let Particle = Java.type("org.bukkit.Particle");
            let Sound = Java.type("org.bukkit.Sound");
            world.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 30, 1.0, 1.0, 1.0, 0.5);
            world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5, 1.0);
        } catch (e) {}

        player.sendActionBar("§b§l九霄惊雷！§7天威降世，伤害提升 50%");

    } else {
        
        // 普通天气：小型电火花 + 闪电命中音效
        try {
            let Particle = Java.type("org.bukkit.Particle");
            let Sound = Java.type("org.bukkit.Sound");
            world.spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0, 1, 0), 12, 0.5, 0.5, 0.5, 0.2);
            world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0, 1.2);
        } catch (e) {}

        player.sendActionBar("§e§l惊雷落下！");
    }
}


// ==================== 物品右键事件（发射风弹）====================
function onUse(event) {
    let player = event.getPlayer();
    let uuid = player.getUniqueId().toString();
    let now = Date.now();

    // 【冷却检查】
    if (cooldownMap.containsKey(uuid)) {
        let last = cooldownMap.get(uuid);
        let remaining = COOLDOWN_MS - (now - last);
        if (remaining > 0) {
            // 【修改】保留一位小数显示
            let seconds = (remaining / 1000).toFixed(1);
            player.sendActionBar("§7风弹冷却中，剩余 §c" + seconds + " §c秒");
            player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
            return;
        }
    }

    // 记录冷却
    cooldownMap.put(uuid, now);

    let world = player.getWorld();
    let eyeLoc = player.getEyeLocation();
    let dir = eyeLoc.getDirection();

    // 发射风弹
    try {
        let EntityType = Packages.org.bukkit.entity.EntityType;
        let windCharge = world.spawnEntity(eyeLoc, EntityType.WIND_CHARGE);
        
        // 设置飞行方向与速度
        windCharge.setVelocity(dir.multiply(1.5));
        
        // 设置发射者（影响风弹爆炸时的推力归属）
        try {
            windCharge.setShooter(player);
        } catch (e) {}
        
        // 音效
        world.playSound(eyeLoc, "entity.wind_charge.throw", 1.0, 1.0);
        
    } catch (e) {
        // 若 spawnEntity 失败，尝试 launchProjectile 方式
        try {
            let WindCharge = Java.type('org.bukkit.entity.WindCharge');
            player.launchProjectile(WindCharge.class, dir.multiply(1.5));
            world.playSound(eyeLoc, "entity.wind_charge.throw", 1.0, 1.0);
        } catch (e2) {
            player.sendMessage("§7风弹发射失败，请检查服务端版本是否支持 WindCharge");
        }
    }
}