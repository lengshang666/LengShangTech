// ==================== 世界崩解之镐 ====================
// 左键：正常挖掘（原版行为，由 RSC 工具事件处理）
// 右键：破碎准星指向的方块（包括基岩、末地传送门等不可破坏方块）
//        破碎后生成对应掉落物

// 【粘液物品 ID】用于绑定此脚本到特定 Slimefun 物品
const ITEM_ID = 'LENGSHANG_世界崩解之镐';

// 【冷却配置】右键崩解冷却时间（毫秒），防止连续触发
const COOLDOWN_MS = 500;

// 冷却记录表：键=玩家UUID，值=上次成功崩解的时间戳
var cooldownMap = new java.util.HashMap();


// ==================== RSC 工具左键事件（正常挖掘）====================
function onToolBreak(event, item, fortune, drops) {
    // 左键保持原版行为，无需额外处理
}


// ==================== RSC 物品右键事件（崩解破碎）====================
function onUse(event) {
    var player = event.getPlayer();
    var item = event.getItem();
    if (!item) return;

    // 【关键】通过 Slimefun ID 验证物品
    var sfItem = getSfItemByItem(item);
    if (!sfItem || sfItem.getId() !== ITEM_ID) return;

    var uuid = player.getUniqueId().toString();
    var now = Date.now();

    // 【冷却检查】若距离上次崩解不足 500ms，直接返回
    if (cooldownMap.containsKey(uuid)) {
        var last = cooldownMap.get(uuid);
        if (now - last < COOLDOWN_MS) {
            return; // 冷却中，静默忽略
        }
    }

    // 获取准星指向的方块（最大距离 5 格）
    var targetBlock = player.getTargetBlock(null, 5);
    if (!targetBlock) {
        player.sendActionBar("§7未指向任何方块");
        return;
    }

    var block = targetBlock;
    var material = block.getType();
    var matName = material.name();

    // 不能破坏空气
    if (matName === 'AIR' || matName === 'CAVE_AIR' || matName === 'VOID_AIR') {
        player.sendActionBar("§7无法崩解空气");
        return;
    }

    var world = block.getWorld();
    var loc = block.getLocation();

    // 【权限检查】需要该位置的破坏权限
    if (!hasPermission(player, loc)) {
        player.sendMessage("§7你没有权限在此区域崩解方块！");
        player.playSound(player.getLocation(), "block.note_block.bass", 1.0, 0.5);
        return;
    }

    // 【记录冷却】在崩解前记录时间戳，确保即使后续报错也不会重复触发
    cooldownMap.put(uuid, now);

    // 生成掉落物
    var drops = getDrops(block);

    // 【关键修复】清除粘液方块数据，防止刷物
    try {
        var BlockStorage = Java.type('me.mrCookieSlime.Slimefun.api.BlockStorage');
        if (BlockStorage.check(block)) {
            BlockStorage.clearBlockInfo(block, false);
        }
    } catch (e) {
        // BlockStorage 异常时不阻塞崩解流程
    }

    // 破坏方块（强制破坏，无视硬度）
    block.setType(Packages.org.bukkit.Material.AIR);

    // 掉落物品
    if (drops && drops.length > 0) {
        var dropLoc = loc.clone().add(0.5, 0.5, 0.5);
        for (var i = 0; i < drops.length; i++) {
            var dropItem = world.dropItem(dropLoc, drops[i]);
            dropItem.setVelocity(new Packages.org.bukkit.util.Vector(0, 0, 0));
        }
    }

    // 视觉特效
    world.playSound(loc, "block.stone.break", 1.0, 0.8);

    try {
        var Particle = Packages.org.bukkit.Particle;
        var center = loc.clone().add(0.5, 0.5, 0.5);

        world.spawnParticle(
            Particle.EXPLOSION_NORMAL,
            center,
            3, 0.2, 0.2, 0.2, 0.05
        );

        try {
            world.spawnParticle(
                Particle.BLOCK_DUST,
                center,
                15, 0.3, 0.3, 0.3, 0.1,
                material.createBlockData()
            );
        } catch (e2) { }
    } catch (e) { }

    player.sendActionBar("§7已崩解 §c" + getBlockName(matName));
}


// ==================== 掉落物计算 ====================
function getDrops(block) {
    var mat = block.getType();
    var matName = mat.name();
    var Material = Packages.org.bukkit.Material;
    var ItemStack = Packages.org.bukkit.inventory.ItemStack;

    // 【新增】检测是否为粘液方块，如果是则掉落粘液物品本身
    try {
        var BlockStorage = Java.type('me.mrCookieSlime.Slimefun.api.BlockStorage');
        var sfBlockItem = BlockStorage.check(block);
        if (sfBlockItem) {
            var sfDrop = sfBlockItem.getItem();
            if (sfDrop) {
                return [sfDrop.clone()];
            }
        }
    } catch (e) {
        // BlockStorage 不可用或发生异常，继续按原版处理
    }

    // 【关键修复】流体方块（水、岩浆）不是物品，需要特殊处理
    // 1.21+ 中 ItemStack 构造函数会检查材质是否为物品，方块材质会抛异常
    switch (matName) {
        // 不可破坏方块 → 掉落自身
        case 'BEDROCK':
            return [new ItemStack(mat, 1)];
        case 'END_PORTAL_FRAME':
            return [new ItemStack(mat, 1)];
        case 'END_PORTAL':
            return [new ItemStack(Material.ENDER_EYE, 1)];
        case 'NETHER_PORTAL':
            return [new ItemStack(Material.OBSIDIAN, 1)];
        case 'DRAGON_EGG':
            return [new ItemStack(mat, 1)];
        case 'COMMAND_BLOCK':
        case 'REPEATING_COMMAND_BLOCK':
        case 'CHAIN_COMMAND_BLOCK':
            return [new ItemStack(mat, 1)];
        case 'BARRIER':
            return [new ItemStack(mat, 1)];
        case 'STRUCTURE_BLOCK':
        case 'STRUCTURE_VOID':
            return [new ItemStack(mat, 1)];
        case 'JIGSAW':
            return [new ItemStack(mat, 1)];
        case 'LIGHT':
            return [new ItemStack(mat, 1)];
        case 'SPAWNER':
            return [new ItemStack(mat, 1)];

        // 【新增】流体方块处理
        case 'WATER':
            // 水源崩解后掉落水桶（或空桶）
            return [new ItemStack(Material.BUCKET, 1)];
        case 'LAVA':
            return [new ItemStack(Material.BUCKET, 1)];
    }

    // 【关键修复】安全创建 ItemStack，避免非物品材质导致崩溃
    var drops = [];
    try {
        // 先尝试获取方块的默认掉落物
        var blockDrops = block.getDrops();
        if (blockDrops && blockDrops.size() > 0) {
            for (var i = 0; i < blockDrops.size(); i++) {
                drops.push(blockDrops.get(i));
            }
        } else {
            // 无特殊掉落，尝试创建物品
            // 使用 try-catch 防止非物品材质（如流体、火、末地传送门等）崩溃
            try {
                drops.push(new ItemStack(mat, 1));
            } catch (e) {
                // 若该材质不是物品（如火、水、末地门等），静默忽略
                // 这些方块崩解后不掉落任何物品
            }
        }
    } catch (e) {
        // 异常时尝试安全创建
        try {
            drops.push(new ItemStack(mat, 1));
        } catch (e2) {
            // 非物品材质，不掉落
        }
    }

    return drops;
}

// ==================== 方块名称显示（完整中文映射）====================
function getBlockName(matName) {
    var names = {
        'BEDROCK': '基岩',
        'END_PORTAL_FRAME': '末地传送门框架',
        'END_PORTAL': '末地传送门',
        'NETHER_PORTAL': '地狱传送门',
        'DRAGON_EGG': '龙蛋',
        'COMMAND_BLOCK': '命令方块',
        'REPEATING_COMMAND_BLOCK': '循环命令方块',
        'CHAIN_COMMAND_BLOCK': '连锁命令方块',
        'BARRIER': '屏障',
        'STRUCTURE_BLOCK': '结构方块',
        'STRUCTURE_VOID': '结构空位',
        'JIGSAW': '拼图方块',
        'LIGHT': '光源方块',
        'SPAWNER': '刷怪笼',
        'STONE': '石头',
        'GRANITE': '花岗岩',
        'DIORITE': '闪长岩',
        'ANDESITE': '安山岩',
        'COBBLESTONE': '圆石',
        'MOSSY_COBBLESTONE': '苔石',
        'SMOOTH_STONE': '平滑石头',
        'DEEPSLATE': '深板岩',
        'COBBLED_DEEPSLATE': '深板岩圆石',
        'POLISHED_DEEPSLATE': '磨制深板岩',
        'TUFF': '凝灰岩',
        'CALCITE': '方解石',
        'DRIPSTONE_BLOCK': '滴水石块',
        'DIRT': '泥土',
        'COARSE_DIRT': '砂土',
        'ROOTED_DIRT': '缠根泥土',
        'PODZOL': '灰化土',
        'MYCELIUM': '菌丝体',
        'GRASS_BLOCK': '草方块',
        'MUD': '泥巴',
        'CLAY': '黏土',
        'SAND': '沙子',
        'RED_SAND': '红沙',
        'GRAVEL': '沙砾',
        'COAL_ORE': '煤矿石',
        'DEEPSLATE_COAL_ORE': '深层煤矿石',
        'IRON_ORE': '铁矿石',
        'DEEPSLATE_IRON_ORE': '深层铁矿石',
        'COPPER_ORE': '铜矿石',
        'DEEPSLATE_COPPER_ORE': '深层铜矿石',
        'GOLD_ORE': '金矿石',
        'DEEPSLATE_GOLD_ORE': '深层金矿石',
        'REDSTONE_ORE': '红石矿石',
        'DEEPSLATE_REDSTONE_ORE': '深层红石矿石',
        'EMERALD_ORE': '绿宝石矿石',
        'DEEPSLATE_EMERALD_ORE': '深层绿宝石矿石',
        'LAPIS_ORE': '青金石矿石',
        'DEEPSLATE_LAPIS_ORE': '深层青金石矿石',
        'DIAMOND_ORE': '钻石矿石',
        'DEEPSLATE_DIAMOND_ORE': '深层钻石矿石',
        'NETHER_GOLD_ORE': '下界金矿石',
        'NETHER_QUARTZ_ORE': '下界石英矿石',
        'ANCIENT_DEBRIS': '远古残骸',
        'COAL_BLOCK': '煤炭块',
        'IRON_BLOCK': '铁块',
        'COPPER_BLOCK': '铜块',
        'GOLD_BLOCK': '金块',
        'REDSTONE_BLOCK': '红石块',
        'EMERALD_BLOCK': '绿宝石块',
        'LAPIS_BLOCK': '青金石块',
        'DIAMOND_BLOCK': '钻石块',
        'NETHERITE_BLOCK': '下界合金块',
        'QUARTZ_BLOCK': '石英块',
        'AMETHYST_BLOCK': '紫水晶块',
        'OAK_LOG': '橡木原木',
        'SPRUCE_LOG': '云杉原木',
        'BIRCH_LOG': '白桦原木',
        'JUNGLE_LOG': '丛林原木',
        'ACACIA_LOG': '金合欢原木',
        'DARK_OAK_LOG': '深色橡木原木',
        'MANGROVE_LOG': '红树原木',
        'CHERRY_LOG': '樱花原木',
        'OAK_WOOD': '橡木',
        'OAK_PLANKS': '橡木木板',
        'STRIPPED_OAK_LOG': '去皮橡木原木',
        'OAK_LEAVES': '橡树树叶',
        'SPRUCE_LEAVES': '云杉树叶',
        'BIRCH_LEAVES': '白桦树叶',
        'GLASS': '玻璃',
        'WHITE_STAINED_GLASS': '白色染色玻璃',
        'ORANGE_STAINED_GLASS': '橙色染色玻璃',
        'WHITE_WOOL': '白色羊毛',
        'ORANGE_WOOL': '橙色羊毛',
        'WHITE_CONCRETE': '白色混凝土',
        'BLACK_CONCRETE': '黑色混凝土',
        'TERRACOTTA': '陶瓦',
        'WHITE_TERRACOTTA': '白色陶瓦',
        'NETHERRACK': '下界岩',
        'SOUL_SAND': '灵魂沙',
        'SOUL_SOIL': '灵魂土',
        'BASALT': '玄武岩',
        'BLACKSTONE': '黑石',
        'GILDED_BLACKSTONE': '镶金黑石',
        'NETHER_BRICKS': '下界砖块',
        'CRIMSON_NYLIUM': '绯红菌岩',
        'WARPED_NYLIUM': '诡异菌岩',
        'END_STONE': '末地石',
        'END_STONE_BRICKS': '末地石砖',
        'PURPUR_BLOCK': '紫珀块',
        'PURPUR_PILLAR': '紫珀柱',
        'OAK_SAPLING': '橡树树苗',
        'GRASS': '草',
        'FERN': '蕨',
        'DEAD_BUSH': '枯萎的灌木',
        'DANDELION': '蒲公英',
        'POPPY': '虞美人',
        'BLUE_ORCHID': '兰花',
        'ALLIUM': '绒球葱',
        'AZURE_BLUET': '蓝花美耳草',
        'RED_TULIP': '红色郁金香',
        'ORANGE_TULIP': '橙色郁金香',
        'WHITE_TULIP': '白色郁金香',
        'PINK_TULIP': '粉色郁金香',
        'OXEYE_DAISY': '滨菊',
        'CORNFLOWER': '矢车菊',
        'LILY_OF_THE_VALLEY': '铃兰',
        'SUNFLOWER': '向日葵',
        'LILAC': '丁香',
        'ROSE_BUSH': '玫瑰丛',
        'PEONY': '牡丹',
        'CACTUS': '仙人掌',
        'SUGAR_CANE': '甘蔗',
        'BAMBOO': '竹子',
        'VINE': '藤蔓',
        'LILY_PAD': '睡莲',
        'WHEAT': '小麦',
        'CARROTS': '胡萝卜',
        'POTATOES': '马铃薯',
        'BEETROOTS': '甜菜根',
        'PUMPKIN': '南瓜',
        'MELON': '西瓜',
        'CARVED_PUMPKIN': '雕刻过的南瓜',
        'JACK_O_LANTERN': '南瓜灯',
        'HAY_BLOCK': '干草捆',
        'BROWN_MUSHROOM': '棕色蘑菇',
        'RED_MUSHROOM': '红色蘑菇',
        'MUSHROOM_STEM': '蘑菇柄',
        'ICE': '冰',
        'PACKED_ICE': '浮冰',
        'BLUE_ICE': '蓝冰',
        'SNOW_BLOCK': '雪块',
        'SNOW': '雪',
        'WATER': '水源',
        'LAVA': '岩浆源',
        'CRAFTING_TABLE': '工作台',
        'FURNACE': '熔炉',
        'BLAST_FURNACE': '高炉',
        'SMOKER': '烟熏炉',
        'CAMPFIRE': '营火',
        'SOUL_CAMPFIRE': '灵魂营火',
        'CHEST': '箱子',
        'TRAPPED_CHEST': '陷阱箱',
        'ENDER_CHEST': '末影箱',
        'BARREL': '木桶',
        'WHITE_BED': '白色床',
        'ORANGE_BED': '橙色床',
        'MAGENTA_BED': '品红色床',
        'LIGHT_BLUE_BED': '淡蓝色床',
        'YELLOW_BED': '黄色床',
        'LIME_BED': '黄绿色床',
        'PINK_BED': '粉色床',
        'GRAY_BED': '灰色床',
        'LIGHT_GRAY_BED': '淡灰色床',
        'CYAN_BED': '青色床',
        'PURPLE_BED': '紫色床',
        'BLUE_BED': '蓝色床',
        'BROWN_BED': '棕色床',
        'GREEN_BED': '绿色床',
        'RED_BED': '红色床',
        'BLACK_BED': '黑色床',
        'OAK_DOOR': '橡木门',
        'IRON_DOOR': '铁门',
        'OAK_FENCE': '橡木栅栏',
        'NETHER_BRICK_FENCE': '下界砖栅栏',
        'OAK_STAIRS': '橡木楼梯',
        'COBBLESTONE_STAIRS': '圆石楼梯',
        'STONE_BRICK_STAIRS': '石砖楼梯',
        'OAK_SLAB': '橡木台阶',
        'STONE_SLAB': '石头台阶',
        'BRICKS': '红砖块',
        'STONE_BRICKS': '石砖',
        'MOSSY_STONE_BRICKS': '苔石砖',
        'CRACKED_STONE_BRICKS': '裂石砖',
        'CHISELED_STONE_BRICKS': '雕纹石砖',
        'DEEPSLATE_BRICKS': '深板岩砖',
        'DEEPSLATE_TILES': '深板岩瓦',
        'POLISHED_BLACKSTONE_BRICKS': '磨制黑石砖',
        'SANDSTONE': '砂岩',
        'CUT_SANDSTONE': '切制砂岩',
        'CHISELED_SANDSTONE': '雕纹砂岩',
        'SMOOTH_SANDSTONE': '平滑砂岩',
        'RED_SANDSTONE': '红砂岩',
        'PRISMARINE': '海晶石',
        'PRISMARINE_BRICKS': '海晶石砖',
        'DARK_PRISMARINE': '暗海晶石',
        'SEA_LANTERN': '海晶灯',
        'OBSIDIAN': '黑曜石',
        'CRYING_OBSIDIAN': '哭泣的黑曜石',
        'ENCHANTING_TABLE': '附魔台',
        'BOOKSHELF': '书架',
        'LECTERN': '讲台',
        'ANVIL': '铁砧',
        'CHIPPED_ANVIL': '开裂的铁砧',
        'DAMAGED_ANVIL': '损坏的铁砧',
        'BEACON': '信标',
        'CONDUIT': '潮涌核心',
        'JUKEBOX': '唱片机',
        'NOTE_BLOCK': '音符盒',
        'PISTON': '活塞',
        'STICKY_PISTON': '粘性活塞',
        'REDSTONE_WIRE': '红石线',
        'REDSTONE_TORCH': '红石火把',
        'REPEATER': '红石中继器',
        'COMPARATOR': '红石比较器',
        'DAYLIGHT_DETECTOR': '阳光探测器',
        'OBSERVER': '侦测器',
        'HOPPER': '漏斗',
        'DROPPER': '投掷器',
        'DISPENSER': '发射器',
        'RAIL': '铁轨',
        'POWERED_RAIL': '动力铁轨',
        'DETECTOR_RAIL': '探测铁轨',
        'ACTIVATOR_RAIL': '激活铁轨',
        'LADDER': '梯子',
        'SCAFFOLDING': '脚手架',
        'OAK_SIGN': '橡木告示牌',
        'OAK_WALL_SIGN': '墙上的橡木告示牌',
        'PAINTING': '画',
        'ITEM_FRAME': '物品展示框',
        'GLOW_ITEM_FRAME': '荧光物品展示框',
        'ARMOR_STAND': '盔甲架',
        'SKELETON_SKULL': '骷髅头颅',
        'WITHER_SKELETON_SKULL': '凋灵骷髅头颅',
        'ZOMBIE_HEAD': '僵尸的头',
        'PLAYER_HEAD': '玩家头颅',
        'CREEPER_HEAD': '爬行者头颅',
        'DRAGON_HEAD': '龙首',
        'SHULKER_BOX': '潜影盒',
        'WHITE_SHULKER_BOX': '白色潜影盒',
        'WHITE_CONCRETE_POWDER': '白色混凝土粉末',
        'TUBE_CORAL_BLOCK': '管珊瑚块',
        'BRAIN_CORAL_BLOCK': '脑纹珊瑚块',
        'BUBBLE_CORAL_BLOCK': '气泡珊瑚块',
        'FIRE_CORAL_BLOCK': '火珊瑚块',
        'HORN_CORAL_BLOCK': '鹿角珊瑚块',
        'SPONGE': '海绵',
        'WET_SPONGE': '湿海绵',
        'SLIME_BLOCK': '黏液块',
        'HONEY_BLOCK': '蜂蜜块',
        'BEE_NEST': '蜂巢',
        'BEEHIVE': '蜂箱',
        'HONEYCOMB_BLOCK': '蜜脾块',
        'OXIDIZED_COPPER': '氧化的铜块',
        'WEATHERED_COPPER': '斑驳的铜块',
        'EXPOSED_COPPER': '外露的铜块',
        'CUT_COPPER': '切制铜块',
        'FLOWERING_AZALEA': '盛开的杜鹃树叶',
        'MOSS_BLOCK': '苔藓块',
        'MOSS_CARPET': '覆地苔藓',
        'GLOW_LICHEN': '发光地衣',
        'SCULK': '幽匿块',
        'SCULK_CATALYST': '幽匿催发体',
        'SCULK_SHRIEKER': '幽匿尖啸体',
        'SCULK_SENSOR': '幽匿感测体',
        'REINFORCED_DEEPSLATE': '强化深板岩',
        'OCHRE_FROGLIGHT': '赭黄蛙明灯',
        'VERDANT_FROGLIGHT': '翠绿蛙明灯',
        'PEARLESCENT_FROGLIGHT': '珠光蛙明灯',
        'BAMBOO_BLOCK': '竹块',
        'STRIPPED_BAMBOO_BLOCK': '去皮竹块',
        'OAK_HANGING_SIGN': '橡木悬挂式告示牌',
        'SMITHING_TABLE': '锻造台',
        'CARTOGRAPHY_TABLE': '制图台',
        'FLETCHING_TABLE': '制箭台',
        'LOOM': '织布机',
        'GRINDSTONE': '砂轮',
        'COMPOSTER': '堆肥桶',
        'CAULDRON': '炼药锅',
        'LAVA_CAULDRON': '装有岩浆的炼药锅',
        'WATER_CAULDRON': '装有水的炼药锅',
        'POWDER_SNOW_CAULDRON': '装有细雪的炼药锅',
        'FLOWER_POT': '花盆',
        'CAKE': '蛋糕',
        'DRAGON_WALL_HEAD': '墙上的龙首',
        'END_CRYSTAL': '末影水晶',
        'RESPAWN_ANCHOR': '重生锚',
        'COPPER_BULB': '铜灯',
        'TRIAL_SPAWNER': '试炼刷怪笼',
        'VAULT': '宝库',
        'HEAVY_CORE': '沉重核心',
        'PALE_OAK_LOG': '苍白橡木原木',
        'PALE_OAK_LEAVES': '苍白橡树树叶',
        'PALE_MOSS_BLOCK': '苍白苔藓块',
        'PALE_HANGING_MOSS': '苍白垂须',
        'CREAKING_HEART': '嘎枝之心',
        'RESIN_CLUMP': '树脂团',
        'RESIN_BLOCK': '树脂块',
        'EYEBLOSSOM': '眼眸花',
        'OPEN_EYEBLOSSOM': '张开的眼眸花',
        'CLOSED_EYEBLOSSOM': '闭合的眼眸花',
        'PALE_OAK_WOOD': '苍白橡木',
        'PALE_OAK_PLANKS': '苍白橡木木板',
        'STRIPPED_PALE_OAK_LOG': '去皮苍白橡木原木',
        'STRIPPED_PALE_OAK_WOOD': '去皮苍白橡木',
        'MANGROVE_ROOTS': '红树根',
        'MUDDY_MANGROVE_ROOTS': '沾泥的红树根',
        'PINK_PETALS': '粉红色花簇',
        'WILDFLOWERS': '野花簇',
        'LEAF_LITTER': '落叶',
        'FIREFLY_BUSH': '萤火虫灌木丛',
        'SHORT_DRY_GRASS': '矮枯草丛',
        'TALL_DRY_GRASS': '高枯草丛',
        'BUSH': '灌木丛',
        'CACTUS_FLOWER': '仙人掌花',
        'CHISELED_RESIN_BRICKS': '雕纹树脂砖',
        'RESIN_BRICKS': '树脂砖',
        'RESIN_BRICK_SLAB': '树脂砖台阶',
        'RESIN_BRICK_STAIRS': '树脂砖楼梯',
        'RESIN_BRICK_WALL': '树脂砖墙'
    };

    return names[matName] || matName;
}


// ==================== 权限检查函数 ====================
function hasPermission(player, location) {
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) {
        return true;
    }
    var Slimefun = Java.type('io.github.thebusybiscuit.slimefun4.implementation.Slimefun');
    var Interaction = Java.type('io.github.thebusybiscuit.slimefun4.libraries.dough.protection.Interaction');
    var pm = Slimefun.getProtectionManager();
    return pm.hasPermission(player, location, Interaction.BREAK_BLOCK) &&
        pm.hasPermission(player, location, Interaction.INTERACT_BLOCK);
}