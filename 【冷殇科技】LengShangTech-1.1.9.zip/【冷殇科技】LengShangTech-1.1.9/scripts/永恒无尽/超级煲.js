function onUse(event) { 
    // 获取触发事件的玩家对象
    var player = event.getPlayer();

    // 获取玩家的背包对象
    var inv = player.getInventory();

    // 获取玩家主手（右手）持有的物品
    var itemInMainHand = inv.getItemInMainHand();

    // 获取玩家副手（左手）持有的物品
    var offHandItem = inv.getItemInOffHand();

    // 【限制1】如果玩家当前饱食度已满（最大值为20），则无法进食
    if (player.getFoodLevel() >= 20) {
        return; // 直接返回，不执行后续逻辑
    }

    // 【限制2】如果副手持有粘液科技（Slimefun）物品，禁止食用
    // SlimefunItem.getByItem() 不为 null 说明该物品是 Slimefun 物品
    if (offHandItem != null && SlimefunItem.getByItem(offHandItem) != null) {
        player.sendMessage("您必须使用主手进食且副手不能持有粘液科技物品！");
        return; // 发送提示后终止
    }

    // 【核心逻辑】判断主手是否有物品，且数量大于 0
    if (itemInMainHand != null && itemInMainHand.getAmount() > 0) {
        var amount = 1; // 定义每次消耗的数量

        // 扣除主手物品数量（消耗 1 个）
        itemInMainHand.setAmount(itemInMainHand.getAmount() - amount);

        // 恢复饱食度（Food Level）+20，即直接回满
        player.setFoodLevel(player.getFoodLevel() + 20);

        // 恢复饱和度（Saturation）+20，延长饱食度下降时间
        player.setSaturation(player.getSaturation() + 20);

        // 降低消耗度（Exhaustion）-2，进一步减缓饥饿速度
        player.setExhaustion(player.getExhaustion() - 2);

        // ==================== 新增：药水效果 ====================
        // 导入 Bukkit 药水效果相关类
        var PotionEffect = Java.type("org.bukkit.potion.PotionEffect");
        var PotionEffectType = Java.type("org.bukkit.potion.PotionEffectType");
        var NamespacedKey = Java.type("org.bukkit.NamespacedKey");

        // 【修正】GraalJS 无法直接访问 PotionEffectType 的静态字段（如 SPEED）
        // 在 1.20.5+ 版本中，必须使用 getByKey(NamespacedKey) 方式获取效果类型
        // 参数说明: new PotionEffect(效果类型, 持续时间tick, 等级-1)
        // 20 ticks = 1秒

        // 1. 迅捷 III —— 3分 = 180秒 (3600 ticks)，amplifier=2 对应 III 级
        // Minecraft ID: "speed"
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByKey(NamespacedKey.minecraft("speed")), 3600, 2));

        // 2. 急迫 III —— 3分 = 180秒 (3600 ticks)，amplifier=2 对应 III 级
        // Minecraft ID: "haste"
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByKey(NamespacedKey.minecraft("haste")), 3600, 2));

        // 3. 跳跃提升 III —— 3分 = 180秒 (3600 ticks)，amplifier=2 对应 III 级
        // Minecraft ID: "jump_boost"
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByKey(NamespacedKey.minecraft("jump_boost")), 3600, 2));

        // 4. 力量 V —— 5分 = 300秒 (6000 ticks)，amplifier=4 对应 V 级
        // Minecraft ID: "strength"
        player.addPotionEffect(new PotionEffect(PotionEffectType.getByKey(NamespacedKey.minecraft("strength")), 6000, 4));
        // =======================================================

        // 定义要播放的音效名称：炽足兽进食声
        var soundName = "entity.strider.eat";

        // 在玩家所在位置播放音效
        // 参数说明：位置、音效名、音量(1.0)、音调(1.0)
        player.getLocation().getWorld().playSound(player.getLocation(), soundName, 1.0, 1.0);
    }
}