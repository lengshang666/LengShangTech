// ============================================
// 天堂陨落长弓、重箭王、修罗·灭世神弓
// ============================================

// ========== 通用工具函数 ==========

/**
 * 检查玩家主手是否持有指定Slimefun物品
 * @param {Player} player - 玩家
 * @param {string} slimefunItemId - Slimefun物品ID
 * @returns {boolean} - 是否匹配
 */
function handleItemInMainHand(player, slimefunItemId) {
  let itemInMainHand = player.getInventory().getItemInMainHand();
  let sfItem = getSfItemByItem(itemInMainHand);
  if (sfItem !== null) {
    return slimefunItemId === sfItem.getId();
  }
  return false;
}

// ========== 冷却系统通用模板 ==========

// 存储各弓的冷却时间（毫秒）
const COOLDOWN_CONFIG = {
  "arrowRain": 5000,    // 天堂陨落长弓 5秒
  "lightning": 5000    // 修罗·灭世神弓 5秒
};

// 统一冷却存储
const cooldowns = new java.util.HashMap();

/**
 * 检查指定类型的冷却
 * @param {Player} player - 玩家
 * @param {string} type - 冷却类型
 * @returns {boolean} - true表示冷却结束
 */
function checkCooldown(player, type) {
  let key = player.getUniqueId() + "_" + type;
  let currentTime = Date.now();
  let lastTime = cooldowns.get(key);
  if (lastTime === null || lastTime === undefined) return true;
  return (currentTime - lastTime) >= COOLDOWN_CONFIG[type];
}

/**
 * 设置指定类型的冷却
 * @param {Player} player - 玩家
 * @param {string} type - 冷却类型
 */
function setCooldown(player, type) {
  let key = player.getUniqueId() + "_" + type;
  cooldowns.put(key, Date.now());
}

/**
 * 获取剩余冷却时间（秒）
 * @param {Player} player - 玩家
 * @param {string} type - 冷却类型
 * @returns {number} - 剩余秒数（向上取整）
 */
function getRemainingCooldownSeconds(player, type) {
  let key = player.getUniqueId() + "_" + type;
  let lastTime = cooldowns.get(key);
  if (lastTime === null || lastTime === undefined) return 0;
  let remaining = COOLDOWN_CONFIG[type] - (Date.now() - lastTime);
  if (remaining <= 0) return 0;
  return Math.ceil(remaining / 1000);
}

// ========== 天堂陨落长弓 ==========

function arrowRainBow(player, event) {
  if (!checkCooldown(player, "arrowRain")) {
    let remaining = getRemainingCooldownSeconds(player, "arrowRain");
    player.sendMessage("§c[箭雨·天罚] §7技能冷却中，还需 §c" + remaining + " §7秒");
    return;
  }
  setCooldown(player, "arrowRain");

  let arrow = event.getProjectile();
  let hasLanded = false;
  let rainCount = 0;
  let maxRainWaves = 3;
  let arrowsPerWave = 15;

  runRepeating((t) => {
    if (rainCount >= maxRainWaves) {
      arrow.remove();
      t.cancel();
      return;
    }

    if ((arrow.isInBlock() || arrow.isDead()) && !hasLanded) {
      hasLanded = true;
      let landLocation = arrow.getLocation().clone();
      let world = landLocation.getWorld();

      world.spawnParticle(org.bukkit.Particle.END_ROD, landLocation, 30, 2, 0.5, 2, 0.05);
      world.playSound(landLocation, "block.note_block.pling", 1.0, 2.0);

      startArrowRain(world, landLocation, player, arrowsPerWave, maxRainWaves);

      if (!arrow.isDead()) arrow.remove();
      t.cancel();
    }
  }, 10, 2);
}

function startArrowRain(world, center, shooter, arrowsPerWave, maxWaves) {
  let currentWave = 0;
  runRepeating((t) => {
    if (currentWave >= maxWaves) {
      t.cancel();
      return;
    }
    spawnArrowWave(world, center, shooter, arrowsPerWave, currentWave);
    currentWave++;
    if (currentWave >= maxWaves) {
      world.playSound(center, "entity.arrow.hit_player", 1.0, 0.8);
      world.spawnParticle(org.bukkit.Particle.CRIT, center, 50, 3, 1, 3, 0.5);
      t.cancel();
    }
  }, 8, 8);
}

function spawnArrowWave(world, center, shooter, count, waveIndex) {
  let spreadRadius = 3.0 + (waveIndex * 0.5);
  world.playSound(center, "entity.arrow.shoot", 0.8, 0.6 + (Math.random() * 0.4));

  for (let i = 0; i < count; i++) {
    let offsetX = (Math.random() - 0.5) * 2 * spreadRadius;
    let offsetZ = (Math.random() - 0.5) * 2 * spreadRadius;
    let targetLoc = center.clone().add(offsetX, 0, offsetZ);
    let spawnY = center.getY() + 20 + (Math.random() * 10);
    let spawnLoc = targetLoc.clone();
    spawnLoc.setY(spawnY);

    let direction = new org.bukkit.util.Vector(0, -1, 0);
    direction.setX((Math.random() - 0.5) * 0.3);
    direction.setZ((Math.random() - 0.5) * 0.3);
    direction.normalize();

    let spawnedArrow = world.spawnArrow(spawnLoc, direction, 2.5 + Math.random(), 0);
    spawnedArrow.setShooter(shooter);
    spawnedArrow.setCritical(true);
    spawnedArrow.setDamage(4.0 + (waveIndex * 0.5));
    spawnedArrow.setFireTicks(100);
    spawnedArrow.setPickupStatus(org.bukkit.entity.AbstractArrow.PickupStatus.CREATIVE_ONLY);
  }

  world.spawnParticle(org.bukkit.Particle.WHITE_ASH, center, 20, spreadRadius, 0.5, spreadRadius, 0.1);
}

// ========== 重箭王 ==========

function sanshegong(player, event) {
  let force = event.getForce() * 4;
  let world = player.getWorld();
  let eyeLocation = player.getEyeLocation();
  let direction = eyeLocation.getDirection();

  for (let i = 0; i < 10; i++) {
    world.spawnArrow(eyeLocation, direction, force, 10);
  }
}

// ========== 修罗·灭世神弓 ==========

function lightningBow(player, event) {
  if (!checkCooldown(player, "lightning")) {
    let remaining = getRemainingCooldownSeconds(player, "lightning");
    player.sendMessage("§c[修罗·灭世神弓] §7技能冷却中，还需 §c" + remaining + " §7秒");
    return;
  }
  setCooldown(player, "lightning");

  let arrow = event.getProjectile();
  let hasStruck = false;
  let strikeCount = 0;
  let maxStrikes = 5;

  runRepeating((t) => {
    if (strikeCount >= maxStrikes) {
      hasStruck = true;
      arrow.remove();
      t.cancel();
      return;
    }

    if ((arrow.isInBlock() || arrow.isDead()) && !hasStruck) {
      hasStruck = true;
      let location = arrow.getLocation();
      let world = location.getWorld();
      performLightningStrike(world, location, player, strikeCount);
      strikeCount++;
      if (arrow.isDead()) arrow.remove();
      return;
    }

    if (hasStruck && strikeCount < maxStrikes) {
      let location = arrow.getLocation();
      let world = location.getWorld();
      let offsetX = (Math.random() - 0.5) * 6;
      let offsetZ = (Math.random() - 0.5) * 6;
      let strikeLoc = location.clone().add(offsetX, 0, offsetZ);
      performLightningStrike(world, strikeLoc, player, strikeCount);
      strikeCount++;
    }

    if (strikeCount >= maxStrikes) {
      t.cancel();
    }
  }, 10, 1);
}

function performLightningStrike(world, location, player, strikeIndex) {
  world.strikeLightning(location);

  let explosionPower = 2.0 + (strikeIndex * 0.5);
  world.createExplosion(location, explosionPower, true, false);

  let radius = 4 + strikeIndex;
  let nearbyEntities = world.getNearbyEntities(location, radius, radius, radius);

  for (let i = 0; i < nearbyEntities.size(); i++) {
    let entity = nearbyEntities.get(i);
    if (entity === player) continue;

    if (entity instanceof org.bukkit.entity.LivingEntity) {
      let damage = 6.0 + (strikeIndex * 2.0);
      entity.damage(damage, player);
      entity.setFireTicks(100 + (strikeIndex * 20));

      let knockback = entity.getLocation().toVector()
        .subtract(location.toVector())
        .normalize()
        .multiply(1.5 + strikeIndex * 0.3)
        .setY(0.5);
      entity.setVelocity(knockback);

      entity.addPotionEffect(new org.bukkit.potion.PotionEffect(
        org.bukkit.potion.PotionEffectType.SLOWNESS,
        60 + strikeIndex * 20, 2
      ));
      entity.addPotionEffect(new org.bukkit.potion.PotionEffect(
        org.bukkit.potion.PotionEffectType.BLINDNESS,
        40 + strikeIndex * 10, 0
      ));
    }
  }

  world.spawnParticle(org.bukkit.Particle.ELECTRIC_SPARK, location, 20, 2, 2, 2, 1);
  world.spawnParticle(org.bukkit.Particle.FLAME, location, 10, 1, 1, 1, 0.1);
  world.playSound(location, "entity.lightning_bolt.thunder", 1.0, 1.0);
}

// ========== 弓箭事件主入口 ==========

function onEntityShootBow(e) {
  let entity = e.getEntity();
  if (!(entity instanceof org.bukkit.entity.Player)) {
    return;
  }
  let player = entity;

  if (handleItemInMainHand(player, "LENGSHANG_天堂陨落长弓")) {
    arrowRainBow(player, e);
  } else if (handleItemInMainHand(player, "LENGSHANG_重箭王")) {
    sanshegong(player, e);
  } else if (handleItemInMainHand(player, "LENGSHANG_修罗·灭世神弓")) {
    lightningBow(player, e);
  }
}