const DISPLAY_NAME = '§6';
const COOLDOWN_MS = 200;
const cdMap = new java.util.HashMap();

function getRandomSlimefunItem() {
    try {
        var Slimefun = Packages.io.github.thebusybiscuit.slimefun4.implementation.Slimefun;
        var registry = Slimefun.getRegistry();
        var items = registry.getAllSlimefunItems();
        var list = new java.util.ArrayList();
        var iter = items.iterator();
        while (iter.hasNext()) {
            var item = iter.next();
            if (item != null && item.getId() != null) {
                list.add(item);
            }
        }
        if (list.isEmpty()) return null;
        var idx = Math.floor(Math.random() * list.size());
        return list.get(idx).getItem().clone();
    } catch (e) {
        return null;
    }
}

function onUse(evt) {
    var player = evt.getPlayer();
    var uuid = player.getUniqueId().toString();
    var now = Date.now();

    var allowed = ["lengshang", "xiu", "HeartMxe", "47_Forever", "MuYan", "JodgDoemr", "jiangdonganxia", "zzzzq", "DaX1u", "SuiXing", "laizi123", "laizi", "Tian_Yi", "Cang_Yan"];
    var pName = player.getName();
    var ok = false;
    for (var i = 0; i < allowed.length; i++) {
        if (pName === allowed[i]) { ok = true; break; }
    }
    if (!ok) return;

    if (cdMap.containsKey(uuid)) {
        if (now - cdMap.get(uuid) < COOLDOWN_MS) {
            player.sendActionBar("§7冷却中...");
            return;
        }
    }
    cdMap.put(uuid, now);

    var dropItem = getRandomSlimefunItem();
    if (dropItem == null) {
        player.sendMessage("§c物品列表为空！");
        return;
    }

    var loc = player.getLocation().add(0, 1.5, 0);
    player.getWorld().dropItemNaturally(loc, dropItem);

    var meta = dropItem.getItemMeta();
    var name = (meta != null && meta.hasDisplayName()) ? meta.getDisplayName() : dropItem.getType().name();
    player.sendMessage("§a✦ 随机掉落: §e" + name);
}

function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            var action = evt.getAction().name();
            if (action != "RIGHT_CLICK_AIR" && action != "RIGHT_CLICK_BLOCK") return;
            if (evt.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

            var item = evt.getPlayer().getInventory().getItemInMainHand();
            if (item == null || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() != DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();

function tick(info) { }
function onOpen(player) { }
function onClick(player, slot, slotItem, clickAction) { }
function onClose(player) { }