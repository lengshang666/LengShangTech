// ======================================================
// 唤雷符
// 功能：
// - 清除晴天，设置雷雨 5 分钟
// - 冷却：3 分钟（3600 tick）
// - 当天已经是雷雨时不生效、不消耗、不进入冷却
// ======================================================

// ===== Java 类型 =====
const Effect = Java.type("org.bukkit.Effect");
const Bukkit = Java.type("org.bukkit.Bukkit");
const HashMap = Java.type("java.util.HashMap");
// 导入 Bukkit API 类

// ===== Slimefun 物品 ID =====
const ITEM_ID = "LENGSHANG_唤雷符";
// 该物品在 Slimefun 中的唯一标识符

// ===== 冷却时间（tick）=====
const COOLDOWN_TICKS = 3 * 60 * 20; // 3600 tick
// 3 分钟 = 180 秒 = 3600 ticks（20 ticks/秒）

// 玩家冷却记录
// key: UUID（String）
// value: 上次使用 tick
var cooldownMap = new HashMap();
// Java HashMap，使用服务器 tick 计时

function onUse(event) {

    var player = event.getPlayer();
    if (!player) return;
    // 获取玩家，为空则不处理

    var item = event.getItem();
    if (!item || item.getType().isAir()) return;
    // 物品为空或空气，不处理

    // ===== 校验 Slimefun 物品 =====
    var optional = event.getSlimefunItem();
    if (!optional.isPresent()) return;
    // 不是 Slimefun 物品，不处理

    var sfItem = optional.get();
    if (sfItem.getId() !== ITEM_ID) return;
    // ID 不是 FVV_THUNDER_RUNE，不处理

    var world = player.getWorld();
    // 获取玩家所在世界

    // ==================================================
    // 已雷雨判断（不生效、不消耗、不冷却）
    // ==================================================
    if (world.hasStorm() && world.isThundering()) {
        // 同时满足：正在降雨 AND 正在雷暴
        // hasStorm() → 是否下雨（包括普通雨和雷雨）
        // isThundering() → 是否有雷电（只有雷雨才为 true）
        
        player.sendMessage("§7天空已经在雷雨，无需使用§e唤雷符§7。");
        // §7 = 灰色（无操作提示）, §e = 黄色（物品名高亮）
        
        return;
        // 直接返回，不消耗、不计入冷却
    }

    // ==================================================
    // 冷却判断（基于服务器 tick）
    // ==================================================
    var uuid = player.getUniqueId().toString();
    var nowTick = Bukkit.getCurrentTick();
    // 获取服务器当前总 tick 数

    if (cooldownMap.containsKey(uuid)) {
        var lastTick = cooldownMap.get(uuid);
        var remain = COOLDOWN_TICKS - (nowTick - lastTick);
        // 计算剩余冷却 tick

        if (remain > 0) {
            player.sendMessage(
                "§c唤雷符冷却中，剩余 §e" + Math.ceil(remain / 20) + "§c 秒"
            );
            // §c = 红色（冷却提示）, §e = 黄色（秒数高亮）
            
            return;
        }
    }

    // ==================================================
    // 天气控制
    // ==================================================
    world.setClearWeatherDuration(0);
    // 清除晴天持续时间
    
    world.setWeatherDuration(6000);
    // 降雨/雷暴持续时间 6000 ticks = 5 分钟
    
    world.setStorm(true);
    // 开启降雨
    
    world.setThundering(true);
    // 开启雷暴（与 RAINRUNE 的关键区别：true 而非 false）

    // 客户端刷新
    world.playEffect(player.getLocation(), Effect.SMOKE, 1);
    // 烟雾效果，模拟施法

    // ==================================================
    // 提示 & 声音（字符串格式）
    // ==================================================
    player.sendMessage("§b你使用了§e唤雷符§b，风云突变，电闪雷鸣！");
    // §b = 青色（主题色）, §e = 黄色（物品名）
    
    player.playSound(
        player.getLocation(), 
        "entity.lightning_bolt.thunder", 
        1.0, 
        1.0
    );
    // 播放雷电音效，与唤雨符的 weather.rain 不同，更有冲击力

    // ==================================================
    // 消耗物品（主手）
    // ==================================================
    var inv = player.getInventory();
    var mainHand = inv.getItemInMainHand();

    if (mainHand && !mainHand.getType().isAir()) {
        if (mainHand.getAmount() > 1) {
            mainHand.setAmount(mainHand.getAmount() - 1);
            inv.setItemInMainHand(mainHand);
        } else {
            inv.setItemInMainHand(null);
        }
    }

    // ==================================================
    // 写入冷却
    // ==================================================
    cooldownMap.put(uuid, nowTick);
    // 记录本次使用 tick，开始 3 分钟冷却
}