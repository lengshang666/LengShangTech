// ============================================
// 人造实体配置表
// 作用：定义"哪个 Slimefun 物品ID"对应"召唤哪种实体"
// 这是一个数组，每个元素是一个对象，包含 id 和 entityType 两个属性
// ============================================
const ARTIFICIAL_ENTITIES = [
  { 
    id: "LENGSHANG_巨人刷怪蛋",  // Slimefun 物品的唯一标识ID，对应YML配置里的 id
    entityType: Java.type('org.bukkit.entity.EntityType').GIANT  // 召唤的实体类型：巨人（Giant）
  }
];

// ============================================
// onUse 函数：玩家右键使用物品时触发
// event: 使用事件对象，包含玩家、物品、点击位置等信息
// itemStack: 使用的物品（RSC自动传入）
// ============================================
function onUse(event, itemStack) {
  
  // -----------------------------------------
  // 获取使用物品的玩家对象
  // -----------------------------------------
  let player = event.getPlayer();
  
  // -----------------------------------------
  // 主手使用检查
  // event.getHand() 返回玩家使用的是哪只手
  // EquipmentSlot.HAND = 主手，EquipmentSlot.OFF_HAND = 副手
  // -----------------------------------------
  if (event.getHand() !== org.bukkit.inventory.EquipmentSlot.HAND) {
    // 如果不是主手使用，发送红色提示信息并直接返回，不执行后续代码
    player.sendMessage("§c请主手持有相应物品");
    return;  // 结束函数，阻止副手触发
  }
  
  // -----------------------------------------
  // 获取当前使用的物品对象
  // event.getItem() 返回玩家手中的原版 ItemStack
  // -----------------------------------------
  let onUseItem = event.getItem();
  
  // -----------------------------------------
  // 获取对应的 Slimefun 物品对象
  // getSfItemByItem() 是 RSC 提供的函数，将原版物品转为 Slimefun 物品
  // 这样才能获取到 Slimefun 的物品ID
  // -----------------------------------------
  let sfItem = getSfItemByItem(onUseItem);
  
  // -----------------------------------------
  // 获取该 Slimefun 物品的唯一ID
  // 例如 "WT_JURENWAN"
  // -----------------------------------------
  let sfItemId = sfItem.getId();
  
  // -----------------------------------------
  // 在配置表中查找匹配的实体配置
  // .find() 方法遍历数组，返回第一个满足条件的元素
  // entity => entity.id === sfItemId 是查找条件：配置项的id等于当前物品id
  // 如果找不到，entityConfig 为 undefined
  // -----------------------------------------
  let entityConfig = ARTIFICIAL_ENTITIES.find(entity => entity.id === sfItemId);
  
  // -----------------------------------------
  // 如果没找到匹配的配置，直接结束
  // 防止其他无关物品误触发此脚本
  // -----------------------------------------
  if (!entityConfig) {
    return;  // 结束函数
  }
  
  // -----------------------------------------
  // 消耗物品：数量减1
  // event.getItem() 再次获取物品（也可以直接用上面的 onUseItem）
  // setAmount() 设置物品数量，getAmount() 获取当前数量
  // 减到0时物品会自动从手中消失
  // -----------------------------------------
  let item = event.getItem();
  item.setAmount(item.getAmount() - 1);
  
  // -----------------------------------------
  // 确定召唤位置
  // player.getTargetBlock(null, 5)：获取玩家视线前方5格内准星瞄准的方块
  // null 表示不忽略任何方块类型（即所有方块都能被瞄准）
  // 5 表示最大检测距离5格
  // -----------------------------------------
  let block = player.getTargetBlock(null, 5);
  
  // -----------------------------------------
  // 计算实体生成的精确位置
  // block.getLocation() 获取方块的位置（坐标在方块角落）
  // .add(0, 1, 0) 在Y轴（高度）上加1，即方块正上方一格
  // 这样实体不会卡在方块里面
  // -----------------------------------------
  let location = block.getLocation().add(0, 1, 0);
  
  // -----------------------------------------
  // 获取位置所在的世界对象
  // 世界对象负责管理实体生成、方块放置等世界操作
  // -----------------------------------------
  let world = location.getWorld();
  
  // -----------------------------------------
  // 在指定位置召唤实体
  // world.spawnEntity(位置, 实体类型)
  // entityConfig.entityType 从配置表中取出对应的实体类型（这里是巨人）
  // 返回生成的实体对象（这里没保存返回值，所以无法后续操作该实体）
  // -----------------------------------------
  world.spawnEntity(location, entityConfig.entityType);
  
}  // onUse 函数结束