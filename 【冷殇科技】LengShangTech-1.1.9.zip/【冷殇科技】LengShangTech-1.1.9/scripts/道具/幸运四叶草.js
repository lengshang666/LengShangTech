const DISPLAY_NAME = '§a幸运四叶草';
const COOLDOWN_MS = 500;
const cdMap = new java.util.HashMap();

// 黑名单物品 - 不允许随机出的特殊方块
const BLACKLIST = [
    "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK",
    "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW",
    "BARRIER", "LIGHT",
    "SPAWNER", "TRIAL_SPAWNER",
    "END_PORTAL_FRAME",
    "DEBUG_STICK", "KNOWLEDGE_BOOK",
    "COMMAND_BLOCK_MINECART"
];

function isBlacklisted(matName) {
    for (var i = 0; i < BLACKLIST.length; i++) {
        if (matName == BLACKLIST[i]) return true;
    }
    return false;
}

function getRandomMaterial() {
    try {
        var Material = Packages.org.bukkit.Material;
        var materials = Material.values();
        var valid = [];
        for (var i = 0; i < materials.length; i++) {
            var mat = materials[i];
            var matName = mat.name();
            // 排除空气
            if (mat == Material.AIR || mat == Material.CAVE_AIR || mat == Material.VOID_AIR) continue;
            // 排除旧版兼容物品
            if (matName.indexOf("LEGACY_") !== -1) continue;
            // 只保留可以作为物品持有的材料
            if (!mat.isItem()) continue;
            // 排除黑名单
            if (isBlacklisted(matName)) continue;
            valid.push(mat);
        }
        if (valid.length === 0) return null;
        var idx = Math.floor(Math.random() * valid.length);
        return valid[idx];
    } catch (e) {
        return null;
    }
}

function consumeItem(player) {
    var inv = player.getInventory();
    var mainHand = inv.getItemInMainHand();
    if (mainHand == null || mainHand.getType().name() == "AIR") return false;

    var amount = mainHand.getAmount();
    if (amount <= 1) {
        inv.setItemInMainHand(null);
    } else {
        mainHand.setAmount(amount - 1);
    }
    return true;
}

function onUse(evt) {
    var player = evt.getPlayer();
    var uuid = player.getUniqueId().toString();
    var now = Date.now();

    if (cdMap.containsKey(uuid)) {
        if (now - cdMap.get(uuid) < COOLDOWN_MS) {
            // 冷却提示改到屏幕中间（Action Bar）
            player.sendActionBar("§7冷却中...");
            return;
        }
    }
    cdMap.put(uuid, now);

    // 消耗物品
    if (!consumeItem(player)) {
        return;
    }

    var material = getRandomMaterial();
    if (material == null) {
        // 失败也不提示，静默处理
        return;
    }

    var ItemStack = Packages.org.bukkit.inventory.ItemStack;
    var dropItem = new ItemStack(material, 1);

    var loc = player.getLocation().add(0, 1.5, 0);
    player.getWorld().dropItemNaturally(loc, dropItem);

    // 不发送任何掉落成功提示
}

function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            var action = evt.getAction().name();
            if (action != "RIGHT_CLICK_AIR" && action != "RIGHT_CLICK_BLOCK") return;
            if (evt.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

            var item = evt.getPlayer().getInventory().getItemInMainHand();
            if (item == null || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() != DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();

function tick(info) { }
function onOpen(player) { }
function onClick(player, slot, slotItem, clickAction) { }
function onClose(player) { }