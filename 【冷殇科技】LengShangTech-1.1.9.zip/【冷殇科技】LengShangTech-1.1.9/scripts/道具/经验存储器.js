// ========== 经验存储器 ==========
// 蹲下+右键：存储一级经验（按经验值计算）
// 右键：取出经验，提升一级

let Bukkit = Java.type('org.bukkit.Bukkit');
let ChatColor = Java.type('org.bukkit.ChatColor');
let NamespacedKey = Java.type('org.bukkit.NamespacedKey');
let PersistentDataType = Java.type('org.bukkit.persistence.PersistentDataType');
let Sound = Java.type('org.bukkit.Sound');

// 配置
const EXP_LORE_PREFIX = "§a已存储经验值: §f";
const CAPACITY = 999999999999; // 最大存储经验值
const COOLDOWN_MS = 500;

const cdMap = new Map();

function onUse(event) {
    const player = event.getPlayer();
    const item = event.getItem();

    if (!item || item.getType().isAir()) {
        player.sendMessage("§c❌ 请手持经验存储器");
        event.cancel();
        return;
    }

    // 确保是主手
    if (event.getHand().toString() !== "HAND") return;

    // 获取存储的经验值
    const storedExp = getStoredExp(item);

    // 蹲下 + 右键 = 存储一级经验
    if (player.isSneaking()) {
        event.cancel();
        handleStoreExp(player, item, storedExp);
        return;
    }

    // 右键 = 取出经验，提升一级
    event.cancel();
    handleRetrieveExp(player, item, storedExp);
}

/**
 * 存储一级经验（蹲下+右键）
 * 按照经验值计算，不是等级
 */
function handleStoreExp(player, item, storedExp) {
    const currentLevel = player.getLevel();
    const currentExpProgress = player.getExp(); // 0.0 ~ 1.0

    // 计算当前等级升到下一级需要的经验值
    const expToNext = getExpToNextLevel(currentLevel);

    // 计算玩家当前总经验值
    const currentTotalExp = getTotalExperience(player);

    // 检查是否有足够的经验值存储一级
    if (currentTotalExp < expToNext) {
        player.sendMessage("§c❌ 你的经验不足以存储一级！");
        playSound(player, Sound.ENTITY_VILLAGER_NO, 1.0, 1.0);
        return;
    }

    // 检查容量
    if (storedExp + expToNext > CAPACITY) {
        player.sendMessage("§c❌ 经验存储器已满！");
        playSound(player, Sound.ENTITY_VILLAGER_NO, 1.0, 1.0);
        return;
    }

    // 扣除玩家经验值
    // 使用 giveExp 负数来扣除
    player.giveExp(-expToNext);

    // 更新存储值
    const newStored = storedExp + expToNext;
    setStoredExp(item, newStored);

    player.sendMessage("§a✅ 成功存储 §f" + expToNext + " §a点经验值！");
    player.sendMessage("§7当前等级: §f" + player.getLevel() + " §7级");
    player.sendMessage("§7存储器中: §f" + newStored + " §7点经验");
    playSound(player, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0, 1.5);
}

/**
 * 取出经验，提升一级（右键）
 */
function handleRetrieveExp(player, item, storedExp) {
    if (storedExp <= 0) {
        player.sendMessage("§c❌ 经验存储器是空的！");
        playSound(player, Sound.ENTITY_VILLAGER_NO, 1.0, 1.0);
        return;
    }

    const currentLevel = player.getLevel();

    // 计算当前等级升到下一级需要的经验值
    const expToNext = getExpToNextLevel(currentLevel);

    // 检查存储器中是否有足够的经验值来升一级
    if (storedExp < expToNext) {
        player.sendMessage("§c❌ 存储器中经验不足，无法提升一级！");
        player.sendMessage("§7需要: §f" + expToNext + " §7点，当前: §f" + storedExp + " §7点");
        playSound(player, Sound.ENTITY_VILLAGER_NO, 1.0, 1.0);
        return;
    }

    // 从存储器中扣除经验值
    const newStored = storedExp - expToNext;
    setStoredExp(item, newStored);

    // 给玩家增加经验（提升一级）
    player.giveExp(expToNext);

    player.sendMessage("§a✅ 等级提升成功！");
    player.sendMessage("§7本次消耗: §f" + expToNext + " §7点经验值");
    player.sendMessage("§7存储器中剩余: §f" + newStored + " §7点经验");
    playSound(player, Sound.ENTITY_PLAYER_LEVELUP, 0.5, 1.0);
}

// ==================== 经验值计算 ====================

/**
 * 获取玩家总经验值
 */
function getTotalExperience(player) {
    const level = player.getLevel();
    const expProgress = player.getExp(); // 0.0 ~ 1.0

    // 计算到当前等级为止的总经验值
    let total = getTotalExpToLevel(level);

    // 加上当前等级内的进度经验
    const expToNext = getExpToNextLevel(level);
    total += Math.floor(expProgress * expToNext);

    return total;
}

/**
 * 获取升到指定等级需要的总经验值
 */
function getTotalExpToLevel(level) {
    if (level <= 16) {
        return level * level + 6 * level;
    } else if (level <= 31) {
        return Math.floor(2.5 * level * level - 40.5 * level + 360);
    } else {
        return Math.floor(4.5 * level * level - 162.5 * level + 2220);
    }
}

/**
 * 获取当前等级升到下一级需要的经验值
 */
function getExpToNextLevel(level) {
    if (level <= 15) {
        return 2 * level + 7;
    } else if (level <= 30) {
        return 5 * level - 38;
    } else {
        return 9 * level - 158;
    }
}

// ==================== 数据存储 ====================

/**
 * 获取存储的经验值（从 Lore 读取）
 */
function getStoredExp(item) {
    if (!item || !item.hasItemMeta()) return 0;
    const meta = item.getItemMeta();
    const lore = meta.getLore();
    if (!lore) return 0;

    for (let i = 0; i < lore.size(); i++) {
        const line = lore.get(i);
        if (line.startsWith(EXP_LORE_PREFIX)) {
            const numStr = line.substring(EXP_LORE_PREFIX.length);
            const val = parseInt(numStr.trim());
            return isNaN(val) ? 0 : val;
        }
    }
    return 0;
}

/**
 * 设置存储的经验值（写入 Lore）
 */
function setStoredExp(item, value) {
    if (!item || !item.hasItemMeta()) return false;
    const meta = item.getItemMeta();
    const lore = meta.hasLore() ? meta.getLore() : [];

    const newLine = EXP_LORE_PREFIX + value;

    let updated = false;
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(EXP_LORE_PREFIX)) {
            lore.set(i, newLine);
            updated = true;
            break;
        }
    }
    if (!updated) lore.add(newLine);

    meta.setLore(lore);
    item.setItemMeta(meta);
    return true;
}

// ==================== 辅助函数 ====================

/**
 * 播放音效（避免重载问题，使用 Sound 枚举）
 */
function playSound(player, sound, volume, pitch) {
    try {
        const location = player.getLocation();
        player.getWorld().playSound(location, sound, volume, pitch);
    } catch (e) {
        // 忽略音效错误
    }
}