/**
 * 获取皮肤头颅 (1.21.11 Paper 兼容版)
 * 功能：通过命名牌和玩家头颅合成自定义皮肤头颅
 */

// ==================== Bukkit API 类导入 ====================
var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var SkullMeta = Java.type("org.bukkit.inventory.meta.SkullMeta");
var ItemMeta = Java.type("org.bukkit.inventory.meta.ItemMeta");
var NamespacedKey = Java.type("org.bukkit.NamespacedKey");
var PersistentDataType = Java.type("org.bukkit.persistence.PersistentDataType");
var URL = Java.type("java.net.URL");
var Scanner = Java.type("java.util.Scanner");
var InputStreamReader = Java.type("java.io.InputStreamReader");
var UUID = Java.type("java.util.UUID");
var Base64 = Java.type("java.util.Base64");

// ==================== 常量定义 ====================
var STORAGE_SLOT = 10;   // 左侧输入槽 - 命名牌
var CARD_SLOT = 16;      // 右侧输入槽 - 玩家头颅
var WORK_SLOT = 22;      // 工作槽
var OUTPUT_SLOT = 13;    // 输出槽

// ==================== 工具函数 ====================

function isValidNameTag(item) {
    if (!item || item.getType() !== Material.NAME_TAG) return false;
    if (!item.hasItemMeta()) return false;
    var meta = item.getItemMeta();
    return meta.hasDisplayName() && ChatColor.stripColor(meta.getDisplayName()).trim().length > 0;
}

function getPlayerIdFromNameTag(item) {
    if (!isValidNameTag(item)) return null;
    var meta = item.getItemMeta();
    return ChatColor.stripColor(meta.getDisplayName()).trim();
}

function isPlayerHead(item) {
    if (!item) return false;
    return item.getType() === Material.PLAYER_HEAD || item.getType().name() === "SKULL_ITEM";
}

/**
 * 通过Mojang API获取玩家皮肤数据
 */
function fetchSkinData(playerName) {
    try {
        var uuidUrl = new URL("https://api.mojang.com/users/profiles/minecraft/" + encodeURIComponent(playerName));
        var uuidConn = uuidUrl.openConnection();
        uuidConn.setRequestMethod("GET");
        uuidConn.setConnectTimeout(5000);
        uuidConn.setReadTimeout(5000);
        uuidConn.setRequestProperty("User-Agent", "Mozilla/5.0");
        
        var uuidScanner = new Scanner(uuidConn.getInputStream(), "UTF-8").useDelimiter("\\A");
        var uuidResponse = uuidScanner.hasNext() ? uuidScanner.next() : "";
        uuidScanner.close();
        
        var uuidJson = JSON.parse(uuidResponse);
        if (!uuidJson || !uuidJson.id) {
            print("UUID not found for " + playerName);
            return null;
        }
        var uuid = uuidJson.id;
        
        var profileUrl = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid + "?unsigned=false");
        var profileConn = profileUrl.openConnection();
        profileConn.setRequestMethod("GET");
        profileConn.setConnectTimeout(5000);
        profileConn.setReadTimeout(5000);
        profileConn.setRequestProperty("User-Agent", "Mozilla/5.0");
        
        var profileScanner = new Scanner(profileConn.getInputStream(), "UTF-8").useDelimiter("\\A");
        var profileResponse = profileScanner.hasNext() ? profileScanner.next() : "";
        profileScanner.close();
        
        var profileJson = JSON.parse(profileResponse);
        var properties = profileJson.properties;
        for (var i in properties) {
            var prop = properties[i];
            if (prop.name === "textures") {
                return {
                    value: prop.value,
                    signature: prop.signature || null,
                    skinUrl: null
                };
            }
        }
        return null;
    } catch (e) {
        print("Mojang API Error: " + e);
        return null;
    }
}

/**
 * 从皮肤数据中解析皮肤URL
 */
function extractSkinUrl(skinData) {
    if (!skinData || !skinData.value) return null;
    try {
        var decodedBytes = Base64.getDecoder().decode(skinData.value);
        var decodedStr = new java.lang.String(decodedBytes, "UTF-8");
        var textureJson = JSON.parse(decodedStr);
        var url = textureJson.textures.SKIN.url;
        skinData.skinUrl = url;
        return url;
    } catch (e) {
        return null;
    }
}

/**
 * Paper 1.21.1 兼容版：使用 Bukkit.createProfile + setPlayerProfile
 * 这是 Paper API 官方推荐的方式
 */
function createCustomSkull(skinData, playerName) {
    try {
        var head = new ItemStack(Material.PLAYER_HEAD, 1);
        var meta = head.getItemMeta();
        
        // 使用 Paper API: Bukkit.createProfile(UUID, name)
        // 注意：在 GraalJS 中通过 org.bukkit.Bukkit 调用
        var profile = org.bukkit.Bukkit.createProfile(UUID.randomUUID(), playerName || "CustomHead");
        
        // 设置纹理属性 - 使用字符串方式避免类加载问题
        // Paper 的 PlayerProfile.setProperty 接受 ProfileProperty
        // 我们通过反射构造 ProfileProperty 来避免直接导入类
        var ProfilePropertyClass = Java.type("org.bukkit.profile.ProfileProperty");
        var property = new ProfilePropertyClass("textures", skinData.value, skinData.signature || "");
        
        // 获取 setProperty 方法并调用（避免 GraalJS 方法重载问题）
        var setPropertyMethod = profile.getClass().getMethod("setProperty", ProfilePropertyClass);
        setPropertyMethod.invoke(profile, property);
        
        // 设置到 SkullMeta
        // 使用反射调用 setPlayerProfile 避免重载问题
        var setPlayerProfileMethod = meta.getClass().getMethod("setPlayerProfile", org.bukkit.profile.PlayerProfile.class);
        setPlayerProfileMethod.invoke(meta, profile);
        
        // 设置显示信息
        meta.setDisplayName("§6" + (playerName || "自定义皮肤") + "的头");
        meta.setLore([
            "§7自定义皮肤头颅",
            "§7玩家: §f" + (playerName || "Unknown"),
        ]);
        
        head.setItemMeta(meta);
        return head;
        
    } catch (e) {
        print("Skull creation error (Paper API): " + e);
        // 备用方案：尝试使用 NBT/组件方式
        return createCustomSkullViaNBT(skinData, playerName);
    }
}

/**
 * 备用方案：通过 NBT/数据组件直接设置头颅纹理
 * 1.21+ 使用 Data Components 系统
 */
function createCustomSkullViaNBT(skinData, playerName) {
    try {
        var head = new ItemStack(Material.PLAYER_HEAD, 1);
        
        // 构造 Base64 纹理 JSON
        var textureJson = '{"textures":{"SKIN":{"url":"http://textures.minecraft.net/texture/' + skinData.value + '"}}}';
        
        // 1.21+ 使用 DataComponentType.PROFILE
        // 通过反射获取 ItemStack 的 components 并设置
        var CraftItemStack = Java.type("org.bukkit.craftbukkit.inventory.CraftItemStack");
        var nmsItem = CraftItemStack.asNMSCopy(head);
        
        // 获取 DataComponents.PROFILE
        var DataComponents = Java.type("net.minecraft.core.component.DataComponents");
        var ResolvableProfile = Java.type("net.minecraft.world.item.component.ResolvableProfile");
        
        // 构造 GameProfile
        var GameProfileClass = Java.type("com.mojang.authlib.GameProfile");
        var PropertyClass = Java.type("com.mojang.authlib.properties.Property");
        var gameProfile = new GameProfileClass(UUID.randomUUID(), playerName || "CustomHead");
        var property = new PropertyClass("textures", skinData.value, skinData.signature || "");
        gameProfile.getProperties().put("textures", property);
        
        // 构造 ResolvableProfile
        var resolvableProfile = new ResolvableProfile(gameProfile);
        
        // 设置组件
        nmsItem.set(DataComponents.PROFILE, resolvableProfile);
        
        // 转回 Bukkit ItemStack
        head = CraftItemStack.asBukkitCopy(nmsItem);
        
        // 设置显示名称和 Lore
        var meta = head.getItemMeta();
        meta.setDisplayName("§6" + (playerName || "自定义皮肤") + "的头");
        meta.setLore([
            "§7自定义皮肤头颅",
            "§7玩家: §f" + (playerName || "Unknown"),
        ]);
        head.setItemMeta(meta);
        
        return head;
        
    } catch (e2) {
        print("Skull creation error (NBT fallback): " + e2);
        // 最终备用：返回基础头颅
        var head = new ItemStack(Material.PLAYER_HEAD, 1);
        var meta = head.getItemMeta();
        meta.setDisplayName("§6" + (playerName || "自定义皮肤") + "的头");
        meta.setLore([
            "§7自定义皮肤头颅",
            "§7玩家: §f" + (playerName || "Unknown"),
            "§c注意: 皮肤设置失败",
            "§c错误: " + e2.toString().substring(0, 50)
        ]);
        head.setItemMeta(meta);
        return head;
    }
}

function canPlaceInOutput(inv, newItem) {
    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) return true;
    if (!out.isSimilar(newItem) || out.getAmount() >= 64) return false;
    return true;
}

// ==================== 事件处理函数 ====================

function onClick(player, slot, slotItem, clickAction) {
    if (slot !== WORK_SLOT) return false;
    
    var inv = player.getOpenInventory().getTopInventory();
    if (!inv) return false;

    var nameTag = inv.getItem(STORAGE_SLOT);
    if (!isValidNameTag(nameTag)) {
        player.sendMessage("§c左侧输入槽必须放置已重命名的命名牌（包含玩家ID）！");
        try {
            player.getWorld().playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        } catch (soundErr) {}
        return true;
    }

    var playerId = getPlayerIdFromNameTag(nameTag);
    if (!playerId) {
        player.sendMessage("§c无法从命名牌读取玩家ID！");
        return true;
    }

    var headItem = inv.getItem(CARD_SLOT);
    if (!isPlayerHead(headItem)) {
        player.sendMessage("§c右侧输入槽必须放置玩家的头！");
        try {
            player.getWorld().playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        } catch (soundErr) {}
        return true;
    }

    player.sendMessage("§7正在查询玩家 §f" + playerId + " §7的皮肤...");
    
    var skinData = fetchSkinData(playerId);
    if (!skinData) {
        player.sendMessage("§c无法获取皮肤信息，请检查玩家ID是否正确！是否是正版账号！");
        try {
            player.getWorld().playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        } catch (soundErr) {}
        return true;
    }

    var skinUrl = extractSkinUrl(skinData);
    if (!skinUrl) {
        player.sendMessage("§c无法解析皮肤数据！");
        try {
            player.getWorld().playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        } catch (soundErr) {}
        return true;
    }

    var customSkull = createCustomSkull(skinData, playerId);
    customSkull.setAmount(1);

    if (!canPlaceInOutput(inv, customSkull)) {
        player.sendMessage("§c输出槽被其他物品占用或已满！");
        try {
            player.getWorld().playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        } catch (soundErr) {}
        return true;
    }

    if (nameTag.getAmount() > 1) {
        nameTag.setAmount(nameTag.getAmount() - 1);
    } else {
        inv.setItem(STORAGE_SLOT, null);
    }

    if (headItem.getAmount() > 1) {
        headItem.setAmount(headItem.getAmount() - 1);
    } else {
        inv.setItem(CARD_SLOT, null);
    }

    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) {
        inv.setItem(OUTPUT_SLOT, customSkull);
    } else {
        out.setAmount(out.getAmount() + 1);
    }

    player.sendMessage("§a成功生成 §f" + playerId + " §a的自定义皮肤头颅！");
    player.sendMessage("§7皮肤URL: §f" + skinUrl);
    try {
        player.getWorld().playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0, 1.0);
    } catch (soundErr) {}
    return true;
}

function onOpen(player) {}

function onClose(player) {}