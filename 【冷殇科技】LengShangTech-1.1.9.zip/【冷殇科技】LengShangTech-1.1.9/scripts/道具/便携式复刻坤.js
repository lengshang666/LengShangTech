function onUse(event) {
  let player = event.getPlayer();
  let copyCount = 1;   

  let world = player.getWorld();
  let eyeLocation = player.getEyeLocation();
  let direction = eyeLocation.getDirection();
  let notplayer = eyeLocation.add(0, -0.7, 0).add(direction);
  let maxDistance = 100;
  let rayTraceResults = world.rayTrace(notplayer, direction, maxDistance,
      org.bukkit.FluidCollisionMode.ALWAYS, true, 0, null);

  // 如果没有击中任何实体，返回
  if (rayTraceResults === null) {
    player.sendMessage("§c未检测到目标！");
    return;
  }

  let entity = rayTraceResults.getHitEntity();

  if (entity instanceof org.bukkit.entity.Item) {
    let item = entity.getItemStack();
    
    // ========== 核心改动：先检测是否为粘液物品 ==========
    let sfItem = SlimefunItem.getByItem(item);
    
    // 如果不是粘液物品，直接拒绝复制
    if (sfItem === null) {
      player.sendMessage("§c无法复制非粘液物品！§e只允许复制粘液科技物品。");
      return;
    }

    let itemId = sfItem.getId();

    // ========== 核心改动：通过粘液ID生成全新标准物品 ==========
    let sfItemDef = SlimefunItem.getById(itemId);
    if (sfItemDef === null) {
      player.sendMessage("§c无法获取该物品的定义！");
      return;
    }

    // 获取该ID对应的标准物品（clean item），并设置数量为1
    let newItem = sfItemDef.getItem().clone();
    newItem.setAmount(1);
    
    let location = entity.getLocation();
    
    // 复制物品
    for (let i = 0; i < copyCount; i++) {
      world.dropItemNaturally(location, newItem);
    }
    
    player.sendMessage("§d成功复制粘液物品！");
  } else {
    player.sendMessage("§c击中的不是物品,请右键掉落物最上方或跳起来右键掉落物");
  }
}