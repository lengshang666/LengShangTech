// 全息文字清除器（二次确认版）- 带权限检测
// 功能：右键选择最近的全息文字盔甲架，再次右键确认删除
// 权限：需要目标位置的 BREAK_BLOCK + INTERACT_BLOCK 权限

var playerTarget = new java.util.HashMap();


// ==================== 权限检查函数 ====================
/**
 * 检查玩家是否拥有指定位置的权限
 * 兼容 Residence、WorldGuard、GriefPrevention、Towny 等保护插件
 * 
 * @param {Player} player    - 要检查的玩家
 * @param {Location} location - 目标位置（全息文字所在位置）
 * @returns {boolean} true=有权限，false=无权限
 */
function hasPermission(player, location) {
    // 【绕过权限】OP 或拥有 Slimefun 管理员绕过权限时直接放行
    if (player.hasPermission("slimefun.inventory.bypass") || player.isOp()) {
        return true;
    }

    // 导入 Slimefun 保护管理器
    var Slimefun = Java.type('io.github.thebusybiscuit.slimefun4.implementation.Slimefun');
    // 导入交互类型枚举
    var Interaction = Java.type('io.github.thebusybiscuit.slimefun4.libraries.dough.protection.Interaction');
    
    // 获取保护管理器实例（自动检测服务器已安装的保护插件）
    var pm = Slimefun.getProtectionManager();

    // 同时检查两种权限：
    // BREAK_BLOCK    - 破坏方块权限（删除全息文字 = 破坏实体）
    // INTERACT_BLOCK - 交互方块权限（右键操作区域）
    // 任一权限缺失都视为无权限
    return pm.hasPermission(player, location, Interaction.BREAK_BLOCK) &&
           pm.hasPermission(player, location, Interaction.INTERACT_BLOCK);
}


// ==================== RSC 右键事件入口 ====================
function onUse(event) {
    /* ---------- 0. 拿到插件实例 ---------- */
    var pluginClass = Java.type("org.lins.mmmjjkx.rykenslimefuncustomizer.RykenSlimefunCustomizer");
    var plugin = pluginClass.getPlugin(pluginClass);

    var p   = event.getPlayer();
    var loc = p.getLocation();
    var uuid = p.getUniqueId().toString();

    /* ---------- 1. 权限检测：玩家所在区域 ---------- */
    // 先检查玩家当前位置是否有权限使用此工具
    // 防止在无权限区域滥用工具扫描他人领地
    if (!hasPermission(p, loc)) {
        p.sendMessage("§7你没有权限在此区域使用全息文字清除器！");
        p.playSound(loc, "block.note_block.bass", 1.0, 0.5);
        return;
    }

    /* ---------- 2. 找最近的全息盔甲架 ---------- */
    var entities = loc.getNearbyEntities(3, 3, 3);
    var nearestHologram = null;
    var nearestDistance = 999;

    for (var i = 0; i < entities.size(); i++) {
        var e = entities.get(i);
        // 通过材质名称字符串比较，避免 GraalJS instanceof 问题
        if (e.getType().name() === "ARMOR_STAND") {
            var as = e;
            // 全息文字盔甲架特征：隐形 + 无重力 + Marker（无碰撞箱）
            if (as.isInvisible() && !as.hasGravity() && as.isMarker()) {
                var distance = loc.distance(as.getLocation());
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearestHologram = as;
                }
            }
        }
    }

    // 未找到符合条件的全息文字
    if (!nearestHologram) {
        p.sendMessage("§73 格范围内未找到全息文字！");
        p.playSound(loc, "block.note_block.bass", 1, 0.5);
        // 清除之前的待确认标记
        p.removeMetadata("hologramToRemove", plugin);
        return;
    }

    /* ---------- 3. 权限检测：全息文字所在位置 ---------- */
    // 二次确认：即使玩家在自己领地内，全息文字可能在他人领地
    // 例如跨领地边界放置的全息文字
    if (!hasPermission(p, nearestHologram.getLocation())) {
        p.sendMessage("§7你没有权限移除这个全息文字！");
        p.playSound(loc, "block.note_block.bass", 1.0, 0.5);
        // 清除之前的待确认标记，防止误操作
        p.removeMetadata("hologramToRemove", plugin);
        return;
    }

    /* ---------- 4. 是否已有待确认标记 ---------- */
    var meta = p.getMetadata("hologramToRemove");
    var pending = meta && meta.length > 0 ? meta[0].value() : null;

    // 如果已有标记且标记的就是当前这个全息文字，执行删除
    if (pending && pending.equals(nearestHologram)) {
        /* ---------- 5. 二次右键 -> 正式删除 ---------- */
        nearestHologram.remove();
        p.sendMessage("§a成功清除全息文字！");
        p.playSound(loc, "entity.experience_orb.pickup", 1, 1.5);
        // 清除标记
        p.removeMetadata("hologramToRemove", plugin);
    } else {
        /* ---------- 6. 第一次右键 -> 仅标记 ---------- */
        // 使用 Bukkit Metadata API 存储待删除目标
        // FixedMetadataValue 将插件实例和值绑定，防止内存泄漏
        p.setMetadata("hologramToRemove",
                new org.bukkit.metadata.FixedMetadataValue(plugin, nearestHologram));
        p.sendMessage("§7在 §f" +
                Math.round(nearestDistance * 10) / 10 + " §7格处发现全息文字，再次右键确认清除！");
        p.playSound(loc, "block.note_block.pling", 1, 1);
    }
}