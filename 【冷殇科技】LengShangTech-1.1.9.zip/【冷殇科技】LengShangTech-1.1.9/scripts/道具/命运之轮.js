const DISPLAY_NAME = '§x§B§B§5§1§F§2命§x§C§1§3§A§B§B运§x§C§7§2§2§8§4之§x§C§D§0§B§4§D轮';
const COOLDOWN_MS = 1500;
const cdMap = new java.util.HashMap();

function getRandomSlimefunItem() {
    try {
        var Slimefun = Packages.io.github.thebusybiscuit.slimefun4.implementation.Slimefun;
        var registry = Slimefun.getRegistry();
        var items = registry.getAllSlimefunItems();
        var list = new java.util.ArrayList();
        var iter = items.iterator();
        while (iter.hasNext()) {
            var item = iter.next();
            if (item != null && item.getId() != null) {
                list.add(item);
            }
        }
        if (list.isEmpty()) return null;
        var idx = Math.floor(Math.random() * list.size());
        return list.get(idx).getItem().clone();
    } catch (e) {
        return null;
    }
}

function onUse(evt) {
    var player = evt.getPlayer();
    var uuid = player.getUniqueId().toString();
    var now = Date.now();

    if (cdMap.containsKey(uuid)) {
        if (now - cdMap.get(uuid) < COOLDOWN_MS) {
            player.sendActionBar("§7冷却中...");
            return;
        }
    }
    cdMap.put(uuid, now);

    var dropItem = getRandomSlimefunItem();
    if (dropItem == null) {
        player.sendMessage("§c物品列表为空！");
        return;
    }

    var loc = player.getLocation().add(0, 1.5, 0);
    player.getWorld().dropItemNaturally(loc, dropItem);

    var meta = dropItem.getItemMeta();
    var name = (meta != null && meta.hasDisplayName()) ? meta.getDisplayName() : dropItem.getType().name();
    player.sendMessage("§x§B§B§5§1§F§2命§x§C§1§3§A§B§B运§x§C§7§2§2§8§4之§x§C§D§0§B§4§D轮§6转动 §a✦ 随机掉落: §e" + name);
}

function onLoad() {
    return {
        PlayerInteractEvent: function (evt) {
            var action = evt.getAction().name();
            if (action != "RIGHT_CLICK_AIR" && action != "RIGHT_CLICK_BLOCK") return;
            if (evt.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

            var item = evt.getPlayer().getInventory().getItemInMainHand();
            if (item == null || !item.hasItemMeta()) return;
            if (item.getItemMeta().getDisplayName() != DISPLAY_NAME) return;

            onUse(evt);
            evt.setCancelled(true);
        }
    };
}
onLoad();

function tick(info) {}
function onOpen(player) {}
function onClick(player, slot, slotItem, clickAction) {}
function onClose(player) {}