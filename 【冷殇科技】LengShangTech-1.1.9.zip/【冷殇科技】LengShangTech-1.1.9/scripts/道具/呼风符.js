// ======================================================
// 呼风符
// 功能：
// - 清除暴雨与雷电，设置晴天 5 分钟
// - 使用冷却：3 分钟（3600 tick）
// - 晴天时右键不生效、不消耗、不进入冷却
// ======================================================

// ===== Java 类型 =====
const Effect = Java.type("org.bukkit.Effect");
const Bukkit = Java.type("org.bukkit.Bukkit");
const HashMap = Java.type("java.util.HashMap");
// 导入 Bukkit API 类
// Effect: 视觉效果枚举（如烟雾粒子）
// Bukkit: 主类，用于获取服务器 tick 等
// HashMap: Java 哈希映射，用于存储冷却数据

// ===== Slimefun 物品 ID =====
const ITEM_ID = "LENGSHANG_呼风符";
// 该物品在 Slimefun 中的唯一标识符

// ===== 冷却时间（tick）=====
const COOLDOWN_TICKS = 3 * 60 * 20; // 3600 tick
// 3 分钟 = 180 秒 × 20 ticks/秒 = 3600 ticks
// 使用服务器 tick 而非系统时间，避免时间同步问题

// 玩家冷却记录
// key: UUID（String）
// value: 上次使用 tick（服务器总 tick 数）
var cooldownMap = new HashMap();
// Java HashMap 存储，跨会话不持久（服务器重启重置）

// ======================================================================
// 主入口：物品使用事件
// ======================================================================

/**
 * 物品使用事件处理函数（右键点击时触发）
 * @param {Event} event - RSC 封装的 SlimefunItemUseEvent
 */
function onUse(event) {

    var player = event.getPlayer();
    if (!player) return;
    // 获取玩家，为空则返回

    var item = event.getItem();
    if (!item || item.getType().isAir()) return;
    // 物品为空或空气，不处理

    // ===== 校验 Slimefun 物品 =====
    var optional = event.getSlimefunItem();
    // 获取 Optional<<SlimefunItem>（RSC 封装模式）
    
    if (!optional.isPresent()) return;
    // Optional 无值，不是 Slimefun 物品
    
    var sfItem = optional.get();
    if (sfItem.getId() !== ITEM_ID) return;
    // ID 不匹配，不是呼风符

    var world = player.getWorld();
    // 获取玩家所在世界（天气控制目标）

    // ==================================================
    // 晴天判断（不生效、不消耗、不冷却）
    // ==================================================
    if (!world.hasStorm() && !world.isThundering()) {
        // hasStorm(): 是否有降雨（雨/雪）
        // isThundering(): 是否有雷暴
        
        player.sendMessage("§7天空已是晴朗，无需使用§e呼风符§7。");
        // §7 = 灰色（平淡语气）, §e = 金色（物品名高亮）
        // 晴天使用不消耗物品，不进入冷却，友好提示
        
        return;
    }

    // ==================================================
    // 冷却判断（基于服务器 tick）
    // ==================================================
    var uuid = player.getUniqueId().toString();
    // 玩家 UUID 作为冷却记录键
    
    var nowTick = Bukkit.getCurrentTick();
    // 获取服务器当前总 tick 数
    // 这是 Bukkit API 提供的精确 tick 计数器，从服务器启动开始累加

    if (cooldownMap.containsKey(uuid)) {
        // 检查该玩家是否已有冷却记录
        
        var lastTick = cooldownMap.get(uuid);
        // 获取上次使用时的 tick
        
        var remain = COOLDOWN_TICKS - (nowTick - lastTick);
        // 计算剩余冷却 tick
        // remain = 总冷却 - (当前tick - 上次tick)
        
        if (remain > 0) {
            // 还有剩余冷却时间
            
            player.sendMessage(
                "§c呼风符冷却中，剩余 §e" + Math.ceil(remain / 20) + "§c 秒"
            );
            // §c = 红色（错误）, §e = 金色（数字高亮）
            // Math.ceil(remain / 20): 将 tick 转换为秒，向上取整
            
            return;
        }
    }

    // ==================================================
    // 天气控制
    // ==================================================
    world.setWeatherDuration(0);
    // 清除当前天气事件的剩余持续时间
    // 立即结束正在进行的雨/雪
    
    world.setClearWeatherDuration(6000);
    // 设置晴天持续 6000 ticks = 300 秒 = 5 分钟
    // 之后世界恢复自然天气变化
    
    world.setStorm(false);
    // 关闭降雨状态
    
    world.setThundering(false);
    // 关闭雷暴状态

    // 客户端刷新
    world.playEffect(player.getLocation(), Effect.SMOKE, 1);
    // 在玩家位置播放烟雾粒子效果
    // Effect.SMOKE: 烟雾效果，参数 1 为方向/数据值
    // 用于强制刷新客户端天气显示，确保天气同步

    // ==================================================
    // 提示 & 声音（严格使用字符串格式）
    // ==================================================
    player.sendMessage("§b你使用了§e呼风符§b，天朗气清，风和日丽！");
    // §b = 青色（主题色）, §e = 金色（物品名）
    
    player.playSound(
        player.getLocation(),
        "entity.cow.ambient",    // 牛的叫声（温和、自然）
        1.0,                    // 音量
        1.0                     // 音调
    );
    // 使用字符串音效名，避免 GraalJS 重载问题（参考记忆 #1）

    // ==================================================
    // 消耗物品（主手）
    // ==================================================
    var inv = player.getInventory();
    var mainHand = inv.getItemInMainHand();
    // 获取主手物品（确保消耗的是实际使用的物品）

    if (mainHand && !mainHand.getType().isAir()) {
        // 主手有物品且非空气
        
        if (mainHand.getAmount() > 1) {
            mainHand.setAmount(mainHand.getAmount() - 1);
            inv.setItemInMainHand(mainHand);
            // 堆叠 > 1，减少 1 个并更新
        } else {
            inv.setItemInMainHand(null);
            // 只剩 1 个，清空主手
        }
    }

    // ==================================================
    // 写入冷却
    // ==================================================
    cooldownMap.put(uuid, nowTick);
    // 记录本次使用的服务器 tick，开始 3 分钟冷却
}