let isWaitingForInput = false;
let Bukkit = Java.type('org.bukkit.Bukkit');
let Consumer = Java.type('java.util.function.Consumer');
let ChatColor = Java.type('org.bukkit.ChatColor');
let NamespacedKey = Java.type('org.bukkit.NamespacedKey');
let PersistentDataType = Java.type('org.bukkit.persistence.PersistentDataType');

// ========== 配置区域 ==========
const MAX_LEVEL_LIMIT = 100;
const VALUE_LORE_PREFIX = "§7每次提升: §6";
const BIND_LORE_PREFIX = "§7绑定玩家: §e";
const BIND_UUID_KEY = "bind_uuid";  // PDC 中存储 UUID 的键名
const INTEGER_MAX = 2147483647;
const COOLDOWN_MS = 1500;

const cdMap = new Map();

function onUse(event) {
    const player = event.getPlayer();
    const item = event.getItem();

    if (!item || item.getType().isAir()) {
        player.sendMessage("§c❌ 请手持等级作弊器");
        event.cancel();
        return;
    }

    const bindInfo = getBindInfo(item);
    if (bindInfo === null) {
        if (setBindInfo(item, player)) {
            player.sendMessage("§a✅ 经验作弊器已绑定至玩家 §f" + player.getName());
            player.sendMessage("§7此物品仅限你本人使用，他人无法使用");
        }
    } else if (bindInfo.uuid !== player.getUniqueId().toString()) {
        player.sendMessage("§c❌ 此经验作弊器已绑定给其他玩家！");
        player.sendMessage("§7绑定玩家: §e" + bindInfo.name);
        player.sendMessage("§c你无法使用他人的经验作弊器");
        event.cancel();
        return;
    }

    if (player.isSneaking()) {
        handleSneakRightClick(player, item);
    } else {
        handleNormalRightClick(player, item);
    }
    
    event.cancel();
}

/**
 * 获取绑定信息
 * 从 Lore 读取玩家名，从 PDC 读取 UUID
 */
function getBindInfo(item) {
    if (!item || !item.hasItemMeta()) return null;
    const meta = item.getItemMeta();
    
    // 先从 PDC 读取 UUID（隐藏存储）
    const pdc = meta.getPersistentDataContainer();
    const key = new NamespacedKey("rsc", BIND_UUID_KEY);
    let uuid = null;
    if (pdc.has(key, PersistentDataType.STRING)) {
        uuid = pdc.get(key, PersistentDataType.STRING);
    }
    
    // 再从 Lore 读取玩家名（显示用）
    const lore = meta.getLore();
    if (!lore) return null;
    
    for (let i = 0; i < lore.size(); i++) {
        const line = lore.get(i);
        if (line.startsWith(BIND_LORE_PREFIX)) {
            const fullText = ChatColor.stripColor(line);
            const content = fullText.substring(fullText.indexOf(":") + 1).trim();
            return { uuid: uuid, name: content };
        }
    }
    return null;
}

/**
 * 设置绑定信息
 * UUID 存入 PDC（隐藏），玩家名存入 Lore（显示）
 */
function setBindInfo(item, player) {
    if (!item || !item.hasItemMeta()) return false;
    const meta = item.getItemMeta();
    
    // 将 UUID 存入 PDC（玩家不可见）
    const pdc = meta.getPersistentDataContainer();
    const key = new NamespacedKey("rsc", BIND_UUID_KEY);
    pdc.set(key, PersistentDataType.STRING, player.getUniqueId().toString());
    
    // 将玩家名存入 Lore（玩家可见，无 UUID）
    const lore = meta.hasLore() ? meta.getLore() : [];
    const bindLine = BIND_LORE_PREFIX + player.getName();
    
    let updated = false;
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(BIND_LORE_PREFIX)) {
            lore.set(i, bindLine);
            updated = true;
            break;
        }
    }
    if (!updated) lore.add(bindLine);
    
    meta.setLore(lore);
    item.setItemMeta(meta);
    return true;
}

function handleSneakRightClick(player, item) {
    if (isWaitingForInput) {
        player.sendMessage("§c⚠️ 你已经在输入状态中");
        return;
    }

    const currentValue = getStoredValue(item);
    if (currentValue !== null) {
        player.sendMessage("§6当前每次提升: §b" + formatNumber(currentValue) + " 级");
    }

    player.sendMessage("§6请输入每次要提升的等级数量：");
    player.sendMessage("§7支持格式: 1-100 §c最高限制: " + MAX_LEVEL_LIMIT + "级");
    player.sendMessage("§7输入 'cancel' 取消操作");

    isWaitingForInput = true;

    let JSConsumer = Java.extend(Consumer, {
        accept: function(input) {
            isWaitingForInput = false;
            input = input.trim();

            if (input.toLowerCase() === "cancel") {
                player.sendMessage("§a✅ 已取消操作");
                return;
            }

            const num = parseInputNumber(input);
            if (num === null || num <= 0) {
                player.sendMessage("§c❌ 请输入有效的正整数！");
                return;
            }

            if (num > MAX_LEVEL_LIMIT) {
                player.sendMessage("§c❌ 设置的等级过高！");
                player.sendMessage("§7最大允许设置: §e" + MAX_LEVEL_LIMIT + "级");
                player.sendMessage("§7你输入了: §c" + formatNumber(num) + "级");
                return;
            }

            const currentItem = player.getInventory().getItemInMainHand();
            if (!currentItem || currentItem.getType().isAir()) {
                player.sendMessage("§c❌ 主手工具已空");
                return;
            }

            if (setStoredValue(currentItem, num)) {
                player.sendMessage("§a✅ 每次提升等级已设置为: §b" + formatNumber(num) + " 级");
                player.sendMessage("§7请使用普通右键提升等级");
            }
        }
    });

    getChatInput(player, new JSConsumer());
}

function handleNormalRightClick(player, item) {
    const uuid = player.getUniqueId().toString();
    const now = Date.now();

    if (cdMap.has(uuid) && now - cdMap.get(uuid) < COOLDOWN_MS) {
        player.sendActionBar('§7冷却中...');
        return;
    }
    cdMap.set(uuid, now);

    const targetLevel = getStoredValue(item);
    if (targetLevel === null || targetLevel <= 0) {
        player.sendMessage("§c❌ 请先蹲下右键设置要提升的等级数量");
        player.sendMessage("§7例如输入: 20 (表示每次右键增加20级)");
        return;
    }

    const currentLevel = player.getLevel();
    const newLevel = currentLevel + targetLevel;
    
    if (newLevel > INTEGER_MAX) {
        player.sendMessage("§c❌ 提升后的等级超过游戏限制！");
        return;
    }

    player.setLevel(newLevel);
    
    player.sendMessage("§a✅ 等级提升成功！");
    player.sendMessage("§7原等级: §f" + formatNumber(currentLevel));
    player.sendMessage("§7新等级: §b" + formatNumber(newLevel));
    player.sendMessage("§7本次增加: §a+" + formatNumber(targetLevel) + " 级");
}

function getStoredValue(item) {
    if (!item || !item.hasItemMeta()) return null;
    const lore = item.getItemMeta().getLore();
    if (!lore) return null;
    
    for (let i = 0; i < lore.size(); i++) {
        const line = lore.get(i);
        if (line.startsWith(VALUE_LORE_PREFIX)) {
            const numStr = line.substring(VALUE_LORE_PREFIX.length);
            const cleanNum = numStr.replace(/[,\s级]/g, '');
            const val = parseInt(cleanNum);
            return isNaN(val) ? null : val;
        }
    }
    return null;
}

function setStoredValue(item, value) {
    if (!item || !item.hasItemMeta()) return false;
    const meta = item.getItemMeta();
    const lore = meta.hasLore() ? meta.getLore() : [];
    
    let updated = false;
    for (let i = 0; i < lore.size(); i++) {
        if (lore.get(i).startsWith(VALUE_LORE_PREFIX)) {
            lore.set(i, VALUE_LORE_PREFIX + formatNumber(value) + " 级");
            updated = true;
            break;
        }
    }
    if (!updated) lore.add(VALUE_LORE_PREFIX + formatNumber(value) + " 级");
    
    meta.setLore(lore);
    item.setItemMeta(meta);
    return true;
}

function parseInputNumber(input) {
    try {
        input = input.trim().toLowerCase();
        let multiplier = 1;
        
        if (input.endsWith('m')) multiplier = 1000000;
        else if (input.endsWith('k')) multiplier = 1000;
        
        if (multiplier !== 1) input = input.slice(0, -1);
        
        const number = parseFloat(input);
        return isNaN(number) ? null : Math.floor(number * multiplier);
    } catch (e) {
        return null;
    }
}

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}