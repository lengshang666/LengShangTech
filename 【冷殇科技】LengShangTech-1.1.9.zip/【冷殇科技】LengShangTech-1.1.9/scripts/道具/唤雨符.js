// ======================================================
// 唤雨符
// 功能：
// - 清除晴天，设置雨天 5 分钟
// - 使用冷却：3 分钟（3600 tick）
// - 当天已下雨不生效、不消耗、不进入冷却
// ======================================================

// ===== Java 类型 =====
const Effect = Java.type("org.bukkit.Effect");
const Bukkit = Java.type("org.bukkit.Bukkit");
const HashMap = Java.type("java.util.HashMap");
// 导入 Bukkit API 类
// Effect: 视觉效果枚举（烟雾等）
// Bukkit: 主类，用于获取服务器 tick
// HashMap: Java 哈希表，用于冷却存储

// ===== Slimefun 物品 ID =====
const ITEM_ID = "LENGSHANG_唤雨符";
// 该物品在 Slimefun 中的唯一标识符

// ===== 冷却时间（tick）=====
const COOLDOWN_TICKS = 3 * 60 * 20;
// 3 分钟 = 180 秒 = 3600 ticks（20 ticks/秒）

// 玩家冷却记录
// key: UUID（String）
// value: 上次使用 tick
var cooldownMap = new HashMap();
// Java HashMap，存储玩家冷却时间
// 使用服务器 tick 而非时间戳，避免系统时间修改的影响

// ======================================================================
// 主入口：物品使用事件
// ======================================================================

/**
 * 物品使用事件处理函数（右键点击时触发）
 * @param {Event} event - RSC 封装的 SlimefunItemUseEvent
 */
function onUse(event) {

    var player = event.getPlayer();
    if (!player) return;
    // 获取玩家，为空则不处理

    var item = event.getItem();
    if (!item || item.getType().isAir()) return;
    // 物品为空或空气，不处理

    // ===== 校验 Slimefun 物品 =====
    var optional = event.getSlimefunItem();
    // 获取 Optional<<SlimefunItem>
    
    if (!optional.isPresent()) return;
    // 不是 Slimefun 物品，不处理
    
    var sfItem = optional.get();
    if (sfItem.getId() !== ITEM_ID) return;
    // ID 不是 FVV_RAIN_RUNE，不处理

    var world = player.getWorld();
    // 获取玩家所在世界

    // ==================================================
    // 已下雨判断（不生效、不消耗、不冷却）
    // ==================================================
    if (world.hasStorm()) {
        // 检查世界是否正在下雨/雷暴
        // hasStorm() 返回 true 表示有降水（包括雨和雷暴）
        
        player.sendMessage("§7天空已经在下雨，无需使用§e唤雨符§7。");
        // §7 = 灰色（无操作提示）, §e = 黄色（物品名高亮）
        
        return;
        // 直接返回，不消耗、不计入冷却
    }

    // ==================================================
    // 冷却判断（基于服务器 tick）
    // ==================================================
    var uuid = player.getUniqueId().toString();
    // 获取玩家 UUID 字符串作为冷却键
    
    var nowTick = Bukkit.getCurrentTick();
    // 获取服务器当前总 tick 数
    // 从服务器启动开始累计，不受系统时间影响，更可靠

    if (cooldownMap.containsKey(uuid)) {
        // 检查该玩家是否已有冷却记录
        
        var lastTick = cooldownMap.get(uuid);
        // 获取上次使用的 tick 数
        
        var remain = COOLDOWN_TICKS - (nowTick - lastTick);
        // 计算剩余冷却 tick 数

        if (remain > 0) {
            // 仍在冷却中
            
            player.sendMessage(
                "§c唤雨符冷却中，剩余 §e" + Math.ceil(remain / 20) + "§c 秒"
            );
            // §c = 红色（冷却提示）, §e = 黄色（秒数高亮）
            // Math.ceil(remain / 20): 将 tick 转换为秒并向上取整
            
            return;
        }
    }

    // ==================================================
    // 天气控制
    // ==================================================
    world.setClearWeatherDuration(0);
    // 清除晴天持续时间设为 0，立即结束晴天
    
    world.setWeatherDuration(6000);
    // 雨天持续时间设为 6000 ticks = 5 分钟
    
    world.setStorm(true);
    // 开启降雨
    
    world.setThundering(false);
    // 关闭雷暴（只下雨，不打雷）

    // 客户端刷新
    world.playEffect(player.getLocation(), Effect.SMOKE, 1);
    // 在玩家位置播放烟雾效果，作为视觉反馈
    // 参数：位置, 效果类型, 数据（1 = 普通烟雾）

    // ==================================================
    // 提示 & 声音（字符串格式）
    // ==================================================
    player.sendMessage("§b你使用了§e唤雨符§b，乌云密布，雨水纷纷洒落！");
    // §b = 青色（主题色）, §e = 黄色（物品名）
    
    player.playSound(
        player.getLocation(), 
        "weather.rain", 
        1.0, 
        1.0
    );
    // 播放下雨环境音效，增强氛围

    // ==================================================
    // 消耗物品（主手）
    // ==================================================
    var inv = player.getInventory();
    // 获取背包
    
    var mainHand = inv.getItemInMainHand();
    // 获取主手物品（即唤雨符本身）

    if (mainHand && !mainHand.getType().isAir()) {
        // 主手不为空
        
        if (mainHand.getAmount() > 1) {
            mainHand.setAmount(mainHand.getAmount() - 1);
            inv.setItemInMainHand(mainHand);
            // 堆叠 > 1，减少 1 个并更新
        } else {
            inv.setItemInMainHand(null);
            // 只剩 1 个，清空主手
        }
    }

    // ==================================================
    // 写入冷却
    // ==================================================
    cooldownMap.put(uuid, nowTick);
    // 记录本次使用的 tick 数，开始 3 分钟冷却
}