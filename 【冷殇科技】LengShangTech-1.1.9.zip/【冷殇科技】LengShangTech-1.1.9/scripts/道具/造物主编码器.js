/**
 * 粘液物品ID获取机
 * 功能：通过命名牌输入Slimefun物品ID，合成对应的粘液物品
 */

// ==================== Bukkit API 类导入 ====================
var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var ItemMeta = Java.type("org.bukkit.inventory.meta.ItemMeta");

// ==================== Slimefun API 导入 ====================
var SlimefunItem = Java.type("io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem");

// ==================== 常量定义 ====================
// GUI槽位索引（Minecraft箱子界面，0-53，每行9个槽位）
var STORAGE_SLOT = 10;   // 左侧输入槽 - 放置命名牌（第2行第2列）
var WORK_SLOT = 13;      // 工作槽 - 点击此处开始合成（第3行第5列）
var OUTPUT_SLOT = 16;    // 输出槽 - 生成结果（第2行第6列）

// ==================== 工具函数 ====================

/**
 * 检查物品是否为有效的命名牌
 * 有效条件：是命名牌类型，且有自定义显示名称（非空）
 * @param {ItemStack} item - 要检查的物品
 * @returns {boolean} 是否为有效命名牌
 */
function isValidNameTag(item) {
    if (!item || item.getType() !== Material.NAME_TAG) return false;
    if (!item.hasItemMeta()) return false;
    var meta = item.getItemMeta();
    // 检查是否有显示名称，且去除颜色代码后不为空
    return meta.hasDisplayName() && ChatColor.stripColor(meta.getDisplayName()).trim().length > 0;
}

/**
 * 从命名牌中提取Slimefun物品ID
 * @param {ItemStack} item - 命名牌物品
 * @returns {string|null} 物品ID或null
 */
function getSlimefunIdFromNameTag(item) {
    if (!isValidNameTag(item)) return null;
    var meta = item.getItemMeta();
    // 去除颜色代码并清理空格，转为大写（Slimefun ID通常是大写）
    var id = ChatColor.stripColor(meta.getDisplayName()).trim();
    // Slimefun ID 通常是大写，但保留原样以兼容不同命名
    return id;
}

/**
 * 根据ID获取Slimefun物品
 * @param {string} id - Slimefun物品ID
 * @returns {ItemStack|null} 物品堆栈或null
 */
function getSlimefunItem(id) {
    try {
        if (!id) return null;
        // 使用 SlimefunItem.getById 查询物品
        var sfItem = SlimefunItem.getById(id);
        if (sfItem == null) {
            // 尝试大写ID（Slimefun标准ID通常是大写）
            sfItem = SlimefunItem.getById(id.toUpperCase());
        }
        if (sfItem == null) {
            // 尝试小写ID
            sfItem = SlimefunItem.getById(id.toLowerCase());
        }
        if (sfItem != null) {
            return sfItem.getItem().clone();
        }
        return null;
    } catch (e) {
        print("获取Slimefun物品错误: " + e);
        return null;
    }
}

/**
 * 检查是否可以放置物品到输出槽
 * @param {Inventory} inv - 容器界面
 * @param {ItemStack} newItem - 要放置的新物品
 * @returns {boolean} 是否可以放置
 */
function canPlaceInOutput(inv, newItem) {
    var out = inv.getItem(OUTPUT_SLOT);
    // 输出槽为空
    if (out == null || out.getType().isAir()) return true;
    // 检查物品是否相同且未达到堆叠上限（64）
    if (!out.isSimilar(newItem) || out.getAmount() >= 64) return false;
    return true;
}

// ==================== 事件处理函数 ====================

/**
 * 点击事件处理（核心逻辑）
 * 当玩家点击工作槽时执行合成逻辑
 * @param {Player} player - 点击的玩家
 * @param {number} slot - 点击的槽位
 * @param {ItemStack} slotItem - 槽位中的物品
 * @param {Object} clickAction - 点击动作信息
 * @returns {boolean} 是否取消默认行为
 */
function onClick(player, slot, slotItem, clickAction) {
    // 只处理工作槽的点击
    if (slot !== WORK_SLOT) return false;
    
    var inv = player.getOpenInventory().getTopInventory();
    if (!inv) return false;

    // ===== 检查左侧输入槽（命名牌） =====
    var nameTag = inv.getItem(STORAGE_SLOT);
    if (!isValidNameTag(nameTag)) {
        player.sendMessage("§c左侧输入槽必须放置已重命名的命名牌（包含Slimefun物品ID）！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // 获取Slimefun物品ID
    var slimefunId = getSlimefunIdFromNameTag(nameTag);
    if (!slimefunId) {
        player.sendMessage("§c无法从命名牌读取物品ID！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 查询Slimefun物品 =====
    player.sendMessage("§7正在查询粘液物品 ID: §f" + slimefunId + " ");
    
    var resultItem = getSlimefunItem(slimefunId);
    if (!resultItem) {
        player.sendMessage("§c未找到ID为 §f" + slimefunId + " §c的粘液物品！");
        player.sendMessage("§7请检查ID拼写是否正确");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // 设置输出数量为1
    resultItem.setAmount(1);

    // 检查输出槽
    if (!canPlaceInOutput(inv, resultItem)) {
        player.sendMessage("§c输出槽被其他物品占用或已满！");
        player.playSound(player.getLocation(), "entity.villager.no", 1.0, 1.0);
        return true;
    }

    // ===== 消耗材料 =====
    // 消耗命名牌
    if (nameTag.getAmount() > 1) {
        nameTag.setAmount(nameTag.getAmount() - 1);
    } else {
        inv.setItem(STORAGE_SLOT, null);
    }

    // ===== 输出结果 =====
    var out = inv.getItem(OUTPUT_SLOT);
    if (out == null || out.getType().isAir()) {
        inv.setItem(OUTPUT_SLOT, resultItem);
    } else {
        out.setAmount(out.getAmount() + 1);
    }

    // 成功提示
    player.sendMessage("§a成功生成粘液物品: §f" + resultItem.getItemMeta().getDisplayName() + " §a(ID: " + slimefunId + ")");
    player.playSound(player.getLocation(), "entity.experience_orb.pickup", 1.0, 1.0);
    return true;
}

/**
 * 打开界面事件
 * @param {Player} player - 打开界面的玩家
 */
function onOpen(player) {}

/**
 * 关闭界面事件
 * @param {Player} player - 关闭界面的玩家
 */
function onClose(player) {}