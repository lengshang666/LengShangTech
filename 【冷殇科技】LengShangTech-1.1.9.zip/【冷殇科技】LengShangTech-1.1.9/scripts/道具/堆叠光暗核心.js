var Material = Java.type("org.bukkit.Material");
var SlimefunItem = Java.type("io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem");
var NamespacedKey = Java.type("org.bukkit.NamespacedKey");
var PersistentDataType = Java.type("org.bukkit.persistence.PersistentDataType");
var ChatColor = Java.type("org.bukkit.ChatColor");
var ArrayList = Java.type("java.util.ArrayList");
var Long = Java.type("java.lang.Long");
var ByteArrayInputStream = Java.type("java.io.ByteArrayInputStream");
var ObjectInputStream = Java.type("java.io.ObjectInputStream");
var TARGET_MACHINE_ID = "LENGSHANG_堆叠光暗生成器";
var COUNT_SLOT = 4;
var QUANTUM_SLOT = 16;
var CHECK_SLOT = 10;
var REQUIRED_PICKAXE_ID = "MOMOTECH_SILK_TOUCH_PICKAXE";
var MAX_MACHINE_COUNT = 2147483647;
var GENERATION_INTERVAL_MS = 2000;
var STACK_SIZE = 64;
var PROBABILITY_MAP = {
    "MOMOTECH_SHINE_AND_DARK_CONSTRUCTOR": 0.01,
    "MOMOTECH_RULE_SHINE_AND_DARK_CONSTRUCTOR": 0.5
};
var DEFAULT_PERCENT = 0.01;
var ALLOWED_ITEM_IDS = ["MOMOTECH_SHINE", "MOMOTECH_DARK"];
var OUTPUT_SLOTS = [];
for (var i = 0; i <= 35; i++) OUTPUT_SLOTS.push(i);
var lastGenTime = new java.util.HashMap();
var quantumCache = new java.util.HashMap();
function getLoreValue(item, prefix) {
    if (!item) return null;
    var meta = item.getItemMeta();
    if (!meta || !meta.hasLore()) return null;
    var lore = meta.getLore();
    for (var i = 0; i < lore.size(); i++) {
        var line = lore.get(i);
        if (line.startsWith(prefix)) return line.substring(prefix.length).trim();
    }
    return null;
}
function parseMachineCount(str) {
    if (!str) return 0;
    var digits = str.replace(/[^0-9]/g, '');
    var num = parseInt(digits, 10);
    return isNaN(num) ? 0 : Math.min(num, MAX_MACHINE_COUNT);
}
function getSlimefunItemById(id) {
    var sf = SlimefunItem.getById(id);
    return sf ? sf.getItem().clone() : null;
}
function isRequiredPickaxe(item) {
    if (!item) return false;
    var sf = SlimefunItem.getByItem(item);
    return sf && sf.getId() === REQUIRED_PICKAXE_ID;
}
function isSameItem(a, b) {
    if (!a || !b || a.getType() !== b.getType()) return false;
    var sa = SlimefunItem.getByItem(a);
    var sb = SlimefunItem.getByItem(b);
    return (sa && sb) ? sa.getId() === sb.getId() : a.isSimilar(b);
}
function extractSlimefunIdFromBytes(bytes) {
    if (!bytes || bytes.length < 10) return null;
    var target = "slimefun:slimefun_item";
    var targetBytes = [];
    for (var i = 0; i < target.length; i++) targetBytes.push(target.charCodeAt(i) & 0xFF);
    for (var i = 0; i <= bytes.length - targetBytes.length; i++) {
        var match = true;
        for (var j = 0; j < targetBytes.length; j++) {
            if ((bytes[i + j] & 0xFF) !== targetBytes[j]) { match = false; break; }
        }
        if (match) {
            var pos = i + targetBytes.length;
            var idBytes = [];
            while (pos < bytes.length) {
                var b = bytes[pos] & 0xFF;
                if ((b >= 65 && b <= 90) || (b >= 48 && b <= 57) || b === 95) {
                    idBytes.push(b);
                    pos++;
                } else if (idBytes.length > 0) break;
                else pos++;
            }
            if (idBytes.length > 0) return new java.lang.String(idBytes, "UTF-8");
            return null;
        }
    }
    return null;
}
function getStoredItemIdFromQuantum(item) {
    if (!item || !item.hasItemMeta()) return null;
    var identifier = item.toString() + "@" + item.hashCode();
    var cached = quantumCache.get(identifier);
    if (cached) return cached;
    try {
        var meta = item.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        var quantumKey = new NamespacedKey("networks", "quantum_storage");
        if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return null;
        var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
        var itemKey = new NamespacedKey("networks", "item");
        if (!quantumData.has(itemKey, PersistentDataType.BYTE_ARRAY)) return null;
        var itemBytes = quantumData.get(itemKey, PersistentDataType.BYTE_ARRAY);
        var result = extractSlimefunIdFromBytes(itemBytes);
        if (result) quantumCache.put(identifier, result);
        return result;
    } catch (e) { return null; }
}
function getQuantumAmount(item) {
    var meta = item.getItemMeta();
    var pdc = meta.getPersistentDataContainer();
    var quantumKey = new NamespacedKey("networks", "quantum_storage");
    if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return 0;
    var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
    var amountKey = new NamespacedKey("networks", "amount");
    if (quantumData.has(amountKey, PersistentDataType.LONG)) return Number(quantumData.get(amountKey, PersistentDataType.LONG));
    if (quantumData.has(amountKey, PersistentDataType.INTEGER)) return Number(quantumData.get(amountKey, PersistentDataType.INTEGER));
    return 0;
}
function setQuantumAmount(item, newAmount) {
    var meta = item.getItemMeta();
    var pdc = meta.getPersistentDataContainer();
    var quantumKey = new NamespacedKey("networks", "quantum_storage");
    if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return false;
    var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
    var amountKey = new NamespacedKey("networks", "amount");
    if (newAmount >= 2147483647) {
        quantumData.set(amountKey, PersistentDataType.LONG, Long.valueOf(newAmount));
    } else {
        quantumData.set(amountKey, PersistentDataType.INTEGER, Math.floor(newAmount));
    }
    pdc.set(quantumKey, PersistentDataType.TAG_CONTAINER, quantumData);
    item.setItemMeta(meta);
    updateQuantumStorageLore(item, newAmount);
    return true;
}
function updateQuantumStorageLore(item, newAmount) {
    try {
        var meta = item.getItemMeta();
        if (!meta || !meta.hasLore()) return;
        var lore = meta.getLore();
        var newLore = new ArrayList();
        var plainNumber = newAmount.toString();
        for (var i = 0; i < lore.size(); i++) {
            var line = lore.get(i);
            if (line.includes("数量:")) {
                if (line.includes('"text":"')) {
                    line = line.replace(/("text":")(\d+)(")/, '$1' + plainNumber + '$3');
                } else {
                    line = line.replace(/(数量:.*?)(\d+)/, '$1' + plainNumber);
                }
            }
            newLore.add(line);
        }
        meta.setLore(newLore);
        item.setItemMeta(meta);
    } catch (e) {}
}
function stackToExistingSlots(menu, itemStack, amount) {
    if (amount <= 0) return 0;
    var remaining = amount;
    for (var idx = 0; idx < OUTPUT_SLOTS.length && remaining > 0; idx++) {
        var slot = OUTPUT_SLOTS[idx];
        var existing = menu.getItemInSlot(slot);
        if (existing && isSameItem(existing, itemStack)) {
            var space = STACK_SIZE - existing.getAmount();
            if (space > 0) {
                var add = Math.min(remaining, space);
                existing.setAmount(existing.getAmount() + add);
                remaining -= add;
            }
        }
    }
    return remaining;
}
function fillEmptySlots(menu, itemStack, amount) {
    if (amount <= 0) return 0;
    var placed = 0;
    var empty = [];
    for (var idx = 0; idx < OUTPUT_SLOTS.length; idx++) {
        var slot = OUTPUT_SLOTS[idx];
        if (!menu.getItemInSlot(slot)) empty.push(slot);
    }
    for (var i = 0; i < empty.length && placed < amount; i++) {
        var stackSize = Math.min(amount - placed, STACK_SIZE);
        var newStack = itemStack.clone();
        newStack.setAmount(stackSize);
        menu.replaceExistingItem(empty[i], newStack);
        placed += stackSize;
    }
    return placed;
}
function tick(info) {
    try {
        var loc = info.block().getLocation();
        var key = loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
        var now = Date.now();
        if (lastGenTime.get(key) && now - lastGenTime.get(key) < GENERATION_INTERVAL_MS) return;
        var targetLoc = loc.clone().add(0, -1, 0);
        var targetSf = StorageCacheUtils.getSfItem(targetLoc);
        if (!targetSf || targetSf.getId() !== TARGET_MACHINE_ID) return;
        var targetMenu = StorageCacheUtils.getMenu(targetLoc);
        if (!targetMenu) return;
        var pickaxe = targetMenu.getItemInSlot(CHECK_SLOT);
        if (!isRequiredPickaxe(pickaxe)) return;
        var configItem = targetMenu.getItemInSlot(COUNT_SLOT);
        if (!configItem) return;
        var countStr = getLoreValue(configItem, "§7数量: §f");
        var machineCount = parseMachineCount(countStr);
        if (machineCount <= 0) return;
        var probId = getLoreValue(configItem, "§7ID: §f");
        var percent = DEFAULT_PERCENT;
        if (probId && PROBABILITY_MAP[probId] !== undefined) percent = PROBABILITY_MAP[probId];
        var quantumItem = targetMenu.getItemInSlot(QUANTUM_SLOT);
        if (!quantumItem || quantumItem.getAmount() !== 1) return;
        if (!ChatColor.stripColor(quantumItem.getItemMeta().getDisplayName() || "").includes("网络量子存储")) return;
        var storedItemId = getStoredItemIdFromQuantum(quantumItem);
        if (!storedItemId || ALLOWED_ITEM_IDS.indexOf(storedItemId) === -1) return;
        var itemStack = getSlimefunItemById(storedItemId);
        if (!itemStack) return;
        itemStack.setAmount(1);
        var maxGen = Math.floor(machineCount * percent);
        var toGen = Math.floor(Math.random() * (maxGen + 1));
        if (toGen === 0) return;
        var currentAmount = getQuantumAmount(quantumItem);
        var space = Number.MAX_SAFE_INTEGER - currentAmount;
        var add = Math.min(toGen, space);
        var newAmount = currentAmount + add;
        setQuantumAmount(quantumItem, newAmount);
        var remaining = toGen - add;
        if (remaining > 0) {
            remaining = stackToExistingSlots(targetMenu, itemStack, remaining);
            if (remaining > 0) fillEmptySlots(targetMenu, itemStack, remaining);
        }
        lastGenTime.put(key, now);
    } catch (e) {}
}
function onOpen(player) {}
function onClick(player, slot, slotItem, clickAction) {}
function onClose(player) {}