var Material = Java.type("org.bukkit.Material");
var ItemStack = Java.type("org.bukkit.inventory.ItemStack");
var ChatColor = Java.type("org.bukkit.ChatColor");
var NamespacedKey = Java.type("org.bukkit.NamespacedKey");
var PersistentDataType = Java.type("org.bukkit.persistence.PersistentDataType");
var SLOT_40 = 4;
var SLOT_43 = 7;
var SLOT_49 = 13;
var SLOT_52 = 16;
var ALLOWED_40 = ["MOMOTECH_SHINE_AND_DARK_CONSTRUCTOR", "MOMOTECH_RULE_SHINE_AND_DARK_CONSTRUCTOR"];
var ALLOWED_43 = ["MOMOTECH_SHINE", "MOMOTECH_DARK"];
var DEFAULT_ITEM_40 = (function() {
    var item = new ItemStack(Material.GLOWSTONE, 1);
    var meta = item.getItemMeta();
    meta.setDisplayName("§a点击检测光暗生成器的网络量子存储");
    item.setItemMeta(meta);
    return item;
})();
var DEFAULT_ITEM_43 = (function() {
    var item = new ItemStack(Material.RED_TERRACOTTA, 1);
    var meta = item.getItemMeta();
    meta.setDisplayName("§a点击检测光或暗的网络量子存储");
    item.setItemMeta(meta);
    return item;
})();
var quantumCache = new java.util.HashMap();
function extractSlimefunIdFromBytes(bytes) {
    if (!bytes || bytes.length < 10) return null;
    var target = "slimefun:slimefun_item";
    var targetBytes = [];
    for (var i = 0; i < target.length; i++) targetBytes.push(target.charCodeAt(i) & 0xFF);
    for (var i = 0; i <= bytes.length - targetBytes.length; i++) {
        var match = true;
        for (var j = 0; j < targetBytes.length; j++) {
            if ((bytes[i + j] & 0xFF) !== targetBytes[j]) { match = false; break; }
        }
        if (match) {
            var pos = i + targetBytes.length;
            var idBytes = [];
            while (pos < bytes.length) {
                var b = bytes[pos] & 0xFF;
                if ((b >= 65 && b <= 90) || (b >= 48 && b <= 57) || b === 95) {
                    idBytes.push(b);
                    pos++;
                } else if (idBytes.length > 0) break;
                else pos++;
            }
            if (idBytes.length > 0) return new java.lang.String(idBytes, "UTF-8");
            return null;
        }
    }
    return null;
}
function getStoredItemIdFromQuantum(item) {
    if (!item || !item.hasItemMeta()) return null;
    var identifier = item.toString() + "@" + item.hashCode();
    var cached = quantumCache.get(identifier);
    if (cached) return cached;
    try {
        var meta = item.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        var quantumKey = new NamespacedKey("networks", "quantum_storage");
        if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return null;
        var quantumData = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
        var itemKey = new NamespacedKey("networks", "item");
        if (!quantumData.has(itemKey, PersistentDataType.BYTE_ARRAY)) return null;
        var itemBytes = quantumData.get(itemKey, PersistentDataType.BYTE_ARRAY);
        var result = extractSlimefunIdFromBytes(itemBytes);
        if (result) quantumCache.put(identifier, result);
        return result;
    } catch (e) { return null; }
}
function getItemNameFromLore(item) {
    try {
        var meta = item.getItemMeta();
        if (!meta || !meta.hasLore()) return meta.getDisplayName() || "未知物品";
        var lore = meta.getLore();
        for (var i = 0; i < lore.size(); i++) {
            var line = ChatColor.stripColor(lore.get(i));
            if (line.indexOf("物品:") !== -1) return line.substring(line.indexOf("物品:") + 3).trim();
            if (line.indexOf("存储:") !== -1) return line.substring(line.indexOf("存储:") + 3).trim();
        }
        return meta.getDisplayName() || "未知物品";
    } catch (e) { return "未知物品"; }
}
function getAmount(item) {
    var meta = item.getItemMeta();
    var pdc = meta.getPersistentDataContainer();
    var quantumKey = new NamespacedKey("networks", "quantum_storage");
    if (!pdc.has(quantumKey, PersistentDataType.TAG_CONTAINER)) return 0;
    var data = pdc.get(quantumKey, PersistentDataType.TAG_CONTAINER);
    var amountKey = new NamespacedKey("networks", "amount");
    if (data.has(amountKey, PersistentDataType.LONG)) return Number(data.get(amountKey, PersistentDataType.LONG));
    if (data.has(amountKey, PersistentDataType.INTEGER)) return Number(data.get(amountKey, PersistentDataType.INTEGER));
    return 0;
}
function parseQuantumData(item) {
    try {
        var itemId = getStoredItemIdFromQuantum(item);
        if (!itemId) itemId = "解析失败";
        var amount = getAmount(item);
        var itemName = getItemNameFromLore(item) || "未知物品";
        return { itemId: itemId, itemName: itemName, amount: amount };
    } catch (e) {
        return { itemId: "解析失败", itemName: "解析失败", amount: 0 };
    }
}
function isAllowed(itemId, allowedItems) {
    for (var i = 0; i < allowedItems.length; i++) if (itemId === allowedItems[i]) return true;
    return false;
}
function updateWorkSlot(inv, workSlot, data, isSlot43) {
    var material = isSlot43 ? (data.itemId.indexOf("SHINE") !== -1 ? Material.GLOWSTONE_DUST : Material.GUNPOWDER) : Material.GLOWSTONE;
    var newItem = new ItemStack(material, 1);
    var meta = newItem.getItemMeta();
    meta.setDisplayName("§e" + data.itemName);
    meta.setLore(["§7ID: §f" + data.itemId, "§7数量: §f" + data.amount.toLocaleString()]);
    newItem.setItemMeta(meta);
    inv.setItem(workSlot, newItem);
}
function resetWorkSlot(inv, workSlot, isSlot43) {
    inv.setItem(workSlot, (isSlot43 ? DEFAULT_ITEM_43 : DEFAULT_ITEM_40).clone());
}
function refreshSlot(inv, inputSlot, workSlot, allowedItems, isSlot43, player) {
    try {
        var quantumItem = inv.getItem(inputSlot);
        if (!quantumItem || quantumItem.getType() === Material.AIR) {
            resetWorkSlot(inv, workSlot, isSlot43);
            if (player) player.sendMessage("§c输入槽位为空");
            return;
        }
        var data = parseQuantumData(quantumItem);
        if (!isAllowed(data.itemId, allowedItems)) {
            resetWorkSlot(inv, workSlot, isSlot43);
            if (player) player.sendMessage("§c物品不在允许列表中");
            return;
        }
        updateWorkSlot(inv, workSlot, data, isSlot43);
        if (player) player.sendMessage("§a检测完成");
    } catch (e) {
        resetWorkSlot(inv, workSlot, isSlot43);
        if (player) player.sendMessage("§c检测出错");
    }
}
function onClick(player, slot, slotItem, clickAction) {
    var inv = player.getOpenInventory().getTopInventory();
    if (!inv) return false;
    if (slot === SLOT_40) {
        refreshSlot(inv, SLOT_49, SLOT_40, ALLOWED_40, false, player);
    } else if (slot === SLOT_43) {
        refreshSlot(inv, SLOT_52, SLOT_43, ALLOWED_43, true, player);
    }
    return false;
}
function onClose(player) {
    try {
        var inv = player.getOpenInventory().getTopInventory();
        if (!inv) return;
        refreshSlot(inv, SLOT_49, SLOT_40, ALLOWED_40, false, null);
        refreshSlot(inv, SLOT_52, SLOT_43, ALLOWED_43, true, null);
    } catch (e) {}
}